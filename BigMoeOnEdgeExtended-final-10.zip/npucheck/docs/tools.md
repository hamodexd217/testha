# Tool extension guide

The tool system is intentionally registry-driven. A tool implements `com.bigmoe.onedge.tools.Tool` with:

* `name`: stable machine-readable tool name.
* `description`: concise model-facing capability text.
* `parametersSchema`: JSON Schema-style object describing arguments and required fields.
* `category`: `FILES`, `CODE`, or `WEB` for UI/settings grouping.
* `describe(arguments)`: short live UI label while the tool runs.
* `confirmation(arguments)`: optional approval request. Return a `ConfirmationRequest` for edits, replacements,
  deletes, or other destructive actions; return `null` for safe operations.
* `execute(arguments, ctx)`: the real operation. `ToolContext` identifies the chat/session so created artifacts can be linked.

Register the tool in `AppContainer.toolManager`. `ToolManager` then supplies it to the prompt, parses its calls, runs it
off the main thread with a timeout/result-size cap, emits a tool-running event, and routes confirmation through the chat UI.

For a switchable tool, add its name to the appropriate `*_TOOL_NAMES` set in `AgentController` and expose the setting in
`EngineSettings`/Settings UI. For file-producing tools, update `ArtifactRegistry` so the chat's artifact list stays in sync.

Current groups:

* Files: list/read/search/create/edit/rename/delete/create_folder/create_project/export_zip.
* Code: search_code/analyze_code/run_javascript.
* Web: web_search/read_webpage/extract_webpage.

Security rules are deliberate: every file path is resolved inside the private workspace, destructive changes require user
approval, JavaScript runs in an offline WebView sandbox with no JS bridge, and artifact HTML uses a restrictive CSP.
