/**
 * Icon mappings for file types and model modalities
 * Centralized configuration to ensure consistent icon usage across the app
 */

import {
	Eye as VisionIcon,
	File as FileIcon,
	FileText as FileTextIcon,
	Image as ImageIcon,
	Lightbulb as ReasoningIcon,
	Mic as AudioIcon,
	Video as VideoIcon
} from '@lucide/svelte';
import { FileTypeCategory, ModelCapability, ModelModality } from '$lib/enums';
import type { ModelCapabilities, ModelModalities } from '$lib/types/models';
import type { Component } from 'svelte';

export const FILE_TYPE_ICONS = {
	[FileTypeCategory.AUDIO]: AudioIcon,
	[FileTypeCategory.IMAGE]: ImageIcon,
	[FileTypeCategory.PDF]: FileIcon,
	[FileTypeCategory.TEXT]: FileTextIcon,
	[FileTypeCategory.VIDEO]: VideoIcon
} as const;

export const DEFAULT_FILE_ICON = FileIcon;

export const MODALITY_ICONS = {
	[ModelModality.AUDIO]: AudioIcon,
	[ModelModality.VIDEO]: VideoIcon,
	[ModelModality.VISION]: VisionIcon
} as const;

export const MODALITY_LABELS = {
	[ModelModality.AUDIO]: 'Audio',
	[ModelModality.VIDEO]: 'Video',
	[ModelModality.VISION]: 'Vision'
} as const;

/** Maps an input ModelModality to the boolean flag it drives on the ModelModalities type */
export const MODALITY_FLAG_KEYS: Record<
	Exclude<ModelModality, ModelModality.TEXT>,
	keyof ModelModalities
> = {
	[ModelModality.AUDIO]: 'audio',
	[ModelModality.VIDEO]: 'video',
	[ModelModality.VISION]: 'vision'
};

export const CAPABILITY_ICONS: Record<ModelCapability, Component> = {
	[ModelCapability.REASONING]: ReasoningIcon
} as const;

export const CAPABILITY_LABELS: Record<ModelCapability, string> = {
	[ModelCapability.REASONING]: 'Reasoning'
} as const;

/** Maps a ModelCapability to the boolean flag it drives on the ModelCapabilities type */
export const CAPABILITY_FLAG_KEYS: Record<ModelCapability, keyof ModelCapabilities> = {
	[ModelCapability.REASONING]: 'reasoning'
};

// Shared SVG icon strings for copy and preview buttons
export const COPY_ICON_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-copy-icon lucide-copy"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>`;

export const PREVIEW_ICON_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-eye lucide-eye-icon"><path d="M2.062 12.345a1 1 0 0 1 0-.69C3.5 7.73 7.36 5 12 5s8.5 2.73 9.938 6.655a1 1 0 0 1 0 .69C20.5 16.27 16.64 19 12 19s-8.5-2.73-9.938-6.655"/><circle cx="12" cy="12" r="3"/></svg>`;

export const CODE_ICON_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-code lucide-code-icon"><path d="m16 18 6-6-6-6"/><path d="m8 6-6 6 6 6"/></svg>`;
