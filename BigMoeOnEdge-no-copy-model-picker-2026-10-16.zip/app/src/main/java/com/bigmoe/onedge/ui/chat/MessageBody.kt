package com.bigmoe.onedge.ui.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.unit.dp
import com.bigmoe.onedge.ui.theme.AppTheme

@Composable
fun MessageBody(
    text: String,
    textColor: Color,
    isStreaming: Boolean = false,
    onOpenAsArtifact: (language: String, code: String) -> Unit = { _, _ -> },
    modifier: Modifier = Modifier
) {
    // Parsing is pure and cheap, but streaming recomposes on every token: only redo it when the text changed.
    val blocks = remember(text) { MarkdownLite.parse(text) }
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        for (block in blocks) {
            when (block) {
                is MarkdownBlock.Paragraph -> MarkdownParagraph(block.text, textColor)
                is MarkdownBlock.Math -> MathBlock(block.tex, textColor)
                is MarkdownBlock.Code -> CodeBlock(block, onOpenAsArtifact)
                is MarkdownBlock.Prompt -> PromptBlock(block.text, block.label)
            }
        }
    }
}

private val BR_TAG = Regex("(?i)<br\\s*/?>")

@Composable
private fun bodyStyle(color: Color) = MaterialTheme.typography.bodyLarge.copy(color = color)

@Composable
private fun MarkdownParagraph(text: String, color: Color) {
    val lines = remember(text) { text.replace(BR_TAG, "\n").lines() }
    var i = 0
    while (i < lines.size) {
        val line = lines[i]
        if (line.isBlank()) {
            i++
            continue
        }
        val table = MarkdownTable.collect(lines, i)
        if (table != null) {
            TableText(table.first, color)
            i = table.second
            continue
        }
        when (val l = MdLine.classify(line)) {
            is MdLine.Heading -> {
                val style = when (l.level) {
                    1 -> MaterialTheme.typography.titleLarge
                    2 -> MaterialTheme.typography.titleMedium
                    3 -> MaterialTheme.typography.titleSmall
                    else -> MaterialTheme.typography.bodyLarge
                }
                androidx.compose.foundation.text.BasicText(
                    text = inlineText(l.text, color),
                    style = style.copy(color = color, fontWeight = FontWeight.SemiBold)
                )
            }
            is MdLine.Bullet -> Row(modifier = Modifier.padding(start = (l.level * 16).dp)) {
                androidx.compose.foundation.text.BasicText(
                    text = l.marker,
                    style = bodyStyle(color),
                    modifier = Modifier.width(if (l.marker.length > 1) 30.dp else 18.dp)
                )
                androidx.compose.foundation.text.BasicText(
                    text = inlineText(l.text, color),
                    style = bodyStyle(color),
                    modifier = Modifier.weight(1f)
                )
            }
            is MdLine.Quote -> Row(modifier = Modifier.height(IntrinsicSize.Min).padding(start = ((l.depth - 1) * 12).dp)) {
                Box(modifier = Modifier.width(3.dp).fillMaxHeight().background(MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)))
                Spacer(Modifier.width(8.dp))
                androidx.compose.foundation.text.BasicText(
                    text = inlineText(l.text, color),
                    style = bodyStyle(color).copy(fontStyle = FontStyle.Italic),
                    modifier = Modifier.weight(1f)
                )
            }
            MdLine.Rule -> Box(
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).height(1.dp).background(color.copy(alpha = 0.25f))
            )
            is MdLine.Plain -> androidx.compose.foundation.text.BasicText(
                text = inlineText(l.text, color),
                style = bodyStyle(color)
            )
        }
        i++
    }
}

/** Display math ($$...$$ or \[...\]) as readable Unicode, on its own line(s), scrollable when it is wide. */
@Composable
private fun MathBlock(tex: String, color: Color) {
    val shown = remember(tex) { MathText.toUnicode(tex, multiline = true) }
    Box(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(start = 8.dp, top = 2.dp, bottom = 2.dp)) {
        androidx.compose.foundation.text.BasicText(
            text = shown,
            style = bodyStyle(color).copy(fontFamily = FontFamily.Serif)
        )
    }
}

/** A pipe table as aligned monospace text, scrollable sideways. */
@Composable
private fun TableText(rows: List<List<String>>, color: Color) {
    val shown = remember(rows) { MarkdownTable.format(rows) }
    Box(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
        androidx.compose.foundation.text.BasicText(
            text = shown,
            style = MaterialTheme.typography.bodyMedium.copy(color = color, fontFamily = FontFamily.Monospace)
        )
    }
}

@Composable
private fun inlineText(text: String, color: Color): AnnotatedString {
    val spans = remember(text) { InlineMarkdown.parse(text) }
    val codeBackground = AppTheme.colors.codeBlock
    val codeColor = AppTheme.colors.onCodeBlock
    val linkColor = MaterialTheme.colorScheme.primary
    val builder = AnnotatedString.Builder()
    for (s in spans) {
        val style = SpanStyle(
            fontWeight = if (s.bold) FontWeight.Bold else null,
            fontStyle = if (s.italic) FontStyle.Italic else null,
            textDecoration = when {
                s.strike -> TextDecoration.LineThrough
                s.link -> TextDecoration.Underline
                else -> null
            },
            fontFamily = when {
                s.code -> FontFamily.Monospace
                s.math -> FontFamily.Serif
                else -> null
            },
            background = if (s.code) codeBackground else Color.Unspecified,
            color = when {
                s.code -> codeColor
                s.link -> linkColor
                else -> color
            }
        )
        builder.withStyle(style) { append(s.text) }
    }
    return builder.toAnnotatedString()
}

@Composable
private fun CodeBlock(block: MarkdownBlock.Code, onOpenAsArtifact: (language: String, code: String) -> Unit) {
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) { if (copied) { kotlinx.coroutines.delay(1200); copied = false } }
    val language = remember(block.language, block.fileName, block.code) {
        // Same priority as artifacts: fence tag, then file name extension, then a guess from the code itself.
        com.bigmoe.onedge.parser.ArtifactLanguages.resolve(block.language, block.fileName)
            ?.takeUnless { it == "text" }
            ?: SyntaxHighlighter.detectLanguage(block.code)
    }
    val codeColor = AppTheme.colors.onCodeBlock
    val annotated = remember(language, block.code, codeColor) {
        val builder = AnnotatedString.Builder()
        for (token in SyntaxHighlighter.tokenize(language, block.code)) {
            val style = when (token.kind) {
                SyntaxHighlighter.Kind.KEYWORD -> SpanStyle(fontWeight = FontWeight.Bold)
                SyntaxHighlighter.Kind.STRING -> SpanStyle(fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
                SyntaxHighlighter.Kind.COMMENT -> SpanStyle(color = codeColor.copy(alpha = 0.65f))
                SyntaxHighlighter.Kind.NUMBER -> SpanStyle(fontWeight = FontWeight.SemiBold)
                SyntaxHighlighter.Kind.TAG -> SpanStyle(fontWeight = FontWeight.Bold)
                SyntaxHighlighter.Kind.FUNCTION -> SpanStyle(fontWeight = FontWeight.SemiBold)
                SyntaxHighlighter.Kind.PLAIN -> SpanStyle()
            }
            builder.withStyle(style) { append(token.text) }
        }
        builder.toAnnotatedString()
    }

    Surface(color = AppTheme.colors.codeBlock, shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(10.dp)) {
            Row(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = com.bigmoe.onedge.parser.ArtifactLanguages.displayName(language),
                    style = MaterialTheme.typography.labelMedium,
                    color = AppTheme.colors.onCodeBlock,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = {
                    // Raw code only: no fences, no language label.
                    clipboard.setText(AnnotatedString(block.code))
                    copied = true
                }) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy code")
                    Spacer(Modifier.padding(start = 4.dp))
                    Text(if (copied) "Copied" else "Copy")
                }
                if (block.closed) {
                    TextButton(onClick = { onOpenAsArtifact(language, block.code) }) {
                        Icon(Icons.Default.OpenInNew, contentDescription = "Open as artifact")
                        Spacer(Modifier.padding(start = 4.dp))
                        Text("Artifact")
                    }
                }
            }
            Spacer(Modifier.padding(top = 4.dp))
            SelectionContainer {
                Text(
                    text = annotated,
                    color = AppTheme.colors.onCodeBlock,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.horizontalScroll(rememberScrollState())
                )
            }
        }
    }
}


@Composable
private fun PromptBlock(text: String, label: String = "Prompt") {
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) {
        if (copied) {
            kotlinx.coroutines.delay(1200)
            copied = false
        }
    }
    Surface(color = AppTheme.colors.codeBlock, shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(10.dp)) {
            Row(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelMedium,
                    color = AppTheme.colors.onCodeBlock,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = {
                    clipboard.setText(AnnotatedString(text))
                    copied = true
                }) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy ${label.lowercase()}")
                    Spacer(Modifier.padding(start = 4.dp))
                    Text(if (copied) "Copied" else "Copy")
                }
            }
            Spacer(Modifier.padding(top = 4.dp))
            SelectionContainer {
                Text(
                    text = text,
                    color = AppTheme.colors.onCodeBlock,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                )
            }
        }
    }
}
