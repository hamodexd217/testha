package com.bigmoe.onedge.ui.chat

/**
 * LaTeX math -> readable Unicode text, for chat bubbles that have no TeX engine.
 *
 *   \frac{-b \pm \sqrt{b^2 - 4ac}}{2a}   ->   (-b ± √(b² - 4ac))/(2a)
 *
 * Pure Kotlin, no Android types. It covers what chat models actually write: fractions, roots, super/subscripts, Greek
 * letters, operators and relations, \text, \left/\right, accents, \boxed, \binom, and the common environments
 * (cases, matrices, aligned). Anything it does not know is left as written (`\foo`), never dropped.
 */
object MathText {

    /** [multiline] keeps `\\` row breaks as line breaks (display math); inline math flattens them. */
    fun toUnicode(tex: String, multiline: Boolean = false): String = Converter(tex, multiline).convert()

    // ---- tables ----------------------------------------------------------------------------------------------------

    private val SYMBOLS: Map<String, String> = mapOf(
        // Greek
        "alpha" to "α", "beta" to "β", "gamma" to "γ", "delta" to "δ", "epsilon" to "ε", "varepsilon" to "ε", "zeta" to "ζ",
        "eta" to "η", "theta" to "θ", "vartheta" to "ϑ", "iota" to "ι", "kappa" to "κ", "lambda" to "λ", "mu" to "μ",
        "nu" to "ν", "xi" to "ξ", "pi" to "π", "varpi" to "ϖ", "rho" to "ρ", "varrho" to "ϱ", "sigma" to "σ",
        "varsigma" to "ς", "tau" to "τ", "upsilon" to "υ", "phi" to "φ", "varphi" to "φ", "chi" to "χ", "psi" to "ψ",
        "omega" to "ω", "Gamma" to "Γ", "Delta" to "Δ", "Theta" to "Θ", "Lambda" to "Λ", "Xi" to "Ξ", "Pi" to "Π",
        "Sigma" to "Σ", "Upsilon" to "Υ", "Phi" to "Φ", "Psi" to "Ψ", "Omega" to "Ω",
        // operators
        "pm" to "±", "mp" to "∓", "times" to "×", "div" to "÷", "cdot" to "·", "ast" to "∗", "star" to "⋆", "circ" to "∘",
        "bullet" to "•", "oplus" to "⊕", "otimes" to "⊗", "ominus" to "⊖", "odot" to "⊙", "cup" to "∪", "cap" to "∩",
        "setminus" to "∖", "land" to "∧", "wedge" to "∧", "lor" to "∨", "vee" to "∨", "neg" to "¬", "lnot" to "¬",
        "sum" to "∑", "prod" to "∏", "coprod" to "∐", "int" to "∫", "iint" to "∬", "iiint" to "∭", "oint" to "∮",
        "partial" to "∂", "nabla" to "∇", "infty" to "∞", "emptyset" to "∅", "varnothing" to "∅",
        // relations
        "approx" to "≈", "sim" to "∼", "simeq" to "≃", "cong" to "≅", "neq" to "≠", "ne" to "≠", "equiv" to "≡",
        "leq" to "≤", "le" to "≤", "geq" to "≥", "ge" to "≥", "ll" to "≪", "gg" to "≫", "propto" to "∝", "doteq" to "≐",
        "in" to "∈", "notin" to "∉", "ni" to "∋", "subset" to "⊂", "subseteq" to "⊆", "supset" to "⊃", "supseteq" to "⊇",
        "mid" to "∣", "parallel" to "∥", "perp" to "⊥", "angle" to "∠", "forall" to "∀", "exists" to "∃", "nexists" to "∄",
        "therefore" to "∴", "because" to "∵",
        // arrows
        "to" to "→", "rightarrow" to "→", "leftarrow" to "←", "gets" to "←", "leftrightarrow" to "↔", "Rightarrow" to "⇒",
        "Leftarrow" to "⇐", "Leftrightarrow" to "⇔", "implies" to "⟹", "iff" to "⟺", "mapsto" to "↦", "uparrow" to "↑",
        "downarrow" to "↓", "longrightarrow" to "⟶", "longleftarrow" to "⟵",
        // dots, brackets, misc
        "ldots" to "…", "dots" to "…", "cdots" to "⋯", "vdots" to "⋮", "ddots" to "⋱", "degree" to "°",
        "langle" to "⟨", "rangle" to "⟩", "lfloor" to "⌊", "rfloor" to "⌋", "lceil" to "⌈", "rceil" to "⌉",
        "lbrace" to "{", "rbrace" to "}", "vert" to "|", "lvert" to "|", "rvert" to "|", "Vert" to "‖", "|" to "‖",
        "ell" to "ℓ", "hbar" to "ℏ", "Re" to "ℜ", "Im" to "ℑ", "aleph" to "ℵ", "prime" to "′", "dag" to "†",
        "S" to "§", "P" to "¶", "copyright" to "©", "quad" to "\u00A0\u00A0", "qquad" to "\u00A0\u00A0\u00A0\u00A0",
        "textdegree" to "°", "checkmark" to "✓"
    )

    /** Operator names that are written as words. */
    private val FUNCTIONS = setOf(
        "sin", "cos", "tan", "cot", "sec", "csc", "arcsin", "arccos", "arctan", "sinh", "cosh", "tanh", "coth",
        "log", "ln", "lg", "exp", "lim", "limsup", "liminf", "max", "min", "sup", "inf", "det", "dim", "ker", "gcd",
        "lcm", "deg", "arg", "Pr", "hom", "tr", "rank", "mod", "bmod", "pmod"
    )

    private val IGNORED = setOf(
        "left", "right", "big", "Big", "bigg", "Bigg", "bigl", "bigr", "Bigl", "Bigr", "biggl", "biggr", "Biggl", "Biggr",
        "middle", "limits", "nolimits", "displaystyle", "textstyle", "scriptstyle", "scriptscriptstyle", "nonumber",
        "notag", "mathop", "mathrel", "mathbin", "mathpunct", "mathord", "hline", "toprule", "midrule", "bottomrule",
        "centering", "noindent"
    )

    private val VERBATIM = setOf("text", "textrm", "textit", "textbf", "textsf", "texttt", "mbox", "hbox", "textnormal", "ce", "pu")

    private val STYLES = setOf("mathrm", "mathit", "mathbf", "mathsf", "mathtt", "mathcal", "mathfrak", "mathscr", "boldsymbol", "bm", "operatorname", "mathnormal")

    private val ACCENTS: Map<String, Char> = mapOf(
        "hat" to '\u0302', "widehat" to '\u0302', "tilde" to '\u0303', "widetilde" to '\u0303', "vec" to '\u20D7',
        "dot" to '\u0307', "ddot" to '\u0308', "check" to '\u030C', "acute" to '\u0301', "grave" to '\u0300',
        "breve" to '\u0306', "bar" to '\u0304', "overline" to '\u0304'
    )

    private val BLACKBOARD: Map<Char, String> = mapOf('R' to "ℝ", 'N' to "ℕ", 'Z' to "ℤ", 'Q' to "ℚ", 'C' to "ℂ", 'P' to "ℙ", 'H' to "ℍ")

    // Only the super/subscripts every common Android font has; anything else falls back to ^x / _x, never to a missing-glyph box.
    private val SUPERSCRIPT: Map<Char, Char> = mapOf(
        '0' to '⁰', '1' to '¹', '2' to '²', '3' to '³', '4' to '⁴', '5' to '⁵', '6' to '⁶', '7' to '⁷', '8' to '⁸', '9' to '⁹',
        '+' to '⁺', '-' to '⁻', '\u2212' to '⁻', '=' to '⁼', '(' to '⁽', ')' to '⁾', 'n' to 'ⁿ', 'i' to 'ⁱ'
    )
    private val SUBSCRIPT: Map<Char, Char> = mapOf(
        '0' to '₀', '1' to '₁', '2' to '₂', '3' to '₃', '4' to '₄', '5' to '₅', '6' to '₆', '7' to '₇', '8' to '₈', '9' to '₉',
        '+' to '₊', '-' to '₋', '\u2212' to '₋', '=' to '₌', '(' to '₍', ')' to '₎'
    )

    /**
     * An operand that is one "atom" and needs no parentheses: a number ("224", "-6.6"), one letter with optional
     * scripts ("x", "b²", "x₁", "π"), or a root of one of those ("√3"). "2a", "a+b" and "Total Tokens" are not: a
     * fraction over "2a" must read (…)/(2a), not (…)/2a.
     */
    private val SIMPLE = Regex("^-?(?:\\d+(?:[.,]\\d+)?|\\p{L}[′²³¹⁰⁴-⁹ⁿⁱ₀-₉]*|√[\\p{L}\\p{N}]+[²³¹⁰⁴-⁹ⁿ]*)$")

    /** Operators that take limits: \sum_{i=1}^{n} -> ∑(i=1→n), \int_0^1 -> ∫₀¹. */
    private val BIG_OPERATORS = setOf("sum", "prod", "coprod", "int", "iint", "iiint", "oint")

    internal fun superscript(s: String): String? = mapAll(s, SUPERSCRIPT)
    internal fun subscript(s: String): String? = mapAll(s, SUBSCRIPT)

    private fun mapAll(s: String, map: Map<Char, Char>): String? {
        if (s.isEmpty()) return null
        val sb = StringBuilder()
        for (c in s) sb.append(map[c] ?: return null)
        return sb.toString()
    }

    // ---- converter -------------------------------------------------------------------------------------------------

    private class Converter(private val s: String, private val multiline: Boolean) {
        private var i = 0

        fun convert(): String {
            val raw = sequence(false)
            val lines = raw.split('\n').map { it.replace(Regex("[ \t]+"), " ").trim() }
            return if (multiline) lines.filter { it.isNotEmpty() }.joinToString("\n") else lines.joinToString(" ").trim()
        }

        private fun sequence(stopAtBrace: Boolean): String {
            val sb = StringBuilder()
            while (i < s.length) {
                val c = s[i]
                when (c) {
                    '}' -> {
                        if (stopAtBrace) return sb.toString()
                        i++ // a stray close brace
                    }
                    '{' -> {
                        i++
                        sb.append(sequence(true))
                        if (i < s.length && s[i] == '}') i++
                    }
                    '\\' -> sb.append(command())
                    '^' -> {
                        i++
                        sb.append(script(true))
                    }
                    '_' -> {
                        i++
                        sb.append(script(false))
                    }
                    '&' -> {
                        i++
                        sb.append("\u00A0\u00A0")
                    }
                    '~' -> {
                        i++
                        sb.append(' ')
                    }
                    else -> {
                        sb.append(c)
                        i++
                    }
                }
            }
            return sb.toString()
        }

        private fun skipSpaces() {
            while (i < s.length && (s[i] == ' ' || s[i] == '\t' || s[i] == '\n')) i++
        }

        /** The next argument, converted: a {group}, a \command, or one character. */
        private fun argument(): String {
            skipSpaces()
            if (i >= s.length) return ""
            return when (s[i]) {
                '{' -> {
                    i++
                    val r = sequence(true)
                    if (i < s.length && s[i] == '}') i++
                    r
                }
                '\\' -> command()
                else -> s[i++].toString()
            }
        }

        /** The next {group} exactly as written (for \text{...}); nested braces are kept. */
        private fun rawGroup(): String {
            skipSpaces()
            if (i >= s.length || s[i] != '{') return if (i < s.length) s[i++].toString() else ""
            i++
            val start = i
            var depth = 1
            while (i < s.length && depth > 0) {
                when (s[i]) {
                    '\\' -> i++ // skip the escaped character
                    '{' -> depth++
                    '}' -> depth--
                }
                i++
            }
            val end = if (depth == 0) i - 1 else i
            return s.substring(start, end.coerceAtLeast(start)).replace("\\ ", " ").replace("\\%", "%").replace("\\$", "$").replace("\\_", "_")
        }

        private fun script(isSup: Boolean): String {
            skipSpaces()
            // x^\circ and x^{\circ} are degrees.
            if (isSup) {
                if (s.startsWith("\\circ", i)) {
                    i += 5
                    return "°"
                }
                if (s.startsWith("{\\circ}", i)) {
                    i += 7
                    return "°"
                }
            }
            val arg = argument()
            val mapped = if (isSup) superscript(arg) else subscript(arg)
            if (mapped != null) return mapped
            val mark = if (isSup) "^" else "_"
            return if (arg.length <= 1 || SIMPLE.matches(arg)) mark + arg else "$mark($arg)"
        }

        private fun fraction(a: String, b: String): String {
            val num = if (SIMPLE.matches(a)) a else "($a)"
            val den = if (SIMPLE.matches(b)) b else "($b)"
            return "$num/$den"
        }

        /** The symbol plus its limits, if any follow it directly (in either order). */
        private fun bigOperator(symbol: String): String {
            var lo: String? = null
            var hi: String? = null
            for (k in 0 until 2) {
                skipSpaces()
                if (lo == null && i < s.length && s[i] == '_') {
                    i++
                    lo = argument()
                } else if (hi == null && i < s.length && s[i] == '^') {
                    i++
                    hi = argument()
                }
            }
            if (lo == null && hi == null) return symbol
            val l = lo?.let { subscript(it) }
            val h = hi?.let { superscript(it) }
            if ((lo == null || l != null) && (hi == null || h != null)) return symbol + (l ?: "") + (h ?: "")
            return symbol + "(" + (lo ?: "") + (if (hi != null) "→$hi" else "") + ")"
        }

        private fun radical(n: String?, a: String): String {
            val body = if (SIMPLE.matches(a)) a else "($a)"
            val root = when (n?.trim()) {
                null, "", "2" -> "√"
                "3" -> "∛"
                "4" -> "∜"
                else -> (superscript(n) ?: "($n)") + "√"
            }
            return root + body
        }

        private fun accent(arg: String, mark: Char): String = if (arg.length == 1) arg + mark else arg

        private fun command(): String {
            i++ // the backslash
            if (i >= s.length) return "\\"
            val c = s[i]
            if (!c.isLetter()) {
                i++
                return when (c) {
                    ',', ';', ':', ' ' -> " "
                    '!', '/', '-' -> ""
                    '\\' -> if (multiline) "\n" else "; "
                    '|' -> "‖"
                    else -> c.toString() // \{ \} \% \$ \& \# \_
                }
            }
            val start = i
            while (i < s.length && s[i].isLetter()) i++
            val name = s.substring(start, i)
            if (i < s.length && s[i] == '*' && name != "S") i++ // \hline*, \\*
            return named(name)
        }

        private fun named(name: String): String {
            when (name) {
                "frac", "dfrac", "tfrac", "cfrac" -> {
                    val a = argument()
                    val b = argument()
                    return fraction(a, b)
                }
                "sqrt" -> {
                    skipSpaces()
                    var n: String? = null
                    if (i < s.length && s[i] == '[') {
                        val close = s.indexOf(']', i)
                        if (close > 0) {
                            n = s.substring(i + 1, close)
                            i = close + 1
                        }
                    }
                    return radical(n, argument())
                }
                "binom", "dbinom", "tbinom" -> {
                    val a = argument()
                    val b = argument()
                    return "C($a, $b)"
                }
                "boxed", "fbox" -> return "[ " + argument() + " ]"
                "mathbb" -> {
                    val a = argument()
                    return if (a.length == 1) BLACKBOARD[a[0]] ?: a else a
                }
                "begin" -> return envBegin(rawGroup())
                "end" -> return envEnd(rawGroup())
                "label" -> {
                    rawGroup()
                    return ""
                }
                "tag" -> return "\u00A0\u00A0(" + rawGroup() + ")"
                "overset", "stackrel", "underset" -> {
                    argument()
                    return argument()
                }
                "xrightarrow", "xleftarrow" -> {
                    argument()
                    return if (name == "xrightarrow") "→" else "←"
                }
                "phantom", "hphantom", "vphantom", "smash" -> {
                    argument()
                    return ""
                }
                "underline" -> return argument()
                "not" -> return "¬"
            }
            if (name in VERBATIM) return rawGroup()
            if (name in STYLES) return argument()
            if (name in IGNORED) {
                // \left. and \right. are invisible delimiters.
                if ((name == "left" || name == "right") && i < s.length && s[i] == '.') i++
                return ""
            }
            val accentMark = ACCENTS[name]
            if (accentMark != null) {
                val a = argument()
                return if (name == "overline" && a.length > 1) a else accent(a, accentMark)
            }
            if (name in BIG_OPERATORS) return bigOperator(SYMBOLS.getValue(name))
            SYMBOLS[name]?.let { return it }
            if (name in FUNCTIONS) return name
            return "\\" + name // unknown: leave it as written rather than lose it
        }

        private fun envBegin(env: String): String = when (env.removeSuffix("*")) {
            "cases" -> "{ "
            "pmatrix" -> "("
            "bmatrix" -> "["
            "vmatrix" -> "|"
            else -> ""
        }

        private fun envEnd(env: String): String = when (env.removeSuffix("*")) {
            "pmatrix" -> ")"
            "bmatrix" -> "]"
            "vmatrix" -> "|"
            else -> ""
        }
    }
}
