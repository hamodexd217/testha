package com.bigmoe.onedge.ui.chat

/** One run of inline text with its style. Math spans already hold the converted Unicode text. */
data class MdSpan(
    val text: String,
    val bold: Boolean = false,
    val italic: Boolean = false,
    val strike: Boolean = false,
    val code: Boolean = false,
    val math: Boolean = false,
    val link: Boolean = false
)

/**
 * Inline markdown for chat bubbles, as plain data so it can be tested without Compose: **bold**, *italic* / _italic_,
 * ***both***, ~~strike~~, `code`, [links](url), ![images](url), and math: $x^2$, $$x$$, \(x\), \[x\].
 *
 * Like every markdown engine, anything that does not close stays literal, so text that is still streaming in
 * ("**half a bo") shows as typed until its closing marker arrives.
 */
object InlineMarkdown {

    fun parse(src: String): List<MdSpan> {
        val out = ArrayList<MdSpan>()
        parseInto(preprocess(src), MdSpan(""), out)
        return merge(out)
    }

    /** The text with all markup removed (math converted): for table cells and notifications. */
    fun plain(src: String): String = parse(src).joinToString("") { it.text }

    private const val ESCAPABLE = "\\`*_{}[]()#+-.!$~|>"

    private val SUP_TAG = Regex("(?i)<sup>(.*?)</sup>")
    private val SUB_TAG = Regex("(?i)<sub>(.*?)</sub>")
    private val BR_TAG = Regex("(?i)<br\\s*/?>")

    private fun preprocess(src: String): String {
        var s = src
        if (s.indexOf('<') >= 0) {
            s = SUP_TAG.replace(s) { MathText.superscript(it.groupValues[1]) ?: "^(${it.groupValues[1]})" }
            s = SUB_TAG.replace(s) { MathText.subscript(it.groupValues[1]) ?: "_(${it.groupValues[1]})" }
            s = BR_TAG.replace(s, " ")
        }
        if (s.indexOf('&') >= 0) {
            s = s.replace("&nbsp;", "\u00A0").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
                .replace("&#39;", "'").replace("&amp;", "&")
        }
        return s
    }

    private fun parseInto(text: String, base: MdSpan, out: MutableList<MdSpan>) {
        val run = StringBuilder()
        fun flush() {
            if (run.isNotEmpty()) {
                out.add(base.copy(text = run.toString()))
                run.setLength(0)
            }
        }
        val n = text.length
        var i = 0
        while (i < n) {
            val c = text[i]

            if (c == '\\' && i + 1 < n) {
                val d = text[i + 1]
                if (d == '(' || d == '[') {
                    val end = text.indexOf(if (d == '(') "\\)" else "\\]", i + 2)
                    if (end > 0) {
                        flush()
                        out.add(base.copy(text = MathText.toUnicode(text.substring(i + 2, end)), math = true))
                        i = end + 2
                        continue
                    }
                }
                if (ESCAPABLE.indexOf(d) >= 0) {
                    run.append(d)
                    i += 2
                } else {
                    run.append(c)
                    i++
                }
                continue
            }

            if (c == '$') {
                if (text.startsWith("$$", i)) {
                    val end = text.indexOf("$$", i + 2)
                    if (end > i + 2 && text.substring(i + 2, end).isNotBlank()) {
                        flush()
                        out.add(base.copy(text = MathText.toUnicode(text.substring(i + 2, end)), math = true))
                        i = end + 2
                        continue
                    }
                }
                val close = findMathClose(text, i)
                if (close > 0) {
                    flush()
                    out.add(base.copy(text = MathText.toUnicode(text.substring(i + 1, close)), math = true))
                    i = close + 1
                    continue
                }
                run.append(c)
                i++
                continue
            }

            if (c == '`') {
                var ticks = 0
                while (i + ticks < n && text[i + ticks] == '`') ticks++
                val marker = "`".repeat(ticks)
                val end = text.indexOf(marker, i + ticks)
                if (end >= 0) {
                    flush()
                    var content = text.substring(i + ticks, end)
                    if (content.length >= 2 && content.startsWith(" ") && content.endsWith(" ")) content = content.substring(1, content.length - 1)
                    out.add(base.copy(text = content, code = true))
                    i = end + ticks
                } else {
                    run.append(marker)
                    i += ticks
                }
                continue
            }

            if (c == '*' || c == '_' || c == '~') {
                var cnt = 0
                while (i + cnt < n && text[i + cnt] == c) cnt++
                val len = when {
                    c == '~' -> if (cnt == 2) 2 else 0
                    cnt >= 3 -> 3
                    else -> cnt
                }
                if (len > 0) {
                    val open = i + len
                    val prevOk = c != '_' || i == 0 || !text[i - 1].isLetterOrDigit()
                    val nextOk = open < n && !text[open].isWhitespace()
                    if (prevOk && nextOk) {
                        val close = findEmphasisClose(text, open, c, len)
                        if (close > 0) {
                            flush()
                            val style = when {
                                len == 3 -> base.copy(bold = true, italic = true)
                                c == '~' -> base.copy(strike = true)
                                len == 2 -> base.copy(bold = true)
                                else -> base.copy(italic = true)
                            }
                            parseInto(text.substring(open, close), style, out)
                            i = close + len
                            continue
                        }
                    }
                }
                run.append(text, i, i + cnt)
                i += cnt
                continue
            }

            if (c == '!' && i + 1 < n && text[i + 1] == '[') {
                val close = text.indexOf(']', i + 2)
                if (close > 0 && close + 1 < n && text[close + 1] == '(') {
                    val urlEnd = text.indexOf(')', close + 2)
                    if (urlEnd > 0) {
                        flush()
                        val alt = text.substring(i + 2, close).trim()
                        out.add(base.copy(text = if (alt.isEmpty()) "[image]" else "[image: $alt]"))
                        i = urlEnd + 1
                        continue
                    }
                }
            }

            if (c == '[') {
                val close = text.indexOf(']', i + 1)
                if (close > 0 && close + 1 < n && text[close + 1] == '(') {
                    val urlEnd = text.indexOf(')', close + 2)
                    if (urlEnd > 0) {
                        flush()
                        val label = plain(text.substring(i + 1, close)).ifBlank { text.substring(close + 2, urlEnd) }
                        out.add(base.copy(text = label, link = true))
                        i = urlEnd + 1
                        continue
                    }
                }
            }

            run.append(c)
            i++
        }
        flush()
    }

    /**
     * The closing `$` for the `$` at [open], or -1. Pandoc's rules, which keep prices out of it: the opening `$` is
     * followed by a non-space, the closing one is preceded by a non-space and not followed by a digit; a `$` that
     * cannot close but could open ("costs $5 and $10") means the first one was a price. Prose that merely sits between
     * two dollar signs is rejected too.
     */
    internal fun findMathClose(text: String, open: Int): Int {
        val n = text.length
        if (open + 1 >= n || text[open + 1].isWhitespace() || text[open + 1] == '$') return -1
        var k = open + 1
        while (k < n) {
            val ch = text[k]
            if (ch == '\\') {
                k += 2
                continue
            }
            if (ch == '$') {
                if (k > open + 1 && !text[k - 1].isWhitespace() && !(k + 1 < n && text[k + 1].isDigit())) {
                    return if (looksLikeProse(text.substring(open + 1, k))) -1 else k
                }
                if (k + 1 < n && !text[k + 1].isWhitespace()) return -1
            }
            k++
        }
        return -1
    }

    private fun looksLikeProse(content: String): Boolean {
        if (content.any { it in "\\^_{}=+*/<>" }) return false
        val words = content.split(Regex("\\s+")).count { it.length >= 3 && it.all { ch -> ch.isLetter() } }
        return words >= 3
    }

    private fun findEmphasisClose(text: String, from: Int, ch: Char, len: Int): Int {
        val marker = ch.toString().repeat(len)
        val n = text.length
        var k = from
        while (k < n) {
            val c = text[k]
            if (c == '\\') {
                k += 2
                continue
            }
            if (c == '`') { // never close inside a code span
                val end = text.indexOf('`', k + 1)
                if (end < 0) break
                k = end + 1
                continue
            }
            if (text.startsWith(marker, k) && k > from && !text[k - 1].isWhitespace()) {
                val after = k + len
                val longer = after < n && text[after] == ch // part of a longer run: not ours
                val wordAfter = ch == '_' && after < n && text[after].isLetterOrDigit()
                if (!longer && !wordAfter) return k
                k += len
                continue
            }
            k++
        }
        return -1
    }

    private fun merge(spans: List<MdSpan>): List<MdSpan> {
        val out = ArrayList<MdSpan>()
        for (s in spans) {
            if (s.text.isEmpty()) continue
            val last = out.lastOrNull()
            if (last != null && last.copy(text = "") == s.copy(text = "")) out[out.size - 1] = last.copy(text = last.text + s.text)
            else out.add(s)
        }
        return out
    }
}

/** What a single line of a prose block is, for rendering. */
sealed interface MdLine {
    data class Heading(val level: Int, val text: String) : MdLine
    data class Bullet(val level: Int, val marker: String, val text: String) : MdLine
    data class Quote(val depth: Int, val text: String) : MdLine
    object Rule : MdLine
    data class Plain(val text: String) : MdLine

    companion object {
        private val HEADING = Regex("^\\s{0,3}(#{1,6})\\s+(.*?)\\s*#*\\s*$")
        private val LIST = Regex("^(\\s*)(?:([-*+•])|(\\d{1,3}[.)]))\\s+(.*)$")
        private val QUOTE = Regex("^\\s*((?:>\\s?)+)(.*)$")
        private val RULE = Regex("^\\s{0,3}([-*_])(?:\\s*\\1){2,}\\s*$")

        fun classify(line: String): MdLine {
            HEADING.matchEntire(line)?.let { return Heading(it.groupValues[1].length, it.groupValues[2]) }
            if (RULE.matches(line)) return Rule
            QUOTE.matchEntire(line)?.let { return Quote(it.groupValues[1].count { c -> c == '>' }, it.groupValues[2]) }
            LIST.matchEntire(line)?.let {
                val level = (it.groupValues[1].replace("\t", "    ").length / 2).coerceAtMost(4)
                val ordered = it.groupValues[3]
                val marker = when {
                    ordered.isNotEmpty() -> ordered
                    level == 0 -> "•"
                    level == 1 -> "◦"
                    else -> "▪"
                }
                return Bullet(level, marker, it.groupValues[4])
            }
            return Plain(line)
        }
    }
}

/** GitHub-style pipe tables, shown as aligned monospace text. */
object MarkdownTable {
    private val SEPARATOR = Regex("^\\s*\\|?\\s*:?-{1,}:?\\s*(\\|\\s*:?-{1,}:?\\s*)*\\|?\\s*$")

    fun isRow(line: String): Boolean {
        val t = line.trim()
        return t.startsWith("|") && t.count { it == '|' } >= 2
    }

    fun isSeparator(line: String): Boolean = line.contains('-') && line.contains('|') && SEPARATOR.matches(line)

    /** If a table starts at [start] (a header row followed by a separator row), its rows and the index after it. */
    fun collect(lines: List<String>, start: Int): Pair<List<List<String>>, Int>? {
        if (start + 1 >= lines.size || !isRow(lines[start]) || !isSeparator(lines[start + 1])) return null
        val rows = ArrayList<List<String>>()
        rows.add(cells(lines[start]))
        var k = start + 2
        while (k < lines.size && isRow(lines[k])) {
            rows.add(cells(lines[k]))
            k++
        }
        return Pair(rows, k)
    }

    fun cells(line: String): List<String> {
        var t = line.trim()
        if (t.startsWith("|")) t = t.substring(1)
        if (t.endsWith("|") && !t.endsWith("\\|")) t = t.substring(0, t.length - 1)
        val out = ArrayList<String>()
        val cur = StringBuilder()
        var i = 0
        while (i < t.length) {
            if (t[i] == '\\' && i + 1 < t.length && t[i + 1] == '|') {
                cur.append('|')
                i += 2
            } else if (t[i] == '|') {
                out.add(cur.toString().trim())
                cur.setLength(0)
                i++
            } else {
                cur.append(t[i])
                i++
            }
        }
        out.add(cur.toString().trim())
        return out
    }

    fun format(rows: List<List<String>>): String {
        if (rows.isEmpty()) return ""
        val cols = rows.maxOf { it.size }
        val cells = rows.map { r -> List(cols) { c -> InlineMarkdown.plain(r.getOrElse(c) { "" }) } }
        fun width(s: String) = s.codePointCount(0, s.length)
        val widths = IntArray(cols) { c -> cells.maxOf { width(it[c]) } }
        val sb = StringBuilder()
        cells.forEachIndexed { idx, row ->
            val line = row.indices.joinToString("  │  ") { c -> row[c] + " ".repeat(widths[c] - width(row[c])) }
            sb.append(line.trimEnd()).append('\n')
            if (idx == 0) sb.append(widths.joinToString("──┼──") { "─".repeat(it) }).append('\n')
        }
        return sb.toString().trimEnd('\n')
    }
}
