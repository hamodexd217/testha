<script lang="ts">
	import HoverCardPortal from './hover-card-portal.svelte';
	import { cn, type WithoutChildrenOrChild } from '$lib/components/ui/utils.js';
	import { LinkPreview as HoverCardPrimitive } from 'bits-ui';
	import type { ComponentProps } from 'svelte';

	let {
		align = 'center',
		class: className,
		portalProps,
		ref = $bindable(null),
		sideOffset = 4,
		...restProps
	}: HoverCardPrimitive.ContentProps & {
		portalProps?: WithoutChildrenOrChild<ComponentProps<typeof HoverCardPortal>>;
	} = $props();
</script>

<HoverCardPortal {...portalProps}>
	<HoverCardPrimitive.Content
		bind:ref
		{align}
		class={cn(
			'data-open:animate-in data-closed:animate-out data-closed:fade-out-0 data-open:fade-in-0 data-closed:zoom-out-95 data-open:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 ring-foreground/10 bg-popover text-popover-foreground w-64 rounded-lg p-2.5 text-sm shadow-md ring-1 duration-100 z-50 origin-(--transform-origin) outline-hidden',
			className
		)}
		data-slot="hover-card-content"
		{sideOffset}
		{...restProps}
	/>
</HoverCardPortal>
