# Direct GGUF path access fix

Date: 2026-10-16

## Root cause

The Models screen's `Register path` action passed the user's typed absolute path directly to `File.canRead()`, but the app did not declare or route the user through Android's special shared-storage access permission. `Import GGUF file(s)` worked because it uses the Android Storage Access Framework picker, which provides a temporary/persistable URI grant; that grant does not automatically authorize arbitrary typed `/storage/emulated/0/...` paths.

## Changes

- Declared `MANAGE_EXTERNAL_STORAGE` for the explicit opt-in, no-copy absolute-path workflow on Android 11+.
- The Models screen now detects when a typed path is under shared storage. If all-files access is not granted, the button becomes `Grant path access` and opens Android's app-specific all-files-access settings page.
- On return from Settings, the app checks the grant and automatically retries registering the typed path if access was granted. No model copy is initiated by this path.
- Added the legacy Android 10 `READ_EXTERNAL_STORAGE` permission/request path.
- Improved path validation errors: relative path, missing file, directory path, and unreadable path now have different actionable messages.
- Added unit test cases for absolute paths with spaces and rejecting relative paths.

## How to use

1. Install the newly built APK.
2. Open Models and enter the exact absolute path, for example `/storage/emulated/0/the ai thingy/Qwen3.5-4B-Q4_K_M.gguf`.
3. Tap `Grant path access` and enable **Allow access to manage all files** in Android Settings.
4. Return to the app. Registration retries automatically. If it does not, tap `Register path` again.
5. If registration says the file is missing, check the path and exact filename. Spaces in a path are supported.

The grant permits broad access to shared storage, so it is requested only as part of the user's direct-path action. It is distinct from the ordinary app-permissions screen. `Import GGUF file(s)` remains available and copies selected files to app-private storage.

## Validation and limitations

- AndroidManifest XML parse: passed.
- Repository Kotlin sanity script: it does not report `ModelScreen.kt`; it reports existing issues elsewhere, including an existing `cancel` import/use finding in `ModelViewModel.kt`.
- Gradle unit tests / APK build: not run successfully in this environment because Gradle 8.9 could not be downloaded (`UnknownHostException: services.gradle.org`). The changes still need a GitHub Actions or Android Studio build and an on-device test.
- `MANAGE_EXTERNAL_STORAGE` is restricted by Google Play policy and may not be accepted for Play Store distribution. Verify the current policy if distributing through Google Play. It is included here to support the explicitly requested no-copy absolute-path feature in manually installed builds.
- On shared/emulated storage, the engine may use buffered I/O fallback; permission enables access but does not guarantee I/O performance matching app-private storage.
