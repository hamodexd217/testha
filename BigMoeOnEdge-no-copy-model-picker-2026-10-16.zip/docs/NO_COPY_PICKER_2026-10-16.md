# No-copy GGUF picker

Date: 2026-10-16

## Behavior

- The Models screen's primary action is **Add GGUF from storage (no copy)**.
- It opens Android's document picker. When the picked URI is from `com.android.externalstorage.documents`, the app safely maps its document ID to the real path in the shared storage volume, then validates and registers that path through `ModelManager.registerExistingPath`.
- On Android 11+, the first selection may open the app-specific **Allow access to manage all files** settings page. On return, registration retries automatically. No GGUF bytes are copied by this path.
- **Import GGUF file(s) (copy)** remains available for providers that expose only a `content://` URI (such as cloud/virtual providers) or if users prefer app-private storage.
- Manual absolute-path registration remains under **Advanced: enter a path manually**.
- The path resolver rejects non-ExternalStorage DocumentsProvider URIs and path traversal attempts instead of guessing arbitrary provider paths.

## Limitations / validation

- The native model loader requires a real filesystem path, so this does not make every cloud or Downloads provider compatible with zero-copy loading. For those sources, use the copy option.
- Shared/emulated-storage reads can be slower than app-private internal storage and the app must have access to the shared path. This change avoids duplicate disk usage; it does not guarantee faster model generation.
- Static project sanity script was run. It reports existing unrelated findings in GenerationForegroundService.kt, GenerationManager.kt, ChatViewModel.kt, ModelViewModel.kt and ToolPerformanceTest.kt; it did not report ModelScreen.kt.
- Gradle compilation could not be run because Gradle 8.9 is not cached and the environment cannot reach `services.gradle.org` (`UnknownHostException`). A CI/Android Studio build and on-device test are still needed.
