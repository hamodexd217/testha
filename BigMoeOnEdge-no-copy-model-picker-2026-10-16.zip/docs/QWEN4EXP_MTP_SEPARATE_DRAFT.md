# Qwen4Exp / Qwen3.8-Flash-Next: separate MTP draft GGUF

This build adds a separate Qwen4Exp MTP-only GGUF sidecar. The sidecar is a draft head, not a second full target model. For a sidecar intended to borrow the target vocabulary embeddings and LM head, convert it with `--mtp --mtp-shared-embd` using a full upstream `llama.cpp` checkout that has the Qwen4Exp converter support. The vendored Android tree is pruned and does not include the `gguf-py` Python package, so it is not a complete standalone checkpoint-conversion environment.

## Prepare files

Use the same Hugging Face checkpoint and tokenizer for both conversions. For example, with the matching upstream converter installed and dependencies available:

```bash
# Main target without the embedded draft block (optional but avoids storing the MTP tensors twice)
python convert_hf_to_gguf.py /path/to/Qwen3.8-Flash-Next \
  --outtype bf16 --no-mtp --outfile /output/Qwen3.8-Flash-Next.gguf

# Separate MTP-only sidecar with shared token embeddings and output head
python convert_hf_to_gguf.py /path/to/Qwen3.8-Flash-Next \
  --outtype bf16 --mtp --mtp-shared-embd \
  --outfile /output/mtp-Qwen3.8-Flash-Next-shared-BF16.gguf
```

These commands demonstrate the intended converter flags; they have **not** been run against a real Qwen3.8-Flash-Next checkpoint in this environment. Use matching quantization and architecture support appropriate to the source checkpoint. Do not rename an ordinary full model to look like an MTP sidecar: native loading validates the model architecture and MTP block, and llama.cpp's speculative initializer checks vocabulary compatibility.

## Add files in the app

1. Open **Models** and choose **Import GGUF file(s) (copy)**. Select the target GGUF. For a split target, select *all* shards together in one multi-selection. The app stages the files, checks GGUF headers and shard numbering/metadata, then makes the set visible as one model. Import needs enough private app storage for the copied files.
2. Import the sidecar GGUF with a name containing `mtp-` (for example the name above). It appears under **MTP draft sidecars**, not in the target list.
3. On the target model row, choose **MTP draft →** the sidecar. The attachment is saved for that target path.
4. In **Settings → Guess ahead**, select **MTP** and enable **Use a separate MTP GGUF**. Then load the target model.

A separate draft is supported only with a `qwen4exp` target in this build. The target MoE model keeps Expert Streaming enabled: only its own GGUF's expert tensors are routed through the target stream. The separate sidecar is loaded with ordinary mmap because it has its own GGUF and tensor offsets; its own MTP-layer tensors are not yet handled by the expert-stream source and may add resident/page-cache memory. This avoids forcing the entire target MoE model into ordinary mmap mode, but it does not claim that the sidecar's own experts are streamed. If the sidecar fails to load or is incompatible, the app retries the target without speculation and reports a visible warning rather than pretending MTP is active.

## Split GGUF management

The multi-file picker can copy a complete numbered split set (`-00001-of-000NN.gguf` through the final shard). Selecting one shard or a partial set is rejected. The model list exposes only shard 1, loading is preflight-checked, and rename/delete operations apply to the whole in-app set. The advanced absolute-path registration option remains available where Android grants direct filesystem access; Android scoped-storage rules can make arbitrary paths under `Download` unreadable, so using the document picker is the dependable option when enough storage is available.
