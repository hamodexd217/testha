# Separate MTP + Expert Streaming compatibility update

Date: 2026-10-16

## Behavior changes

- Removed the JNI-level rejection of simultaneous separate-MTP and expert-streaming requests.
- Removed the session-level rejection of that combination.
- Kept the normal automatic load policy for the target: MoE models still enable expert streaming even when a separate MTP sidecar is selected.
- During the streaming capture warm-up, the target graph is captured as before. The independent sidecar graph is not sent through the target model's router hook because its tensor names/offsets belong to a different GGUF.
- Updated Settings copy to explain the memory trade-off accurately.

## Current boundary

The main target model's MoE experts continue to use Expert Streaming. The separate MTP sidecar is loaded through ordinary mmap; its own MTP-layer expert tensors are not yet served by an independent expert-stream source. That may add memory/page-cache use, but the app no longer opts the entire target model out of expert streaming merely because a sidecar is attached.

Do not claim the sidecar's own experts are streamed. Adding that would require a second source/router-hook bound to the sidecar GGUF's own file offsets and tensors.

## Validation performed

- CMake configuration for the Android native source tree succeeded on the Linux host after supplying a placeholder `log-lib` for the host-only configure.
- C++ syntax-only check of `core/src/engine/session.cpp`: passed.
- C++ syntax-only check of `native-bridge.cpp` with local JNI/Android-log header stubs: passed. This is not an Android NDK link/build.
- The repository Kotlin sanity script reports 29 pre-existing findings in unrelated files (`GenerationForegroundService.kt`, `GenerationManager.kt`, `ChatViewModel.kt`, and `ModelViewModel.kt`); it reported no findings in the three modified Kotlin files.
- Full Android APK build and device runtime test were not performed: this environment has no Android SDK/NDK configured. The host llama library build did not finish within the available command time.
