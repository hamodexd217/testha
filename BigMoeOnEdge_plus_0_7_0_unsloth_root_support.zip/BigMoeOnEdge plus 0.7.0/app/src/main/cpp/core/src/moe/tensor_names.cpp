#include "tensor_names.h"

#include <atomic>

namespace bmoe::tensor_names {

namespace {

// Published once per model load and then only read. A replaced table is leaked on purpose (a few hundred bytes per
// load): a reader on another thread may still hold the old pointer, and nothing frees under it.
std::atomic<const std::vector<int> *> g_slot_map{nullptr};

constexpr std::string_view k_block_prefix = "blk.";
constexpr std::string_view k_weight_tail = ".weight";

// What the fitter's per-layer expert pattern looks like around its index, as common/fit.cpp spells
// it. Both halves are regex source text: an escaped dot each, and the alternation that covers every
// expert projection layout the loader knows.
constexpr std::string_view k_override_head = "blk\\.";
constexpr std::string_view k_override_tail = "\\.ffn_(up|down|gate_up|gate)_(ch|)exps";
// What every per-layer FFN pattern of the fitter's starts with after the index: the whole FFN, a
// share of it, or the experts alone.
constexpr std::string_view k_ffn_tail = "\\.ffn_";

// A layer index past this is a runaway digit run, not a layer.
constexpr int k_layer_max = 1 << 20;

// The digits at `p` up to the first non-digit, as a layer index: -1 when there are none or too
// many. `end` is set past the last digit.
int leading_layer(const char * p, const char ** end) {
    if (*p < '0' || *p > '9') return -1;
    int il = 0;
    for (; *p >= '0' && *p <= '9'; ++p) {
        il = il * 10 + (*p - '0');
        if (il > k_layer_max) return -1;
    }
    *end = p;
    return il;
}

// As above, with nothing allowed after the digits.
int whole_layer(const char * p) {
    const char * end = nullptr;
    const int il = leading_layer(p, &end);
    return il >= 0 && *end == '\0' ? il : -1;
}

bool starts_with(const char * s, std::string_view prefix) {
    return std::strncmp(s, prefix.data(), prefix.size()) == 0;
}

} // namespace

int block_layer(const char * name, const char ** rest) {
    if (!starts_with(name, k_block_prefix)) return -1;
    const char * end = nullptr;
    const int il = leading_layer(name + k_block_prefix.size(), &end);
    if (il < 0 || *end != '.') return -1;
    if (rest) *rest = end + 1;
    return il;
}

std::string_view weight_suffix(const char * name, int & il_out) {
    const char * rest = nullptr;
    const int il = block_layer(name, &rest);
    if (il < 0) return {};
    const size_t len = std::strlen(rest);
    if (len <= k_weight_tail.size() || k_weight_tail != rest + (len - k_weight_tail.size())) return {};
    il_out = il;
    return std::string_view(rest, len - k_weight_tail.size());
}

void set_slot_map(const std::vector<int> & stored_layer_of_slot) {
    g_slot_map.store(new std::vector<int>(stored_layer_of_slot), std::memory_order_release);
}

void clear_slot_map() {
    g_slot_map.store(nullptr, std::memory_order_release);
}

int stored_layer(int slot) {
    const std::vector<int> * map = g_slot_map.load(std::memory_order_acquire);
    return map && slot >= 0 && (size_t) slot < map->size() ? (*map)[(size_t) slot] : slot;
}

int node_layer(const char * name, std::string_view prefix) {
    if (!starts_with(name, prefix)) return -1;
    const int il = whole_layer(name + prefix.size());
    return il < 0 ? il : stored_layer(il);
}

int any_node_layer(const char * name) {
    const char * dash = std::strrchr(name, '-');
    if (!dash) return -1;
    const int il = whole_layer(dash + 1);
    return il < 0 ? il : stored_layer(il);
}

int weight_node(const char * name, int & il_out) {
    for (int v = 0; v < k_weight_node_count; ++v) {
        const std::string_view n = k_weight_nodes[v];
        if (!starts_with(name, n) || name[n.size()] != '-') continue;
        const int il = whole_layer(name + n.size() + 1);
        if (il < 0) continue;
        il_out = stored_layer(il);
        return v;
    }
    return -1;
}

std::string expert_override_pattern(int il) {
    return std::string(k_override_head) + std::to_string(il) + std::string(k_override_tail);
}

int expert_override_layer(const char * pattern) {
    // Found anywhere, not only at the start: what is asked is whether the pattern names that
    // layer's experts, and the fitter's form can be one part of a longer pattern.
    for (const char * at = std::strstr(pattern, k_override_head.data()); at;
         at = std::strstr(at + 1, k_override_head.data())) {
        const char * end = nullptr;
        const int il = leading_layer(at + k_override_head.size(), &end);
        if (il >= 0 && starts_with(end, k_override_tail)) return il;
    }
    return -1;
}

int ffn_override_layer(const char * pattern) {
    for (const char * at = std::strstr(pattern, k_override_head.data()); at;
         at = std::strstr(at + 1, k_override_head.data())) {
        const char * end = nullptr;
        const int il = leading_layer(at + k_override_head.size(), &end);
        if (il >= 0 && starts_with(end, k_ffn_tail)) return il;
    }
    return -1;
}

} // namespace bmoe::tensor_names
