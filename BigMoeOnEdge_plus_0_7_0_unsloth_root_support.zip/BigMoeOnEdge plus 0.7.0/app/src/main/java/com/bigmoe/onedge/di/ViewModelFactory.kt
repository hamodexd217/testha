package com.bigmoe.onedge.di

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.bigmoe.onedge.ui.chat.ChatViewModel
import com.bigmoe.onedge.ui.files.FileViewModel
import com.bigmoe.onedge.ui.history.HistoryViewModel
import com.bigmoe.onedge.ui.models.ModelViewModel
import com.bigmoe.onedge.ui.settings.AutoTuneViewModel
import com.bigmoe.onedge.ui.settings.SettingsViewModel

class AppViewModelFactory(
    private val container: AppContainer
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(ChatViewModel::class.java) -> ChatViewModel(
                repository = container.chatRepository,
                settingsDataStore = container.settingsDataStore,
                engineController = container.engineController,
                toolManager = container.toolManager,
                artifactRepository = container.artifactRepository,
                attachmentManager = container.attachmentManager,
                workspace = container.workspace,
                composerStore = container.chatComposerDataStore,
                generationManager = container.generationManager
            ) as T
            modelClass.isAssignableFrom(HistoryViewModel::class.java) ->
                HistoryViewModel(repository = container.chatRepository, composerStore = container.chatComposerDataStore, generationManager = container.generationManager) as T
            modelClass.isAssignableFrom(SettingsViewModel::class.java) -> SettingsViewModel(
                dataStore = container.settingsDataStore,
                engineController = container.engineController,
                modelManager = container.modelManager,
                apiServer = container.apiServerController
            ) as T
            modelClass.isAssignableFrom(AutoTuneViewModel::class.java) -> AutoTuneViewModel(
                dataStore = container.settingsDataStore,
                engineController = container.engineController,
                modelManager = container.modelManager,
                store = container.autoSaveStore,
                scanner = container.deviceScanner,
                contentResolver = container.contentResolver
            ) as T
            modelClass.isAssignableFrom(ModelViewModel::class.java) -> ModelViewModel(
                modelManager = container.modelManager,
                engineController = container.engineController,
                settingsDataStore = container.settingsDataStore,
                autoSaveStore = container.autoSaveStore,
                totalRamBytes = { container.totalRamBytes() }
            ) as T
            modelClass.isAssignableFrom(FileViewModel::class.java) -> FileViewModel(
                workspace = container.workspace,
                artifactRepository = container.artifactRepository,
                javaScriptRunner = container.javaScriptRunner
            ) as T
            else -> throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
