package com.bigmoe.onedge.core

/**
 * Which GGUF architectures the bundled engine can build, and plain-language messages when a model is not one of them.
 * Pure Kotlin (unit-tested). The authority is always the native loader; this only improves what the user reads.
 */
object ModelFamilies {

    /** Architectures present in the vendored llama.cpp that matter for the families users ask about by name. */
    data class Family(
        val name: String,
        val architectures: Set<String>,
        val note: String,
        /**
         * False when the architecture is recognised (names, memory model, messages) but the bundled native engine
         * cannot build its graph, so loading fails with a clear explanation instead of being offered as supported.
         */
        val builtIn: Boolean = true,
        /** False while the bundled graph has only been compile-checked, never run on a device. */
        val verified: Boolean = true
    )

    val LIQUID_LFM2 = Family(
        name = "Liquid LFM2 / LFM2.5",
        architectures = setOf("lfm2", "lfm2moe"),
        note = "Dense (lfm2) models load normally; the MoE variants (lfm2moe, e.g. 8B-A1B, 24B-A2B) use expert streaming."
    )

    val LIQUID_LFM3 = Family(
        name = "Liquid LFM3",
        architectures = setOf("lfm3"),
        note = "Dense hybrid (short-convolution + sliding/global attention). Vision models (LFM3-VL) also need the " +
            "matching mmproj file, whose projector type is lfm3vl. Audio / omni / decision variants are not supported."
    )

    val FLINT = Family(
        name = "Flint",
        architectures = setOf("flint"),
        note = "MoE with leading dense blocks and a shared expert; expert streaming is registered. CPU first, NPU unverified."
    )

    /**
     * Thinking Machines Lab Inkling 2 Mini (`inkling2_loop`): 24 layers of weights, layers 6..17 applied three times per
     * token (48 layer visits), 128 experts / 8 routed, hybrid sliding-window + global attention, 1M context, image input
     * through an mmproj. Sources: the model card and config.json of thinkingmachines/Inkling-2-Mini, llama.cpp PR #32694.
     *
     * The native engine contains its graph (llama.cpp PRs #32217, #32429, #32657, #32694, #32704, the Inkling chat parser
     * #32381, Jinja `sort_keys` #32366, the vision tower and tokenizer changes), adapted to the older mask API of the
     * vendored tree, and the streaming hook maps looped cache slots to their stored layer. It has been compile-checked on
     * a host and its chat template rendered there, but NOT loaded or run on a device, so [verified] is false.
     */
    val INKLING_2_MINI = Family(
        name = "Thinking Machines Inkling 2 Mini",
        architectures = setOf("inkling2_loop", "inkling2"),
        note = "Supports both GGUF layouts: mainline inkling2_loop and Unsloth-root inkling2 (legacy per-visit metadata/tensors). " +
            "Looped MoE (layers 6-17 run 3 times per token), image input via mmproj, reasoning effort levels. Native " +
            "support is compiled in but has not run on a device yet. Speculation: it ships a DSpark drafter, not an MTP head.",
        verified = false
    )

    val NAMED = listOf(LIQUID_LFM2, LIQUID_LFM3, FLINT, INKLING_2_MINI)

    /** The families whose graph the bundled native engine really contains. */
    val BUILT_IN: List<Family> get() = NAMED.filter { it.builtIn }

    fun familyOf(architecture: String): Family? {
        val a = architecture.trim().lowercase()
        return NAMED.firstOrNull { a in it.architectures }
    }

    private val UNKNOWN_ARCH = Regex("unknown model architecture:?\\s*'([^']*)'", RegexOption.IGNORE_CASE)

    /** The architecture named in a native "unknown model architecture: 'x'" error, or null for any other error. */
    fun unknownArchitectureIn(error: String): String? =
        UNKNOWN_ARCH.find(error)?.groupValues?.get(1)?.trim()?.takeIf { it.isNotEmpty() }

    /**
     * Turns the loader's raw failure into something readable. Errors that are not about an unknown architecture are
     * returned unchanged.
     */
    fun explainLoadError(error: String, summary: GgufSummary? = null): String {
        if (error.contains("fastrpc_mmap", ignoreCase = true) || error.contains("fastrpc", ignoreCase = true) && error.contains("mmap", ignoreCase = true)) {
            return error + "\n\nThe NPU (Hexagon) could not map enough memory for this model. Turn off NPU prefill for it in Settings, " +
                "or lower the context size (the NPU also holds the model's context state), or use a smaller quantisation."
        }
        // The Unsloth-root layout is explained whatever the failure says: it fails differently on different engines.
        if (summary != null && summary.loop?.layout == LoopLayout.PER_VISIT) {
            inklingLoadHint(summary.architecture.lowercase(), summary)?.let { return it + "\n\nEngine message: " + error }
        }
        val arch = unknownArchitectureIn(error) ?: return error
        val a = arch.lowercase()
        inklingLoadHint(a, summary)?.let { return it }
        val lfm = a.startsWith("lfm") && BUILT_IN.none { a in it.architectures }
        val supported = BUILT_IN.joinToString("; ") { "${it.name} (${it.architectures.joinToString(", ")})" }
        return buildString {
            append("This engine build does not know the '").append(arch).append("' architecture, so the model cannot be loaded. ")
            if (lfm) append("Only LFM2 / LFM2.5 / LFM3 are built in; a newer Liquid generation needs its model graph added to the native engine first. ")
            else append("A newer model family needs its graph added to the native engine first. ")
            append("Built in for the families you asked about: ").append(supported).append(". ")
            append("Updating the vendored llama.cpp source (and rebuilding the APK) is what adds a new architecture.")
        }
    }

    // ── Inkling ─────────────────────────────────────────────────────────────────────────────────────────────

    private val INKLING_ARCHS = setOf("inkling", "inkling2", "inkling2_loop")

    fun isInklingArchitecture(architecture: String): Boolean = architecture.trim().lowercase() in INKLING_ARCHS

    /** What to tell the user when the native loader rejected an Inkling-family architecture. Null for any other one. */
    internal fun inklingLoadHint(archLower: String, summary: GgufSummary?): String? {
        // The Unsloth-root layout (one block per layer visit) is read through a compatibility mode that is untested on real files.
        if (summary != null && summary.loop?.layout == LoopLayout.PER_VISIT) {
            return "This is the Unsloth-style looped Inkling 2 layout ('inkling2' with one block per layer visit). The engine " +
                "reads it in a compatibility mode (per-visit settings folded to the stored layers, controls under their older " +
                "names) that has not been tried on a real file yet, and the load failed. The files in the Mainline_Support " +
                "folder of unsloth/Inkling-2-Mini-GGUF (rename .gguf_file to .gguf) or ggml-org's Inkling-2-Mini GGUF use the " +
                "layout the engine was written for. See docs/INKLING_2_MINI.md."
        }
        return when (archLower) {
            "inkling2_loop" ->
                "Inkling 2 Mini ('inkling2_loop') was not recognised by the native engine, so this build does not contain " +
                    "the Inkling 2 support it is meant to ship with (docs/INKLING_2_MINI.md lists the llama.cpp changes it " +
                    "needs). Nothing is wrong with the file."
            "inkling2" ->
                "The 'inkling2' architecture (Inkling 2 without a loop) was not recognised by the native engine. Inkling " +
                    "2 Mini uses 'inkling2_loop'. See docs/INKLING_2_MINI.md."
            "inkling" ->
                "The 'inkling' architecture is the original Inkling model (and its MTP sidecars), not Inkling 2 Mini, and " +
                    "is not supported by this engine build."
            else -> null
        }
    }

    /**
     * Why self-speculation through the engine's MTP source cannot be used with a model of this architecture, or null when
     * nothing is known against it (the engine still checks the file itself).
     *
     * Inkling 2 Mini's `mtp.safetensors` (config `mtp_config`) is a 3-layer DSpark block drafter (block size 8, Markov
     * head) that reads hidden states of looped layer visits [5, 23, 41, 48]. It is not a nextn/MTP block of the target,
     * which is all [SpecSource.MTP] drives. The separate `meshllm/Inkling-MTP-*` sidecar is arch `inkling` for the original
     * Inkling and does not match Mini either.
     */
    fun mtpIncompatibleReason(architecture: String): String? = when (architecture.trim().lowercase()) {
        "inkling2_loop", "inkling2" ->
            "Inkling 2 Mini ships a DSpark block drafter, not a nextn/MTP head, so the MTP source cannot use it. " +
                "Speculation was turned off for this load."
        "inkling" ->
            "Inkling MTP sidecars belong to the original Inkling model and do not match Inkling 2 Mini. " +
                "Speculation was turned off for this load."
        else -> null
    }

    /**
     * Inkling 2 Mini's real attention-cache geometry, from the official config.json (24 layers, 8 KV heads x 128,
     * sliding window 1024, global layers 5/11/17/23, loop 6..18 x 3). Returned only when the header matches that
     * model exactly; any other file keeps the generic size-based memory estimate.
     */
    fun kvLayoutFor(summary: GgufSummary): KvLayout? {
        val loop = summary.loop ?: return null
        val arch = summary.architecture.lowercase()
        // the mainline layout stores 24 blocks; the earlier Unsloth layout counts 48 layer visits in block_count
        val stored = loop.physicalLayers(summary.blockCount)
        val archOk = when (loop.layout) {
            LoopLayout.PHYSICAL -> arch == "inkling2_loop"
            LoopLayout.PER_VISIT -> arch == "inkling2"
        }
        if (!archOk || stored != INKLING_MINI_LAYERS || summary.expertCount != INKLING_MINI_EXPERTS) return null
        if (loop.start != 6 || loop.end != 18 || loop.passes != 3) return null
        fun visits(layer: Int) = if (layer in loop.start until loop.end) loop.passes else 1
        val global = INKLING_MINI_GLOBAL_LAYERS.sumOf { visits(it) }
        val total = loop.layerVisits(summary.blockCount)
        return KvLayout(
            globalVisits = global,
            localVisits = total - global,
            kvHeads = 8,
            headDim = 128,
            windowTokens = 1024
        )
    }

    /**
     * Active parameters per token including every pass (5.4B) over the single-pass figure (3.4B), from the model card.
     * Applied to a plan's per-token work; 0.0 for any other model (the layer-visit ratio is used instead).
     */
    fun loopWorkFactorFor(summary: GgufSummary): Double =
        if (kvLayoutFor(summary) != null) 5.4 / 3.4 else 0.0

    private const val INKLING_MINI_LAYERS = 24
    private const val INKLING_MINI_EXPERTS = 128
    private val INKLING_MINI_GLOBAL_LAYERS = listOf(5, 11, 17, 23)
}
