# Model loading (Phase 4)

Verified against upstream `examples/android` (v0.24.0):
* Models must be on a real filesystem path: the engine streams experts with `O_DIRECT`. In-app copies land in
  `filesDir/models` (f2fs/ext4). Files read from emulated external storage fall back to buffered I/O.
* Upstream picks the first shard of split models (`-00001-of-0000N.gguf`); siblings are found next to it.
  The model list here hides shards other than the first.
* Upstream defaults: 4 I/O lanes, 4 compute threads, dense weights = anon, expert cache 2000 MiB fixed (auto is
  optional). This app's defaults: auto cache with a 1536 MB RAM floor, 4/4, anon.
* Some models (e.g. Qwen3.8-Flash-Next) need *Pinned* dense weights and a small cache (1000–1500 MiB on 12 GB).

Flow: Models screen → pick `.gguf` (copied with progress, cancellable, space checked) or `adb push` into the
folder shown on screen → "Load" → pre-flight (GGUF magic, RAM < 6 GB warning, cache > 60 % RAM warning, Pinned
warning) → confirm → `Session::open` on the IO dispatcher. The engine reports no progress, so the UI shows an
indeterminate bar. The last loaded path is persisted; "load on app start" is optional (off by default).

Load-time settings (context, sampling, threads, cache, dense weights) are fixed by `Session::open`. Settings
shows "needs reload" and the Models screen offers "Reload".

Heuristic thresholds (6 GB RAM, 60 %) are this project's, not upstream requirements.

## Direct paths on Android 11+

The advanced **Register path (no copy)** action uses an absolute filesystem path instead of the Storage Access Framework's `content://` URI. On Android 11 and newer, Android generally blocks arbitrary shared-storage paths until the user explicitly grants this app **Allow access to manage all files** in the system settings page. The Models screen's **Grant path access** button opens that page and retries registration after returning. Registration validates the exact path and GGUF header and does not copy the file. If the user does not grant access, the Import action remains available and copies the selected file into app-private storage.

The app declares `MANAGE_EXTERNAL_STORAGE` solely to support this opt-in large-file/no-copy workflow. This is a restricted Android permission and may not be accepted for distribution through Google Play; distribution channels must comply with Google's current all-files-access policy. Direct reads from emulated/shared storage can also fall back to buffered I/O, so permission enables access but does not guarantee the same I/O performance as app-private storage.

