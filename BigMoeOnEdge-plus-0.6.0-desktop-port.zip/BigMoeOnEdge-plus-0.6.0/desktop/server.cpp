#include "bmoe/session.h"
#include "httplib.h"
#include <nlohmann/json.hpp>

#include <cstdlib>
#include <iostream>
#include <mutex>
#include <string>

using json = nlohmann::json;

namespace {
const char * kUi = R"HTML(<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>BigMoeOnEdge+</title><style>
:root{color-scheme:dark;font:16px system-ui;background:#111318;color:#e9eaf0}body{max-width:850px;margin:0 auto;padding:24px}h1{font-size:1.5rem}#log{white-space:pre-wrap;min-height:55vh;border:1px solid #343843;border-radius:14px;padding:16px;background:#191c23}form{display:flex;gap:8px;margin-top:12px}textarea{flex:1;min-height:70px;resize:vertical;background:#20242d;color:inherit;border:1px solid #444b59;border-radius:10px;padding:12px}button{background:#5c78ff;color:white;border:0;border-radius:10px;padding:0 18px;font-weight:650}small{color:#aab0bd}
</style></head><body><h1>BigMoeOnEdge+</h1><small>Experimental desktop host · local loopback only</small><div id="log" aria-live="polite">Ready. Enter a message below.</div><form id="form"><textarea id="prompt" placeholder="Message your local model…" required></textarea><button id="send">Send</button></form><script>
const log=document.querySelector('#log'),form=document.querySelector('#form'),promptBox=document.querySelector('#prompt'),send=document.querySelector('#send');let messages=[];
form.addEventListener('submit',async e=>{e.preventDefault();const text=promptBox.value.trim();if(!text)return;messages.push({role:'user',content:text});log.textContent+='\n\nYou: '+text+'\n\nModel: ';promptBox.value='';send.disabled=true;try{const r=await fetch('/v1/chat/completions',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({model:'local',messages,n_predict:512})});const j=await r.json();if(!r.ok)throw new Error(j.error?.message||'Request failed');const answer=j.choices?.[0]?.message?.content||'';messages.push({role:'assistant',content:answer});log.textContent+=answer;}catch(err){log.textContent+='\n[Error] '+err.message;messages.pop();}finally{send.disabled=false;log.scrollTop=log.scrollHeight;promptBox.focus();}});
</script></body></html>)HTML";

void usage(const char * exe) {
    std::cout << "BigMoeOnEdge+ experimental desktop HTTP/Web UI host\n"
              << "Usage: " << exe << " --model FILE.gguf [--port N] [--ctx N] [--threads N]\n"
              << "Binds to 127.0.0.1 only. Routes: /, /health, /v1/models, /v1/chat/completions\n";
}
bool parse_positive(const char * s, int & out) {
    char * end = nullptr; long v = std::strtol(s, &end, 10);
    if (!s[0] || !end || *end || v < 1 || v > 1000000) return false;
    out = static_cast<int>(v); return true;
}
}

int main(int argc, char ** argv) {
    bmoe::SessionConfig cfg;
    cfg.n_ctx = 4096;
    cfg.chatml = true;
    int port = 8765;
    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--help" || a == "-h") { usage(argv[0]); return 0; }
        if (a == "--model" || a == "--port" || a == "--ctx" || a == "--threads") {
            if (++i >= argc) { std::cerr << "Missing value for " << a << '\n'; return 2; }
            const char * v = argv[i];
            if (a == "--model") cfg.model_path = v;
            else if (a == "--port") { if (!parse_positive(v, port) || port > 65535) { std::cerr << "Invalid port\n"; return 2; } }
            else if (a == "--ctx") { if (!parse_positive(v, cfg.n_ctx)) { std::cerr << "Invalid context\n"; return 2; } }
            else if (a == "--threads") { if (!parse_positive(v, cfg.n_threads)) { std::cerr << "Invalid threads\n"; return 2; } cfg.n_threads_batch = cfg.n_threads; }
            continue;
        }
        std::cerr << "Unknown option: " << a << '\n'; usage(argv[0]); return 2;
    }
    if (cfg.model_path.empty()) { std::cerr << "--model is required\n"; usage(argv[0]); return 2; }

    std::string error;
    auto session = bmoe::Session::open(cfg, error);
    if (!session) { std::cerr << "Model initialization failed: " << error << '\n'; return 1; }

    httplib::Server server;
    std::mutex generation_mutex;
    server.Get("/", [](const httplib::Request &, httplib::Response & res) {
        res.set_content(kUi, "text/html; charset=utf-8");
    });
    server.Get("/health", [](const httplib::Request &, httplib::Response & res) {
        res.set_content("{\"ok\":true,\"engine\":\"BigMoeOnEdge+\"}", "application/json");
    });
    server.Get("/v1/models", [](const httplib::Request &, httplib::Response & res) {
        res.set_content("{\"object\":\"list\",\"data\":[{\"id\":\"local\",\"object\":\"model\"}]}", "application/json");
    });
    server.Post("/v1/chat/completions", [&](const httplib::Request & req, httplib::Response & res) {
        json body;
        try { body = json::parse(req.body); }
        catch (...) { res.status = 400; res.set_content("{\"error\":{\"message\":\"Invalid JSON body\"}}", "application/json"); return; }
        if (!body.contains("messages") || !body["messages"].is_array()) {
            res.status = 400; res.set_content("{\"error\":{\"message\":\"messages must be an array\"}}", "application/json"); return;
        }
        if (body.value("stream", false)) {
            res.status = 400; res.set_content("{\"error\":{\"message\":\"stream=true is not supported by this experimental first version\"}}", "application/json"); return;
        }
        bmoe::GenerateRequest turn;
        turn.chat_messages_json = body["messages"].dump();
        turn.clear_kv = false;
        turn.render_text = true;
        if (body.contains("n_predict") && body["n_predict"].is_number_integer()) {
            int n = body["n_predict"].get<int>(); if (n > 0 && n <= 32768) turn.n_predict = n;
        } else if (body.contains("max_tokens") && body["max_tokens"].is_number_integer()) {
            int n = body["max_tokens"].get<int>(); if (n > 0 && n <= 32768) turn.n_predict = n;
        }
        std::lock_guard<std::mutex> lock(generation_mutex);
        const auto result = session->generate(turn);
        if (!result.ok) {
            res.status = 500;
            res.set_content(json{{"error", {{"message", result.error}}}}.dump(), "application/json");
            return;
        }
        const std::string answer = result.generated_text;
        res.set_content(json{
            {"id", "chatcmpl-bmoe-local"}, {"object", "chat.completion"},
            {"choices", json::array({json{{"index", 0}, {"message", {{"role", "assistant"}, {"content", answer}}}, {"finish_reason", "stop"}}})},
            {"usage", {{"prompt_tokens", 0}, {"completion_tokens", result.summary.n_generated}, {"total_tokens", result.summary.n_generated}}}
        }.dump(), "application/json");
    });

    std::cout << "BigMoeOnEdge+ desktop host ready at http://127.0.0.1:" << port << "/\n";
    std::cout << "Model loaded in " << session->load_seconds() << " seconds. Keep this terminal open.\n";
    if (!server.listen("127.0.0.1", port)) { std::cerr << "Could not listen on loopback port " << port << '\n'; return 1; }
    return 0;
}
