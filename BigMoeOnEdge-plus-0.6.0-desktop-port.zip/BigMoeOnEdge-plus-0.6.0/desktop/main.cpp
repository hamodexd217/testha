#include "bmoe/session.h"

#include <cstdlib>
#include <iostream>
#include <string>

namespace {
void usage(const char * exe) {
    std::cout << "BigMoeOnEdge+ desktop native engine (experimental)\n"
              << "Usage: " << exe << " --model FILE.gguf [options]\n\n"
              << "  --model PATH    GGUF model path (required)\n"
              << "  --prompt TEXT   Prompt text (default: 'Hello!')\n"
              << "  --tokens N      Maximum generated tokens (default: 128)\n"
              << "  --ctx N         Context size (default: 4096)\n"
              << "  --batch N       Prefill batch size (default: 512)\n"
              << "  --threads N     CPU threads (default: detected by engine config = 4)\n"
              << "  --chatml        Format prompt using the model's chat template\n"
              << "  --no-think      Request disabled reasoning in chat-template mode\n"
              << "  --help          Show this help\n";
}
bool parse_int(const char * s, int & out) {
    char * end = nullptr;
    const long v = std::strtol(s, &end, 10);
    if (!s[0] || !end || *end || v < 1 || v > 1000000) return false;
    out = static_cast<int>(v);
    return true;
}
}

int main(int argc, char ** argv) {
    bmoe::SessionConfig cfg;
    cfg.n_ctx = 4096;
    bmoe::GenerateRequest req;
    req.prompt = "Hello!";
    req.n_predict = 128;
    bool no_think = false;
    for (int i = 1; i < argc; ++i) {
        const std::string arg = argv[i];
        if (arg == "--help" || arg == "-h") { usage(argv[0]); return 0; }
        if (arg == "--chatml") { cfg.chatml = true; continue; }
        if (arg == "--no-think") { no_think = true; continue; }
        if (arg == "--model" || arg == "--prompt" || arg == "--tokens" || arg == "--ctx" || arg == "--batch" || arg == "--threads") {
            if (++i >= argc) { std::cerr << "Missing value for " << arg << "\n"; usage(argv[0]); return 2; }
            const std::string value = argv[i];
            if (arg == "--model") cfg.model_path = value;
            else if (arg == "--prompt") req.prompt = value;
            else if (arg == "--tokens") { if (!parse_int(value.c_str(), req.n_predict)) { std::cerr << "Invalid --tokens\n"; return 2; } }
            else if (arg == "--ctx") { if (!parse_int(value.c_str(), cfg.n_ctx)) { std::cerr << "Invalid --ctx\n"; return 2; } }
            else if (arg == "--batch") { if (!parse_int(value.c_str(), cfg.n_batch)) { std::cerr << "Invalid --batch\n"; return 2; } }
            else if (arg == "--threads") { if (!parse_int(value.c_str(), cfg.n_threads)) { std::cerr << "Invalid --threads\n"; return 2; } cfg.n_threads_batch = cfg.n_threads; }
            continue;
        }
        std::cerr << "Unknown option: " << arg << "\n";
        usage(argv[0]);
        return 2;
    }
    if (cfg.model_path.empty()) { std::cerr << "ERROR: --model is required.\n"; usage(argv[0]); return 2; }
    req.think = !no_think;

    std::string error;
    auto session = bmoe::Session::open(cfg, error);
    if (!session) {
        std::cerr << "ERROR: model/session initialization failed: " << error << "\n";
        return 1;
    }
    const auto result = session->generate(req, [](const bmoe::TokenMetrics & token) {
        std::cout << token.piece << std::flush;
    });
    std::cout << "\n";
    if (!result.ok) {
        std::cerr << "ERROR: generation failed: " << result.error << "\n";
        return 1;
    }
    std::cerr << "\n[BigMoeOnEdge+] load=" << session->load_seconds()
              << "s, context=" << session->n_ctx() << " tokens\n";
    return 0;
}
