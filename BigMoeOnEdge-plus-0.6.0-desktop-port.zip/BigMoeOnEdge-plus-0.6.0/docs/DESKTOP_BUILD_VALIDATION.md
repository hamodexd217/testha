# Desktop host build validation

Validation run in the source tree after adding the host CMake entry point:

- Linux x86_64 CMake configure: passed.
- Linux x86_64 native build of `bmoe_core`, `bmoe-desktop`, and `bmoe-desktop-server`: passed.
- `bmoe-desktop --help`: passed.
- `bmoe-desktop-server --help`: passed.
- YAML parse of `.github/workflows/build.yml`, `.github/workflows/update-release.yml`, and `.github/workflows/build-npu-fixed-3.yml`: passed.

Not verified here: Windows/macOS compilation, loading a real GGUF on desktop, model generation,
HTTP chat with a real model, streaming SSE, or Android APK build. Git metadata is not present in the
source ZIP, so llama.cpp's CMake emitted the expected warning that automatic git build information
is unavailable; it did not block the host build.
