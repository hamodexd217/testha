# Desktop portability: first native target

## What this change does

The existing Android application remains Kotlin/Compose + JNI and continues to use
`app/src/main/cpp/CMakeLists.txt`. A new root `CMakeLists.txt` builds the same `bmoe_core`
and the same vendored llama.cpp tree as a host-native executable, `bmoe-desktop`, without
including `native-bridge.cpp`, Android logging, or the Android-only Hexagon build path.

The initial desktop targets are deliberately a native CLI and a minimal local HTTP/Web UI host,
not a port of the entire Helldez product stack. Both open a GGUF through `bmoe::Session` and
use the same model/session implementation as the Android JNI engine. The HTTP host serves a
small browser UI and implements `/health`, `/v1/models`, and a non-streaming
`/v1/chat/completions` endpoint. It binds to `127.0.0.1` only and serializes generation requests.
This validates the important portability boundary first: engine/core vs platform adapter.

## Build locally

```sh
cmake -S . -B build-desktop -DCMAKE_BUILD_TYPE=Release \
  -DBMOE_BUILD_DESKTOP_CLI=ON -DBMOE_DESKTOP_MULTIMODAL=OFF
cmake --build build-desktop --parallel 2
./build-desktop/bin/bmoe-desktop --help
./build-desktop/bin/bmoe-desktop --model /path/to/model.gguf --chatml --prompt "Hello" --tokens 128
./build-desktop/bin/bmoe-desktop-server --model /path/to/model.gguf --port 8765
# Then open http://127.0.0.1:8765/ in a browser
```

Windows PowerShell can use the same CMake configure/build commands; the executable is normally
`build-desktop\bin\bmoe-desktop.exe` (generator may add a configuration subdirectory).

## Platform boundaries and current limitations

- Android JNI and Hexagon remain Android-only.
- Desktop currently builds a CPU host target; backend acceleration depends on the llama.cpp
  backend configuration and must be validated per OS/GPU.
- Multimodal support is off by default for the first desktop target to avoid making a desktop
  build depend on extra media components; `BMOE_DESKTOP_MULTIMODAL=ON` is an opt-in and still
  needs platform testing.
- The initial browser UI is intentionally small: no model downloader, persistence, streaming responses,
  or Android-style settings parity yet. Those should be added as a separate desktop host/UI layer
  using the existing core APIs, rather than linking Android-specific application code into desktop builds.
- The HTTP endpoint currently accepts OpenAI-style `messages` and token budgets, but does not yet
  implement streaming SSE, tool calls, API-key authentication, or full OpenAI protocol parity.
- The CI matrix builds Linux x64, Windows x64, and macOS ARM64 and runs both executables' `--help`.
  That is a compile and CLI smoke test, not proof that a model loads or generates correctly on every OS.
