package com.bigmoe.onedge.ui.artifact

import android.annotation.SuppressLint
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.SheetState
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.bigmoe.onedge.parser.ArtifactModel
import com.bigmoe.onedge.parser.ArtifactType
import java.io.ByteArrayInputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArtifactSheet(
    artifact: ArtifactModel?,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    sheetState: SheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
) {
    if (artifact == null) return

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Code,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.padding(start = 8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = artifact.title, style = MaterialTheme.typography.titleMedium)
                    Text(
                        text = artifact.type.name,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close Artifact")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Box(modifier = Modifier.fillMaxWidth().weight(1f)) {
                ArtifactPreview(artifact = artifact)
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun ArtifactPreview(
    artifact: ArtifactModel,
    modifier: Modifier = Modifier
) {
    val html = remember(artifact.id, artifact.content) { ArtifactHtml.build(artifact) }
    val js = ArtifactHtml.needsJavaScript(artifact.type)
    val isMermaid = artifact.type == ArtifactType.MERMAID

    AndroidView(
        factory = { context ->
            WebView(context).apply {
                settings.apply {
                    javaScriptEnabled = js
                    // No storage, no file/content access, no geolocation, no popups, no caching.
                    domStorageEnabled = false
                    allowFileAccess = false
                    allowContentAccess = false
                    setGeolocationEnabled(false)
                    javaScriptCanOpenWindowsAutomatically = false
                    setSupportMultipleWindows(false)
                    // Only Mermaid needs the network (for its one script); everything else is offline.
                    blockNetworkLoads = !isMermaid
                    cacheMode = WebSettings.LOAD_NO_CACHE
                }
                // Deliberately NO addJavascriptInterface: page scripts get no bridge into the app.

                webViewClient = object : WebViewClient() {
                    // The page may never navigate away (links, location.href, form posts).
                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = true

                    override fun shouldInterceptRequest(
                        view: WebView?,
                        request: WebResourceRequest?
                    ): WebResourceResponse? {
                        val url = request?.url?.toString() ?: ""
                        if (isMermaid && url.startsWith(ArtifactHtml.MERMAID_URL_PREFIX)) {
                            return super.shouldInterceptRequest(view, request)
                        }
                        if (url.startsWith("http://") || url.startsWith("https://")) {
                            return WebResourceResponse(
                                "text/plain", "UTF-8", 403, "Forbidden", emptyMap(),
                                ByteArrayInputStream(ByteArray(0))
                            )
                        }
                        return super.shouldInterceptRequest(view, request)
                    }
                }
            }
        },
        update = { webView ->
            // Recomposition must not reload the page (it would reset an interactive artifact).
            if (webView.tag != html) {
                webView.tag = html
                webView.loadDataWithBaseURL("https://localhost", html, "text/html", "UTF-8", null)
            }
        },
        onRelease = { it.destroy() },
        modifier = modifier
    )
}
