package com.bigmoe.onedge.ui.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.bigmoe.onedge.core.AgentController
import com.bigmoe.onedge.core.AgentEvent
import com.bigmoe.onedge.core.AgentRequest
import com.bigmoe.onedge.core.ImageData
import com.bigmoe.onedge.core.EngineController
import com.bigmoe.onedge.core.EngineState
import com.bigmoe.onedge.core.HistoryMessage
import com.bigmoe.onedge.core.MessageSink
import com.bigmoe.onedge.core.NewMessage
import com.bigmoe.onedge.data.local.datastore.EngineSettings
import com.bigmoe.onedge.data.local.datastore.EngineSettingsDataStore
import com.bigmoe.onedge.attachments.AttachmentException
import com.bigmoe.onedge.attachments.AttachmentManager
import com.bigmoe.onedge.attachments.PendingAttachment
import com.bigmoe.onedge.data.local.entity.AttachmentKind
import com.bigmoe.onedge.data.local.entity.MessageRole
import com.bigmoe.onedge.data.repository.ArtifactDomainModel
import com.bigmoe.onedge.data.repository.ArtifactRepository
import com.bigmoe.onedge.data.repository.AttachmentDomainModel
import com.bigmoe.onedge.tools.ConfirmationHandler
import com.bigmoe.onedge.tools.ConfirmationRequest
import com.bigmoe.onedge.tools.ToolManager
import com.bigmoe.onedge.workspace.AttachmentContext
import com.bigmoe.onedge.workspace.FileKinds
import com.bigmoe.onedge.workspace.Workspace
import com.bigmoe.onedge.data.repository.ChatMessageDomainModel
import com.bigmoe.onedge.data.repository.ChatRepository
import com.bigmoe.onedge.data.repository.ChatSessionDomainModel
import com.bigmoe.onedge.parser.ArtifactModel
import com.bigmoe.onedge.parser.MessageContent
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ChatUiState(
    val currentSession: ChatSessionDomainModel? = null,
    val messages: List<ChatMessageUiModel> = emptyList(),
    val settings: EngineSettings = EngineSettings(),
    val engineState: EngineState = EngineState.Unloaded,
    /** False when the loaded model always reasons (no way to turn thinking off). */
    val thinkingSwitchable: Boolean = true,
    val isGenerating: Boolean = false,
    /** Answer text of the message being generated (tool-call blocks already removed). */
    val liveText: String = "",
    val liveReasoning: String = "",
    /** e.g. "Running web_search…" while a tool executes. */
    val liveStatus: String? = null,
    /** A visible problem or hint (no model, malformed tool call, engine error). */
    val notice: String? = null,
    val selectedArtifact: ArtifactModel? = null,
    /** Files / pictures / videos picked but not sent yet. */
    val pendingAttachments: List<PendingAttachment> = emptyList(),
    /** Set while a tool waits for the user's approval (edit with diff, delete, overwrite). */
    val pendingConfirmation: ConfirmationRequest? = null,
    /** Attachments and AI-made files of the open chat (the screen groups them under their messages). */
    val attachments: List<AttachmentDomainModel> = emptyList(),
    val artifacts: List<ArtifactDomainModel> = emptyList(),
    /** One-shot: a workspace path the screen should open in the file viewer, then clear. */
    val openFilePath: String? = null
) {
    val visionActive: Boolean get() = (engineState as? EngineState.Ready)?.info?.visionActive == true
}

data class ChatMessageUiModel(
    val id: String,
    val role: MessageRole,
    /** Text to show (tool calls stripped for assistant messages; tool result body for TOOL messages). */
    val text: String,
    val reasoning: String?,
    val toolCalls: List<String>,
    val artifacts: List<ArtifactModel>,
    val timestamp: Long,
    val tokensPerSecond: Double?,
    val prefillMs: Long?,
    val generatedTokens: Int?,
    val cacheHitPct: Double?,
    val note: String?
)

class ChatViewModel(
    private val repository: ChatRepository,
    private val settingsDataStore: EngineSettingsDataStore,
    private val agentController: AgentController,
    private val engineController: EngineController,
    private val toolManager: ToolManager,
    private val artifactRepository: ArtifactRepository,
    private val attachmentManager: AttachmentManager,
    private val workspace: Workspace
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    private var sessionJobs: List<Job> = emptyList()
    private var generationJob: Job? = null
    private var confirmation: CompletableDeferred<Boolean>? = null

    init {
        // The approval dialog: a tool that edits/deletes/overwrites files suspends here until the user answers.
        toolManager.confirmationHandler = ConfirmationHandler { request ->
            val answer = CompletableDeferred<Boolean>()
            confirmation = answer
            _uiState.update { it.copy(pendingConfirmation = request) }
            try {
                answer.await()
            } finally {
                confirmation = null
                _uiState.update { it.copy(pendingConfirmation = null) }
            }
        }
        settingsDataStore.settingsFlow
            .onEach { s -> _uiState.update { it.copy(settings = s) } }
            .launchIn(viewModelScope)
        engineController.state
            .onEach { s ->
                val locked = (s as? EngineState.Ready)?.info?.thinkControl == "none"
                _uiState.update { it.copy(engineState = s, thinkingSwitchable = !locked) }
            }
            .launchIn(viewModelScope)
    }

    /** Opens a saved chat (History). No-op when it is already the open chat. */
    fun loadSession(sessionId: String) {
        if (_uiState.value.currentSession?.id == sessionId) return
        if (generationJob?.isActive == true) stopGeneration()
        observeSession(sessionId)
    }

    /** Starts an empty chat; the session row is created lazily on the first message. */
    fun newChat() {
        if (generationJob?.isActive == true) stopGeneration()
        sessionJobs.forEach { it.cancel() }
        sessionJobs = emptyList()
        _uiState.update {
            it.copy(
                currentSession = null, messages = emptyList(), liveText = "", liveReasoning = "",
                liveStatus = null, notice = null, selectedArtifact = null,
                pendingAttachments = emptyList(), attachments = emptyList(), artifacts = emptyList()
            )
        }
    }

    private fun observeSession(sessionId: String) {
        // Cancel the previous collectors first: otherwise every visit to History leaks two more.
        sessionJobs.forEach { it.cancel() }
        _uiState.update {
            it.copy(messages = emptyList(), notice = null, selectedArtifact = null, pendingAttachments = emptyList(), attachments = emptyList(), artifacts = emptyList())
        }
        val sessionFlow = repository.observeSessionById(sessionId)
            .onEach { s -> _uiState.update { it.copy(currentSession = s) } }
            .launchIn(viewModelScope)
        val messagesFlow = repository.observeMessagesForSession(sessionId)
            // CONTEXT messages (attached file text) are part of the prompt, never a bubble.
            .onEach { list -> _uiState.update { it.copy(messages = list.filter { m -> m.role != MessageRole.CONTEXT }.map { m -> m.toUiModel() }) } }
            .launchIn(viewModelScope)
        val artifactsFlow = artifactRepository.observe(sessionId)
            .onEach { list -> _uiState.update { it.copy(artifacts = list) } }
            .launchIn(viewModelScope)
        val attachmentsFlow = repository.observeAttachments(sessionId)
            .onEach { list -> _uiState.update { it.copy(attachments = list) } }
            .launchIn(viewModelScope)
        sessionJobs = listOf(sessionFlow, messagesFlow, artifactsFlow, attachmentsFlow)
    }

    fun sendMessage(promptText: String) {
        val text = promptText.trim()
        val pending = _uiState.value.pendingAttachments
        if ((text.isEmpty() && pending.isEmpty()) || _uiState.value.isGenerating) return
        if (_uiState.value.engineState !is EngineState.Ready) {
            _uiState.update { it.copy(notice = NOTICE_NO_MODEL) }
            return
        }
        if (pending.any { it.kind != AttachmentKind.FILE } && !_uiState.value.visionActive) {
            _uiState.update { it.copy(notice = NOTICE_NO_VISION) }
            return
        }
        val settings = _uiState.value.settings
        val userText = text.ifEmpty { "Please look at the attached ${if (pending.any { it.kind != AttachmentKind.FILE }) "media" else "file(s)"}." }
        _uiState.update {
            it.copy(isGenerating = true, liveText = "", liveReasoning = "", liveStatus = null, notice = null, pendingAttachments = emptyList())
        }
        generationJob = viewModelScope.launch {
            try {
                var session = _uiState.value.currentSession
                val history: List<HistoryMessage>
                if (session == null) {
                    val modelPath = (engineController.state.value as? EngineState.Ready)?.info?.path
                    session = repository.createNewSession(titleFrom(userText), modelPath)
                    observeSession(session.id)
                    history = emptyList()
                } else {
                    history = repository.getMessages(session.id).map { HistoryMessage(it.id, it.role, it.content) }
                    if (session.title == ChatRepository.DEFAULT_TITLE && history.isEmpty()) {
                        repository.updateSessionTitle(session.id, titleFrom(userText))
                    }
                }
                val sessionId = session.id
                val userId = repository.addMessage(sessionId, NewMessage(MessageRole.USER, userText))

                // Attachments: link them to the message, turn documents into hidden context text, decode media.
                var contextText = ""
                var images: List<ImageData> = emptyList()
                if (pending.isNotEmpty()) {
                    for (a in pending) repository.addAttachment(sessionId, userId, a.kind, a.name, a.mime, a.path, a.sizeBytes)
                    try {
                        val files = pending.filter { it.kind == AttachmentKind.FILE }
                            .map { AttachmentContext.TextFile(it.name, attachmentManager.readText(it)) }
                        val prepared = attachmentManager.prepareMedia(
                            pending.filter { it.kind != AttachmentKind.FILE }, settings.imageMaxDim, settings.videoFrames
                        )
                        images = prepared.images
                        contextText = AttachmentContext.build(files, prepared.notes, userText, settings.contextLength)
                    } catch (e: Exception) {
                        _uiState.update { it.copy(notice = "Could not read an attachment: ${e.message ?: e.javaClass.simpleName}") }
                        return@launch
                    }
                    if (contextText.isNotBlank()) repository.addMessage(sessionId, NewMessage(MessageRole.CONTEXT, contextText))
                }
                val sink = MessageSink { repository.addMessage(sessionId, it) }

                agentController.runAgentLoop(
                    AgentRequest(sessionId, history, userText, settings, contextText, images), sink
                ).collect { ev -> onAgentEvent(ev) }
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                _uiState.update { it.copy(notice = "Unexpected error: ${t.message ?: t.javaClass.simpleName}") }
            } finally {
                withContext(NonCancellable) {
                    _uiState.update {
                        it.copy(isGenerating = false, liveText = "", liveReasoning = "", liveStatus = null)
                    }
                }
            }
        }
    }

    // ---------------------------------------------------------------- attachments

    /** Copies a picked document / picture / video into the workspace and queues it for the next message. */
    fun addAttachment(resolver: android.content.ContentResolver, uri: android.net.Uri, kind: AttachmentKind) {
        if (kind != AttachmentKind.FILE && !_uiState.value.visionActive) {
            _uiState.update { it.copy(notice = NOTICE_NO_VISION) }
            return
        }
        viewModelScope.launch {
            try {
                val a = attachmentManager.import(resolver, uri, kind)
                _uiState.update { it.copy(pendingAttachments = it.pendingAttachments + a) }
            } catch (e: AttachmentException) {
                _uiState.update { it.copy(notice = e.message) }
            } catch (e: Exception) {
                _uiState.update { it.copy(notice = "Could not attach the file: ${e.message ?: e.javaClass.simpleName}") }
            }
        }
    }

    fun removePendingAttachment(id: String) {
        _uiState.update { s -> s.copy(pendingAttachments = s.pendingAttachments.filter { it.id != id }) }
    }

    // ---------------------------------------------------------------- tools, files

    /** Answer of the approval dialog. */
    fun resolveConfirmation(approved: Boolean) {
        confirmation?.complete(approved)
    }

    fun toggleToolFiles() {
        val v = !_uiState.value.settings.toolsFilesEnabled
        viewModelScope.launch { settingsDataStore.updateToolsFilesEnabled(v) }
    }

    fun toggleToolCode() {
        val v = !_uiState.value.settings.toolsCodeEnabled
        viewModelScope.launch { settingsDataStore.updateToolsCodeEnabled(v) }
    }

    /** Opens an inline artifact by first persisting it to the chat workspace. */
    fun openArtifact(artifact: ArtifactModel) {
        viewModelScope.launch {
            try {
                val sessionId = _uiState.value.currentSession?.id
                    ?: repository.createNewSession(ChatRepository.DEFAULT_TITLE, (_uiState.value.engineState as? EngineState.Ready)?.info?.path).also { observeSession(it.id) }.id
                val ext = when (artifact.type) {
                    com.bigmoe.onedge.parser.ArtifactType.HTML -> "html"
                    com.bigmoe.onedge.parser.ArtifactType.SVG -> "svg"
                    com.bigmoe.onedge.parser.ArtifactType.MERMAID -> "mmd"
                    com.bigmoe.onedge.parser.ArtifactType.CODE -> "txt"
                }
                val rel = workspace.uniquePath("artifacts/inline.$ext")
                workspace.writeText(rel, artifact.content, overwrite = false)
                artifactRepository.register(sessionId, "", rel, artifact.title)
                _uiState.update { it.copy(openFilePath = rel) }
            } catch (e: Exception) {
                _uiState.update { it.copy(notice = "Could not save the artifact: ${e.message}") }
            }
        }
    }

    /** "Open as artifact" on a code block: saves it as a file in the workspace and opens the viewer. */
    fun saveCodeAsArtifact(language: String, code: String) {
        val sessionId = _uiState.value.currentSession?.id
        viewModelScope.launch {
            try {
                val ext = extensionFor(language)
                val rel = workspace.uniquePath("artifacts/snippet.$ext")
                workspace.writeText(rel, code, overwrite = false)
                if (sessionId != null) artifactRepository.register(sessionId, "", rel)
                _uiState.update { it.copy(openFilePath = rel) }
            } catch (e: Exception) {
                _uiState.update { it.copy(notice = "Could not save the code: ${e.message}") }
            }
        }
    }

    fun consumeOpenFile() {
        _uiState.update { it.copy(openFilePath = null) }
    }

    private fun onAgentEvent(ev: AgentEvent) {
        when (ev) {
            is AgentEvent.Text -> _uiState.update { it.copy(liveText = it.liveText + ev.delta, liveStatus = null) }
            is AgentEvent.Reasoning -> _uiState.update { it.copy(liveReasoning = it.liveReasoning + ev.delta) }
            is AgentEvent.ToolStarted -> _uiState.update {
                it.copy(liveStatus = if (ev.name == "web_search") statusForTool(ev.name, ev.arguments) else toolManager.describeCall(ev.name, ev.arguments) + "…")
            }
            is AgentEvent.Notice -> _uiState.update { it.copy(notice = ev.text) }
            // The saved message is now in the list below; start a clean live bubble for the next round.
            is AgentEvent.MessageSaved -> _uiState.update { it.copy(liveText = "", liveReasoning = "") }
            is AgentEvent.Artifact -> Unit // shown as a chip once the message is saved
            AgentEvent.Done -> Unit
        }
    }

    fun stopGeneration() {
        if (_uiState.value.isGenerating) agentController.requestStop()
        confirmation?.complete(false) // a tool waiting for approval is refused, so it can unwind
    }

    fun dismissNotice() {
        _uiState.update { it.copy(notice = null) }
    }

    /** The globe button in the input bar. */
    fun toggleWebSearch() {
        val enabled = !_uiState.value.settings.isWebSearchEnabled
        viewModelScope.launch { settingsDataStore.updateWebSearchEnabled(enabled) }
    }

    /** The brain button in the input bar; feeds GenerateRequest.think of the next message. */
    fun toggleThinking() {
        if (!_uiState.value.thinkingSwitchable) return
        val enabled = !_uiState.value.settings.thinkingEnabled
        viewModelScope.launch { settingsDataStore.updateThinkingEnabled(enabled) }
    }

    fun selectArtifact(artifact: ArtifactModel?) {
        _uiState.update { it.copy(selectedArtifact = artifact) }
    }

    fun dismissArtifactDrawer() {
        _uiState.update { it.copy(selectedArtifact = null) }
    }

    private fun ChatMessageDomainModel.toUiModel(): ChatMessageUiModel {
        val isAssistant = role == MessageRole.ASSISTANT
        return ChatMessageUiModel(
            id = id,
            role = role,
            text = when (role) {
                MessageRole.ASSISTANT -> MessageContent.displayText(content)
                MessageRole.TOOL -> MessageContent.toolResultBody(content)
                else -> content
            },
            reasoning = reasoning,
            toolCalls = if (isAssistant) MessageContent.toolCallLabels(content) { n, a -> toolManager.describeCall(n, a) } else emptyList(),
            artifacts = if (isAssistant) MessageContent.artifacts(id, content) else emptyList(),
            timestamp = timestamp,
            tokensPerSecond = tokensPerSecond,
            prefillMs = prefillMs,
            generatedTokens = generatedTokens,
            cacheHitPct = cacheHitPct,
            note = note
        )
    }

    companion object {
        /** "Searching the web for “cats”…" for the search tool, "Running x…" otherwise. */
        fun statusForTool(name: String, argumentsJson: String): String {
            if (name != "web_search") return "Running $name…"
            val q = runCatching { org.json.JSONObject(argumentsJson).optString("query") }.getOrNull().orEmpty().trim()
            return if (q.isEmpty()) "Searching the web…" else "Searching the web for \u201C${q.take(60)}\u201D…"
        }

        const val NOTICE_NO_VISION =
            "The loaded model cannot see pictures or video. Load a vision model together with its mmproj file (Models tab)."

        private val EXT = mapOf(
            "kotlin" to "kt", "java" to "java", "python" to "py", "javascript" to "js", "typescript" to "ts", "html" to "html",
            "css" to "css", "json" to "json", "xml" to "xml", "yaml" to "yml", "markdown" to "md", "bash" to "sh", "sql" to "sql",
            "c" to "c", "cpp" to "cpp", "csharp" to "cs", "go" to "go", "rust" to "rs", "swift" to "swift", "svg" to "svg",
            "mermaid" to "mmd", "toml" to "toml", "csv" to "csv", "php" to "php", "ruby" to "rb", "lua" to "lua", "dart" to "dart"
        )

        /** File extension for a code-fence language tag ("js", "Python", "c++" ...). Unknown -> "txt". */
        fun extensionFor(language: String): String {
            val l = language.trim().lowercase()
            val canonical = when (l) {
                "js", "jsx", "node" -> "javascript"; "ts", "tsx" -> "typescript"; "py", "python3" -> "python"
                "c++", "cc", "hpp" -> "cpp"; "cs" -> "csharp"; "sh", "shell", "zsh" -> "bash"; "yml" -> "yaml"
                "md" -> "markdown"; "kt", "kts" -> "kotlin"; "rs" -> "rust"; "rb" -> "ruby"
                else -> FileKinds.languageFor("x.$l").takeIf { it != "text" } ?: l
            }
            return EXT[canonical] ?: "txt"
        }

        const val NOTICE_NO_MODEL = "No model is loaded. Open the model screen and load a model first."

        fun titleFrom(prompt: String): String {
            val oneLine = prompt.lineSequence().firstOrNull { it.isNotBlank() }?.trim().orEmpty()
            return if (oneLine.length <= 40) oneLine.ifEmpty { ChatRepository.DEFAULT_TITLE } else oneLine.take(40).trimEnd() + "…"
        }
    }
}
