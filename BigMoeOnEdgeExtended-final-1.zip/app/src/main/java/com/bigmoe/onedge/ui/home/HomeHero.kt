package com.bigmoe.onedge.ui.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.bigmoe.onedge.R

/**
 * The picture on the Home screen. To use your own image, add a file named `home_hero_custom`
 * (png / webp / jpg) to `app/src/main/res/drawable/`; nothing else has to change. Without it the bundled
 * placeholder `home_hero_default` is shown.
 */
@Composable
fun HomeHero(modifier: Modifier = Modifier, height: Dp = 140.dp) {
    val context = LocalContext.current
    val resId = remember {
        val custom = context.resources.getIdentifier("home_hero_custom", "drawable", context.packageName)
        if (custom != 0) custom else R.drawable.home_hero_default
    }
    Box(modifier = modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(20.dp))) {
        Image(
            painter = painterResource(resId),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxWidth().height(height)
        )
    }
}
