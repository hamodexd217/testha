package com.bigmoe.onedge.core

/**
 * The engine as the app sees it. The production implementation is [NativeEngineBackend]; tests use a fake,
 * so the controller/agent logic runs on the JVM without libonedge-engine.so.
 */
interface EngineBackend {
    /** Blocking. Returns null on success, otherwise the error message. */
    fun load(modelPath: String, config: LoadConfig, csvPath: String?, mmprojPath: String?): String?

    /** Build-time features of the native library. */
    fun capabilities(): EngineCaps

    /** Parsed "key=value" lines from the loaded model (arch, n_ctx, ...). */
    fun modelInfo(): Map<String, String>

    /** Blocking; see [NativeGenerationCallback]. */
    fun generate(
        system: String,
        historyFlat: List<ChatTurn>,
        prompt: String,
        maxTokens: Int,
        clearKv: Boolean,
        think: Boolean,
        images: List<ImageData>,
        callback: NativeGenerationCallback
    )

    /** Thread-safe; makes a running generate() return promptly. */
    fun stop()

    /** Cancels, waits, releases. */
    fun free()
}

class NativeEngineBackend(private val bridge: EngineNativeBridge) : EngineBackend {

    override fun capabilities(): EngineCaps = EngineCaps.fromBits(bridge.nativeCapabilities())

    override fun load(modelPath: String, config: LoadConfig, csvPath: String?, mmprojPath: String?): String? {
        val err = bridge.nativeLoadModel(
            modelPath = encodeUtf8(modelPath),
            ints = config.toIntArray(),
            floats = config.toFloatArray(),
            csvPath = encodeUtf8(csvPath.orEmpty()),
            mmprojPath = encodeUtf8(mmprojPath.orEmpty())
        )
        return if (err.isEmpty()) null else decodeUtf8(err)
    }

    override fun modelInfo(): Map<String, String> =
        decodeUtf8(bridge.nativeModelInfo()).lineSequence()
            .mapNotNull { line ->
                val i = line.indexOf('=')
                if (i <= 0) null else line.substring(0, i) to line.substring(i + 1)
            }.toMap()

    override fun generate(
        system: String,
        historyFlat: List<ChatTurn>,
        prompt: String,
        maxTokens: Int,
        clearKv: Boolean,
        think: Boolean,
        images: List<ImageData>,
        callback: NativeGenerationCallback
    ) {
        val flat = ArrayList<ByteArray>(historyFlat.size * 2)
        for (t in historyFlat) {
            flat.add(encodeUtf8(t.role))
            flat.add(encodeUtf8(t.content))
        }
        bridge.nativeGenerate(
            system = encodeUtf8(system),
            historyFlat = flat.toTypedArray(),
            prompt = encodeUtf8(prompt),
            maxTokens = maxTokens,
            clearKv = clearKv,
            think = think,
            imageDims = IntArray(images.size * 2) { i -> if (i % 2 == 0) images[i / 2].width else images[i / 2].height },
            imageData = Array(images.size) { images[it].rgb },
            callback = callback
        )
    }

    override fun stop() = bridge.nativeStopGeneration()

    override fun free() = bridge.nativeFreeModel()
}
