#include "thinking_control.h"

#include <cstdio>
#include <exception>
#include <string>

// ============================================================================
// COMPAT NOTE (this round): the person supplied a real llama.cpp checkout
// (upstream ggml-org/llama.cpp, "master" branch, dated 2026-07-08) to vendor
// as third_party/llama.cpp. It is NOT the Helldez/llama.cpp
// bmoe/expert-ready-hook fork - see native-bridge.cpp / core/CMakeLists.txt,
// which already detect that absence via BMOE_HAVE_EXPERT_READY_HOOK and fall
// back correctly (serial path, cfg.moe.overlap = false). That part needed no
// change. This file did.
//
// The root CMakeLists.txt's own comment warns that llama.cpp's `common`
// layer "is NOT a stable API - it can change between upstream versions... a
// submodule bump may need the chat glue in runtime.cpp updated". That's
// exactly what happened here: this checkout's `common_chat_params` (see
// third_party/llama.cpp/common/chat.h) carries a single
// `std::string thinking_end_tag`, not the `std::vector<std::string>
// thinking_end_tags` this file originally iterated. Every OTHER bmoe/llama.cpp
// symbol this codebase touches was checked against this exact checkout's
// headers and matches (COMMON_REASONING_FORMAT_AUTO, thinking_start_tag,
// common_chat_templates_source, common_chat_templates_apply, etc.) - this
// was the one real break.
//
// The fix below is a narrow adaptation of probe_think_control()'s original
// logic (find the rightmost end-tag match in the prefilled prompt) to a
// single tag instead of a vector - not a guess, and not a rewrite of the
// surrounding decision logic. If a future submodule bump re-introduces
// thinking_end_tags (plural), this is the one spot to revert.
// ============================================================================

namespace bmoe {

const char * think_control_name(ThinkControl c) {
    switch (c) {
    case ThinkControl::Template:
        return "template";
    case ThinkControl::Prefill:
        return "prefill";
    case ThinkControl::None:
        return "none";
    }
    return "template";
}

} // namespace bmoe

namespace bmoe::detail {

namespace {

// What a natively-supporting template puts inside the closed span. See add_no_think_prefill:
// whitespace, so the engine contributes no words to the model's own reasoning.
const char * const kEmptyReasoning = "\n\n";

// Render a one-turn conversation the way generate() renders a real one — same jinja path, same
// reasoning format — so what the probe observes is what generation will produce. The message text
// is irrelevant: templates branch on the flag, never on the words.
common_chat_params apply_probe(const common_chat_templates * tmpls, bool enable_thinking, bool prefill) {
    common_chat_msg user;
    user.role = "user";
    user.content = "hi";

    common_chat_templates_inputs inputs;
    inputs.messages = {user};
    inputs.add_generation_prompt = true;
    inputs.use_jinja = true;
    inputs.enable_thinking = enable_thinking;
    inputs.reasoning_format = COMMON_REASONING_FORMAT_AUTO;
    if (prefill) add_no_think_prefill(inputs);

    return common_chat_templates_apply(const_cast<common_chat_templates *>(tmpls), inputs);
}

} // namespace

void add_no_think_prefill(common_chat_templates_inputs & inputs) {
    common_chat_msg prefill;
    prefill.role = "assistant";
    prefill.reasoning_content = kEmptyReasoning;
    // content stays empty: the handler renders the closing tag and then nothing, leaving the model
    // at the first token of its answer. Nothing is appended that would have to be stripped back off.
    inputs.messages.push_back(prefill);
    inputs.continue_final_message = COMMON_CHAT_CONTINUATION_CONTENT;
}

ThinkControl probe_think_control(const common_chat_templates * tmpls) {
    if (tmpls == nullptr) return ThinkControl::Template;
    try {
        const common_chat_params off_p = apply_probe(tmpls, /*enable_thinking=*/false, /*prefill=*/false);
        const std::string & off = off_p.prompt;
        const std::string on = apply_probe(tmpls, /*enable_thinking=*/true, /*prefill=*/false).prompt;
        if (on != off) return ThinkControl::Template;

        // Does the model own a reasoning span — a `<think>`-style pair it opens and closes itself?
        //
        // Both halves are needed. A declared tag alone proves nothing, because handlers publish the
        // pair for a whole family: the non-reasoning members (LFM2-8B-A1B, LFM2.5-Instruct) advertise
        // `<think>` they never emit. Requiring the template to actually USE it is the same test
        // llama.cpp applies before wiring up reasoning extraction for that family.
        const std::string src = common_chat_templates_source(tmpls);
        const bool owns_span =
            !off_p.thinking_start_tag.empty() && src.find(off_p.thinking_start_tag) != std::string::npos;

        const std::string prefilled = apply_probe(tmpls, /*enable_thinking=*/false, /*prefill=*/true).prompt;

        // It does, and the flag is inert. Whether the request can still be honoured depends on WHO
        // closes the span. If the prefilled render moves past the closed span into further structure
        // of the format itself — harmony ends the analysis channel and then opens the final one —
        // the model is placed in its answer section and cannot decline. If the render just ends at
        // the closing tag, closing it was only a suggestion to a model that opens its own — LFM2.5
        // reasons straight past a pre-closed empty span and emits the reasoning untagged into the
        // answer (issue #82), worse than leaving it alone. Say so instead of making it worse.
        if (owns_span) {
            if (prefilled != off) {
                // Single-tag adaptation (see COMPAT NOTE at the top of this file): find where the
                // closing tag ends in the prefilled render, then check whether any further
                // structure follows it.
                size_t close_end = std::string::npos;
                const std::string & tag = off_p.thinking_end_tag;
                if (!tag.empty()) {
                    const size_t at = prefilled.rfind(tag);
                    if (at != std::string::npos) close_end = at + tag.size();
                }
                if (close_end != std::string::npos &&
                    prefilled.find_first_not_of(" \t\r\n", close_end) != std::string::npos) {
                    return ThinkControl::Prefill;
                }
            }
            return ThinkControl::None;
        }

        // No span of its own, and the prefill lands: reasoning is structural — a channel the format
        // itself separates — so starting the turn past that section is not something the model can
        // decline (harmony/gpt-oss).
        if (prefilled != off && off_p.thinking_start_tag.empty()) return ThinkControl::Prefill;

        // Nothing indicates this model reasons at all: no span it uses, no reasoning section to start
        // past. There is nothing to suppress, so pass the flag and add nothing — claiming it "always
        // reasons" would be a louder lie than the silence this probe exists to end.
        return ThinkControl::Template;
    } catch (const std::exception & e) {
        std::fprintf(stderr, "bmoe: thinking-control probe failed (%s); assuming the template honours it\n", e.what());
        return ThinkControl::Template;
    }
}

} // namespace bmoe::detail
