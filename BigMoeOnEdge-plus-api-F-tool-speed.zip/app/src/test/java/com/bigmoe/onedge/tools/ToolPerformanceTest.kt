package com.bigmoe.onedge.tools

import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** The speed-related behaviour of the tool layer: result clipping, the compact prompt, which tools may run side by side. */
class ToolPerformanceTest {

    private class Big : Tool {
        override val name = "big"
        override val description = "returns a lot"
        override val parametersSchema = JSONObject()
        override suspend fun execute(arguments: JSONObject) = (1..400).joinToString("\n") { "line number $it of the output" }
    }

    private class TwoParams : Tool {
        override val name = "two"
        override val description = "has two parameters"
        override val parametersSchema = toolSchema(
            listOf(
                Triple("path", "string", ""),
                Triple("start_line", "integer", "1-based"),
                Triple("query", "string", "Text or regex")
            ),
            listOf("path")
        )
        override suspend fun execute(arguments: JSONObject) = "ok"
    }

    @Test
    fun aLongResultIsClippedAtALineBreakAndSaysHowMuchWasLeft() = runBlocking {
        val m = ToolManager(maxResultChars = 1000).apply { registerTool(Big()) }
        val r = m.executeToolCall("big", "{}")
        val body = r.substringBefore("\n[truncated")
        assertTrue(body.length <= 1000)
        assertTrue(body.length >= 800)
        assertTrue("cut mid-line: ...${body.takeLast(25)}", body.endsWith("of the output"))
        assertTrue(Regex("\\[truncated: \\d+ more characters not shown\\]$").containsMatchIn(r))
    }

    @Test
    fun theLimitCanBeChangedBetweenRuns() = runBlocking {
        val m = ToolManager().apply { registerTool(Big()) }
        m.maxResultChars = 500
        assertTrue(m.executeToolCall("big", "{}").length < 600)
        m.maxResultChars = 20_000
        assertFalse(m.executeToolCall("big", "{}").contains("[truncated"))
    }

    @Test
    fun aShortResultIsReturnedUntouched() {
        assertEquals("short", ToolManager().clip("short", 100))
    }

    @Test
    fun clippingNeverSplitsASurrogatePair() {
        val s = "a".repeat(9) + "\uD83D\uDE00" + "b".repeat(50) // an emoji straddling the limit of 10
        val clipped = ToolManager().clip(s, 10)
        val body = clipped.substringBefore("\n[truncated")
        assertFalse(Character.isHighSurrogate(body.last()))
    }

    @Test
    fun theCompactPromptOmitsObviousStringTypesAndEmptyParameterLines() {
        val p = ToolManager().apply { registerTool(TwoParams()) }.getToolsDescriptionPrompt()
        // (org.json on the JVM does not keep key order, so only the pieces are checked)
        val sig = p.lineSequence().first { it.startsWith("- two(") }
        assertTrue(sig, sig.contains("path") && sig.contains("start_line?") && sig.contains("query?"))
        assertFalse(sig.contains("path?"))        // required, so no question mark
        assertTrue(p.contains("    start_line (integer): 1-based"))
        assertTrue(p.contains("    query: Text or regex"))
        assertFalse(p.contains("(string)"))
        assertFalse(p.contains("    path"))          // no description: no line, the signature already names it
    }

    @Test
    fun onlyTheReadOnlyNetworkToolsMayRunTogether() {
        val m = ToolManager().apply {
            registerTool(WebSearchTool(keylessFallback = false))
            registerWebPageTools(this)
            registerTool(Big())
        }
        assertTrue(m.isParallelSafe("web_search"))
        assertTrue(m.isParallelSafe("read_webpage"))
        assertTrue(m.isParallelSafe("extract_webpage"))
        assertFalse(m.isParallelSafe("big"))
        assertFalse(m.isParallelSafe("no_such_tool"))
    }

    @Test
    fun theFifthSearchResultKeepsItsSnippet() {
        val html = (1..6).joinToString("\n") { i ->
            """<a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fsite$i.example%2F">Title $i</a>
               <a class="result__snippet" href="x">Snippet $i</a>"""
        }
        val r = WebSearchTool.parseDuckDuckGoHtml(html)
        assertEquals(5, r.size)
        assertEquals("Snippet 5", r[4].snippet)
        assertEquals("https://site5.example/", r[4].url)
    }

    @Test
    fun theDescriptionsStayShort() {
        // The tool prompt is processed again whenever a conversation is re-read from its start, at tens of tokens per
        // second on a phone: keep the description of every built-in tool short. (A guard against creeping verbosity.)
        val m = ToolManager().apply {
            registerTool(WebSearchTool(keylessFallback = false))
            registerWebPageTools(this)
            registerUtilityTools(this, null)
        }
        for (name in m.toolNames()) assertTrue("$name description too long", m.getTool(name)!!.description.length <= 300)
    }
}
