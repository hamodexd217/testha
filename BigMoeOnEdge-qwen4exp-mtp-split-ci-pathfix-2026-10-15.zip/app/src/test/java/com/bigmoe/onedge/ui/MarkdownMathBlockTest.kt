package com.bigmoe.onedge.ui

import com.bigmoe.onedge.ui.chat.MarkdownBlock
import com.bigmoe.onedge.ui.chat.MarkdownLite
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MarkdownMathBlockTest {

    @Test
    fun displayMathOnOneLineBecomesItsOwnBlock() {
        val blocks = MarkdownLite.parse("Intro\n\$\$x = \\frac{a}{b}\$\$\nOutro")
        assertEquals(3, blocks.size)
        assertEquals("Intro", (blocks[0] as MarkdownBlock.Paragraph).text)
        assertEquals("x = \\frac{a}{b}", (blocks[1] as MarkdownBlock.Math).tex)
        assertEquals("Outro", (blocks[2] as MarkdownBlock.Paragraph).text)
    }

    @Test
    fun displayMathOverSeveralLines() {
        val m = MarkdownLite.parse("\$\$\nx = 1\ny = 2\n\$\$").single() as MarkdownBlock.Math
        assertEquals("x = 1\ny = 2", m.tex)
    }

    @Test
    fun bracketForm() {
        assertEquals("a + b", (MarkdownLite.parse("\\[ a + b \\]").single() as MarkdownBlock.Math).tex)
    }

    @Test
    fun textAfterTheClosingDelimiterStaysAParagraph() {
        val blocks = MarkdownLite.parse("\$\$a\$\$ is the formula")
        assertEquals("a", (blocks[0] as MarkdownBlock.Math).tex)
        assertEquals("is the formula", (blocks[1] as MarkdownBlock.Paragraph).text)
    }

    @Test
    fun anUnclosedBlockStaysTextWhileItStreamsIn() {
        val blocks = MarkdownLite.parse("\$\$ x = \\frac{")
        assertTrue(blocks.single() is MarkdownBlock.Paragraph)
    }

    @Test
    fun mathInsideACodeFenceIsLeftAlone() {
        val blocks = MarkdownLite.parse("```\n\$\$x\$\$\n```")
        assertTrue(blocks.single() is MarkdownBlock.Code)
    }

    @Test
    fun anEmptyPairIsNotABlock() {
        assertTrue(MarkdownLite.parse("\$\$ \$\$").single() is MarkdownBlock.Paragraph)
    }
}
