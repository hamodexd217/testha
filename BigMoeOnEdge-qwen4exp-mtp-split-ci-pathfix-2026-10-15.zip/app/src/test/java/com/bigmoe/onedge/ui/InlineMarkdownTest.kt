package com.bigmoe.onedge.ui

import com.bigmoe.onedge.ui.chat.InlineMarkdown
import com.bigmoe.onedge.ui.chat.MarkdownTable
import com.bigmoe.onedge.ui.chat.MdLine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class InlineMarkdownTest {

    /** "plain [bold:text] [math:x]" so a whole line can be compared at once. */
    private fun show(s: String): String = InlineMarkdown.parse(s).joinToString("") { sp ->
        val flags = listOfNotNull(
            "bold".takeIf { sp.bold }, "italic".takeIf { sp.italic }, "strike".takeIf { sp.strike },
            "code".takeIf { sp.code }, "math".takeIf { sp.math }, "link".takeIf { sp.link }
        )
        if (flags.isEmpty()) sp.text else "[" + flags.joinToString("+") + ":" + sp.text + "]"
    }

    @Test
    fun theLinesFromTheScreenshots() {
        assertEquals("values of [math:x] that satisfy it, use the [bold:quadratic formula]:", show("values of \$x\$ that satisfy it, use the **quadratic formula**:"))
        assertEquals("[math:a = 1]", show("\$a = 1\$"))
        assertEquals("Simplify [math:√224]:", show("Simplify \$\\sqrt{224}\$:"))
        assertEquals("[math:x = (-b ± √(b² - 4ac))/(2a)] done", show("\$\$x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}\$\$ done"))
    }

    @Test
    fun pricesAreNotMath() {
        assertEquals("It costs \$5 and \$10 each", show("It costs \$5 and \$10 each"))
        assertEquals("between \$5.00 and \$10.00 inclusive", show("between \$5.00 and \$10.00 inclusive"))
        assertEquals("total: \$20 + \$30 = \$50", show("total: \$20 + \$30 = \$50"))
        assertEquals("I have \$5 and you have 5\$ left", show("I have \$5 and you have 5\$ left"))
        assertEquals("cost \$5 then [math:x²] here", show("cost \$5 then \$x^2\$ here"))
    }

    @Test
    fun parenthesisedAndBracketedMath() {
        assertEquals("[math:x² + y²] and [math:z]", show("\\(x^2 + y^2\\) and \\[z\\]"))
        assertEquals("(e.g., [math:x] or [math:y₁])", show("(e.g., \$x\$ or \$y_1\$)"))
    }

    @Test
    fun emphasis() {
        assertEquals("this is [italic:italic] and [italic:also italic] and [bold+italic:both]", show("this is _italic_ and *also italic* and ***both***"))
        assertEquals("[strike:gone] stay", show("~~gone~~ stay"))
        assertEquals("[bold:bold with ][bold+italic:nested italic][bold: inside]", show("**bold with *nested italic* inside**"))
    }

    @Test
    fun thingsThatLookLikeMarkupButAreNot() {
        assertEquals("use snake_case_names and my_var here", show("use snake_case_names and my_var here"))
        assertEquals("2 * 3 * 4 = 24", show("2 * 3 * 4 = 24"))
        assertEquals("The rate is 7.4 t/s * 2", show("The rate is 7.4 t/s * 2"))
        assertEquals("half a **bo", show("half a **bo")) // still streaming in
    }

    @Test
    fun codeLinksAndEscapes() {
        assertEquals("[code:a*b*c] stays and [bold:after]", show("`a*b*c` stays and **after**"))
        assertEquals("see [link:the docs] now", show("see [the docs](https://x.org/a_b) now"))
        assertEquals("escaped \$5 and *stars*", show("escaped \\\$5 and \\*stars\\*"))
    }

    @Test
    fun htmlLeftovers() {
        assertEquals("a ² + b₁ & c", InlineMarkdown.plain("a <sup>2</sup> + b<sub>1</sub> &amp; c"))
    }

    @Test
    fun linesAreClassified() {
        assertEquals(MdLine.Heading(2, "Step-by-Step Solution:"), MdLine.classify("## Step-by-Step Solution:"))
        assertEquals(MdLine.Bullet(0, "•", "item"), MdLine.classify("- item"))
        assertEquals(MdLine.Bullet(0, "•", "item"), MdLine.classify("* item"))
        assertEquals(MdLine.Bullet(1, "◦", "a = 1"), MdLine.classify("  * a = 1"))
        assertEquals(MdLine.Bullet(0, "1.", "Identify"), MdLine.classify("1. Identify"))
        assertEquals(MdLine.Quote(1, "quoted"), MdLine.classify("> quoted"))
        assertEquals(MdLine.Rule, MdLine.classify("---"))
        assertEquals(MdLine.Rule, MdLine.classify("* * *"))
        assertEquals(MdLine.Plain("**bold** start"), MdLine.classify("**bold** start"))
        assertEquals(MdLine.Plain("2023. was a year"), MdLine.classify("2023. was a year"))
    }

    @Test
    fun tablesAreCollectedAndAligned() {
        val lines = listOf("| Name | Qty |", "|---|---:|", "| apple | 3 |", "| kiwi | 12 |", "after")
        val (rows, next) = MarkdownTable.collect(lines, 0)!!
        assertEquals(4, next)
        assertEquals(listOf("Name", "Qty"), rows[0])
        assertEquals("Name   │  Qty\n───────┼─────\napple  │  3\nkiwi   │  12", MarkdownTable.format(rows))
        assertNull(MarkdownTable.collect(listOf("| a | b |", "| c | d |"), 0)) // no separator row: not a table
        assertNotNull(MarkdownTable.collect(listOf("| a | b |", "| --- | --- |"), 0))
        assertTrue(MarkdownTable.cells("| a \\| b | c |").contains("a | b"))
    }
}
