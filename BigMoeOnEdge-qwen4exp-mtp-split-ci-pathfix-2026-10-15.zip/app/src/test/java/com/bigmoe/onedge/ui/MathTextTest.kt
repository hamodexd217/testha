package com.bigmoe.onedge.ui

import com.bigmoe.onedge.ui.chat.MathText
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MathTextTest {
    private fun m(tex: String) = MathText.toUnicode(tex)

    @Test
    fun theQuadraticFormulaFromTheChatScreenshot() {
        assertEquals("x = (-b ± √(b² - 4ac))/(2a)", m("""x = \frac{-b \pm \sqrt{b^2 - 4ac}}{2a}"""))
        assertEquals("x = (-16 ± √(16² - 4(1)(8)))/(2(1))", m("""x = \frac{-16 \pm \sqrt{16^2 - 4(1)(8)}}{2(1)}"""))
        assertEquals("16² - 32 = 256 - 32 = 224", m("""16^2 - 32 = 256 - 32 = 224"""))
        assertEquals("√224 = √(16 × 14) = 4√14", m("""\sqrt{224} = \sqrt{16 \times 14} = 4\sqrt{14}"""))
    }

    @Test
    fun theTimeFormulaFromTheSecondScreenshot() {
        assertEquals("Time = (Total Tokens)/(Tokens per Second)", m("""\text{Time} = \frac{\text{Total Tokens}}{\text{Tokens per Second}}"""))
        assertEquals("Time = 472/6.6", m("""\text{Time} = \frac{472}{6.6}"""))
        assertEquals("472 ÷ 6.6 ≈ 71.5151... seconds", m("""472 \div 6.6 \approx 71.5151... \text{ seconds}"""))
    }

    @Test
    fun fractionsParenthesiseOnlyWhatIsNotASingleAtom() {
        assertEquals("a/b", m("""\frac{a}{b}"""))
        assertEquals("(a+b)/2", m("""\frac{a+b}{2}"""))
        assertEquals("1/(2a)", m("""\frac{1}{2a}"""))
        assertEquals("-b/a", m("""-\frac{b}{a}"""))
    }

    @Test
    fun scriptsUseUnicodeWhereEveryFontHasIt() {
        assertEquals("x₁ + x₂", m("""x_1 + x_2"""))
        assertEquals("a²⁺ⁿ", m("""a^{2+n}"""))
        assertEquals("e^(iπ) + 1 = 0", m("""e^{i\pi} + 1 = 0"""))
        assertEquals("x_i", m("""x_i"""))
        assertEquals("90°", m("""90^\circ"""))
    }

    @Test
    fun rootsDelimitersAndBigOperators() {
        assertEquals("∛27 = 3", m("""\sqrt[3]{27} = 3"""))
        assertEquals("( (a+b)/2 )²", m("""\left( \frac{a+b}{2} \right)^2"""))
        assertEquals("∑(i=1→n) i = (n(n+1))/2", m("""\sum_{i=1}^{n} i = \frac{n(n+1)}{2}"""))
        assertEquals("∫₀¹ x dx", m("""\int_0^1 x \, dx"""))
        assertEquals("[ x = 4√14 ]", m("""\boxed{x = 4\sqrt{14}}"""))
    }

    @Test
    fun greekAndRelations() {
        assertEquals("α + β ≤ γ ≠ π", m("""\alpha + \beta \leq \gamma \neq \pi"""))
        assertEquals("sin θ", m("""\sin \theta"""))
    }

    @Test
    fun unknownCommandsAreKeptNotDropped() {
        assertEquals("\\foox", m("""\foo{x}"""))
    }

    @Test
    fun casesAndRowBreaksKeepTheirLinesInDisplayMath() {
        val out = MathText.toUnicode("""\begin{cases} x+1 & x>0 \\ 0 & x \le 0 \end{cases}""", multiline = true)
        val lines = out.lines()
        assertEquals(2, lines.size)
        assertTrue(lines[0].startsWith("{ x+1"))
        assertTrue(lines[1].endsWith("x ≤ 0"))
        // flattened in inline math
        assertTrue(!MathText.toUnicode("""a \\ b""").contains('\n'))
    }

    @Test
    fun scriptHelpers() {
        assertEquals("¹²", MathText.superscript("12"))
        assertNull(MathText.superscript("q"))
        assertEquals("₁₀", MathText.subscript("10"))
        assertNull(MathText.subscript(""))
    }
}
