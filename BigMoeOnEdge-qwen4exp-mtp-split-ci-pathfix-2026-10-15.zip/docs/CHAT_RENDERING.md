# Chat rendering: math and the markdown that was showing raw

## What was wrong
The bubble renderer (`MessageBody.kt`) only understood `**bold**` and `` `code` ``, headings and code fences. Everything else was shown as typed:
LaTeX (`$$x = \frac{-b \pm \sqrt{b^2 - 4ac}}{2a}$$`, `$x$`, `\(x\)`), `*italic*`, `~~strike~~`, `[links](url)`, `- bullets` (shown as a raw `*` / `-`), `> quotes`, `---` rules and `| tables |`.

## What it does now
* **Math** becomes readable Unicode text, in a serif font, no TeX engine and no new dependency (`MathText.kt`):
  `\frac{-b \pm \sqrt{b^2 - 4ac}}{2a}` -> `(-b ± √(b² - 4ac))/(2a)`. Covers fractions, roots (`√`, `∛`, `∜`, `ⁿ√`), super/subscripts (Unicode where every Android font has the glyph, otherwise `^x` / `_x`),
  Greek, operators and relations, arrows, `\text{}`, `\left/\right`, accents, `\boxed`, `\binom`, `\sum`/`\int` limits, and `cases`/matrix/aligned environments. An unknown command is kept as written, never dropped.
  Block math (`$$...$$` or `\[...\]` on its own line(s)) is its own block, scrollable when wide; inline math (`$x$`, `$$x$$`, `\(x\)`) sits in the line.
  Prices are not math: `costs $5 and $10` stays as typed (pandoc's rules, plus a prose check). Math that is still streaming in (no closing `$$` yet) shows as typed until it closes.
* **Inline markup** (`InlineMarkdown.kt`): bold, italic (`*x*`, `_x_`, not inside `snake_case`), bold-italic, strike, code, links (underlined, not clickable), image placeholders, `\*` escapes, `<sup>`/`<sub>`/`<br>` and basic HTML entities.
* **Lines**: bullets (`-`, `*`, `+`, nested, with real indentation), numbered lists, `>` quotes with a bar, `---` rules, headings 1-6.
* **Tables** (`| a | b |` with a separator row): aligned monospace text, scrollable sideways.

## Limits
No real typesetting: fractions are `a/b`, not stacked; big matrices and multi-line equations are approximations; links are not tappable; table columns assume a monospace width (right-to-left or wide characters may not line up).

## Checked
Logic of the converter and the inline parser was run in Python ports with the lines from your screenshots plus edge cases (prices, snake_case, nested emphasis): all as expected.
The Kotlin itself is not compiled and the new JVM tests (`MathTextTest`, `InlineMarkdownTest`, `MarkdownMathBlockTest`) were never run. Not seen on a device.

## Also in this round
* "Share latest CSV" skipped nothing before and picked the newest file even when it was empty (a model load opens a new, empty session file): it now picks the newest non-empty one.
