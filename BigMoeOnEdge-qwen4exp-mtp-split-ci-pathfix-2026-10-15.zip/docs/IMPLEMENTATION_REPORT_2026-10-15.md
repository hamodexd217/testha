# Qwen4Exp MTP sidecar and split-GGUF implementation report

Date: 2026-10-15  
Working branch: `feature/qwen4exp-mtp-split`  
Base commit: `19a2465`  
`master` was not edited.

## What is implemented in this branch

### Separate Qwen4Exp MTP draft

- Added an optional draft-model path through the app's native bridge and session configuration.
- The session loads the target and the MTP-only GGUF separately, creates a draft context, validates the architecture, hidden width, vocabulary count, and presence of MTP tensors, and gives the draft context access to the target context for borrowing the target's token embeddings and output head.
- Added Qwen4Exp-specific llama.cpp model/tensor/graph support for a stand-alone MTP block, including the hyper-connection head tensors, the MTP graph, QSA attention cache filtering, and rollback handling for a draft context without recurrent state.
- Fixed the common speculative initializer to load the configured draft path rather than re-opening the target path.
- Added `--mtp-shared-embd` conversion support, so a separate MTP GGUF can omit duplicate token embeddings and the output head. The Qwen4Exp converter maps its embedding/hidden projections and hyper-connection mixer to the GGUF tensors expected by the native model loader.
- Added persistent sidecar attachment per target model, a sidecar list and picker in Models, a Settings toggle for using the sidecar, status reporting for which draft was loaded, and reload/startup wiring.
- A sidecar is currently supported only for `general.architecture=qwen4exp`. It uses ordinary mmap loading, not Expert Streaming. The app intentionally switches to mmap for this load and the UI warns about the RAM trade-off. If draft loading fails, the app retries normal decoding with speculation off and shows a warning; this is a fallback, not a claim that MTP succeeded.

### Split GGUF and model management

- The import picker supports selecting multiple GGUF documents together. A split set must include every `-00001-of-000NN.gguf` through the final shard and is staged before finalization.
- Split validation checks filenames, presence/non-zero size, GGUF magic, readable metadata, architecture consistency, and `split.no` / `split.count` where those keys exist.
- Split sets appear as one target model. Rename and delete act on the whole in-app shard set. Later shards cannot be selected as models on their own.
- Draft paths are kept separate from the target list and linked by the target's canonical path. Drafts are not loaded unless MTP is selected and the separate-draft toggle is enabled.
- Absolute-path registration is still best-effort: Android scoped storage may prevent direct access to user-visible folders. Multi-document import is the reliable path, but copies the entire model into private app storage and consequently needs enough free space.

### Converter guidance

`docs/QWEN4EXP_MTP_SEPARATE_DRAFT.md` documents target and MTP-only conversion commands and the app import/attachment flow. Those conversion commands are examples and were **not** executed against an actual checkpoint in this environment. The pruned vendored tree lacks the complete `gguf-py` dependency set needed to run the converter end-to-end.

## Validation actually performed

- `cmake -S app/src/main/cpp/third_party/llama.cpp -B /tmp/llama-build -DLLAMA_BUILD_TESTS=OFF -DLLAMA_BUILD_EXAMPLES=OFF -DLLAMA_BUILD_SERVER=OFF -DGGML_NATIVE=OFF -DGGML_OPENMP=OFF` — passed on the Linux host.
- `cmake --build /tmp/llama-build --target llama -j4` — passed; the modified vendored `llama` library reached 100%, including `src/models/qwen4exp.cpp`.
- C++ syntax-only checks for the app session, JNI bridge (using a small local Android log stub), and `common/speculative.cpp` — passed. These are host-side syntax checks, not an Android NDK build.
- `python3 -m py_compile` on the touched MTP conversion modules and `convert_hf_to_gguf.py` — passed.
- Compiled `GgufInspector.kt`, `EngineTypes.kt`, and `ModelManager.kt` with local platform/coroutine stubs, then ran a custom test using synthetic GGUF headers — passed: multi-select shard import, numbering/metadata validation, one-row listing, group rename/delete, and sidecar attach/detach/listing.
- `git diff --check` — passed.

## Not verified here (important)

- `./gradlew :app:testDebugUnitTest --no-daemon` could not start the tests: Gradle 8.9 was not present locally and the wrapper's download failed with `UnknownHostException: services.gradle.org`. JUnit tests in the repository have therefore **not** run.
- A full Android build was not run because Android SDK/NDK paths are not available in this environment. Compose screens, the complete app dependency graph, and the final Android shared library have not been compiled together here.
- No real Qwen3.8-Flash-Next checkpoint or matching MTP-only GGUF was available, and no Android device was available. Therefore actual GGUF conversion, target/draft loading on device, token generation/acceptance, quality, speed-up, peak RAM, and fallback behavior on hardware remain unverified.
- Model-manager integration was tested with generated miniature GGUF headers. It does not replace a test with real multi-gigabyte split GGUF files or Android's actual Storage Access Framework provider.

## Follow-up: uploaded GitHub Actions log (2026-10-15)

The user-provided CI log fails at `chmod: cannot access 'gradlew': No such file or directory`. The preceding step unzips the source archive into `project/`, and this archive has a `workrepo/` wrapper folder; the workflow then runs `chmod +x gradlew` at the workspace root. Gradle never starts in that failed run. See `docs/CI_BUILD_FIX_2026-10-15.md` for a replacement Build step that discovers `gradlew` under `project/` and changes into its parent directory. This fixes the observed path error but does not claim the next full Android build will pass; the workflow must be rerun to reveal any subsequent compilation or dependency issue.

## Delivery interpretation

This ZIP contains the implementation work on the dedicated feature branch; it is not a claim of device-certified/runtime-verified MTP. The native llama library compiles on the host, but the final gating check is to convert a matching target plus MTP-only sidecar, build the Android app with its SDK/NDK, and test load/generation on a supported device. `master` remains untouched, and the working-tree changes are carried in this source ZIP rather than a pushed commit.
