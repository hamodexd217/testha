# Hexagon / NPU Android build

The NPU path is intentionally separate from the ordinary Android build. A Snapdragon 8 Gen 2 does contain a Hexagon HTP accelerator (the v73 generation), but hardware capability alone does not mean an APK contains or can load the Hexagon backend. The standard APK is deliberately CPU-only and reports `npuPrefill=false`; its NPU settings remain visible but disabled.

- CPU-only/default: `./gradlew --no-daemon :app:assembleDebug`
- NPU: manually run the GitHub Actions workflow `.github/workflows/android-npu.yml` from the repository's Actions tab.
- Static source check: `bash scripts/validate-npu-source.sh` checks the engine flag, `HTP0` selection, expected HTP v73 target, APK workflow, and fail-closed payload checks without claiming a native build.

The NPU workflow runs Gradle from the repository root (`:app:assembleDebug`). Running Gradle while the current directory is `app/` is not equivalent: the settings file belongs to the parent project. The workflow now verifies each staged ELF and re-extracts the APK's copies to confirm the full payload survived packaging.

The native configure step explicitly passes `-DPREBUILT_LIB_DIR=android_aarch64`. This is required by ggml's parent Hexagon CMake integration; omitting it causes the SDK `hexagon_fun.cmake` `string(FIND requires 3 or 4 parameters` errors during configure. The script validates and prints the SDK/tools paths before running CMake. The workflow uses upstream BigMoeOnEdge 0.28's pinned Snapdragon toolchain image. The native engine is rebuilt from this exact checkout with `BMOE_ENABLE_HEXAGON=ON`, so the `BMOE_HAVE_HEXAGON` capability bit and the prefill code are part of the actual `libonedge-engine.so` shipped in the APK.

The staging payload contains:

- `libonedge-engine.so`
- `libc++_shared.so`
- `libggml-htp-v73.so`
- `libggml-htp-v75.so`
- `libggml-htp-v79.so`
- `libggml-htp-v81.so`

All four HTP skels are shipped because the ggml Hexagon backend chooses the matching DSP generation at runtime. The settings switch is enabled from the native capability bit, not from a Gradle flag alone. NPU use is prompt-prefill acceleration only; decode remains on CPU. Row-streaming and speculative decoding currently conflict with this path and are gated in the UI/native bridge.

`-PbmoePrebuiltNative=true` is fail-closed: Gradle verifies the real engine and all four HTP skels before the APK build starts. It also uses a tiny placeholder CMake target so the already-built JNI engine is packaged from `src/main/jniLibs/arm64-v8a` rather than rebuilt by a CPU-only local machine.

## Verification boundary

The source archive contains the build recipe and workflow, not prebuilt NPU libraries. The ordinary CPU APK does not contain the HTP backend. The GitHub Actions workflow must finish successfully to produce `onedge-npu-debug-apk`; installation and an on-device prompt-prefill test on the target Snapdragon device are still required to confirm runtime execution.
