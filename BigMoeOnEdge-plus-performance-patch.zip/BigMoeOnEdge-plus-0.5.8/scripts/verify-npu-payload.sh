#!/usr/bin/env bash
# Fail-closed verification for the JNI libraries needed by the optional Hexagon APK.
# Accepts either the staged jniLibs/arm64-v8a directory or a temp directory extracted from an APK.
set -euo pipefail

DIR="${1:-app/src/main/jniLibs/arm64-v8a}"
required=(
  libonedge-engine.so
  libc++_shared.so
  libggml-htp-v73.so
  libggml-htp-v75.so
  libggml-htp-v79.so
  libggml-htp-v81.so
)

if [[ ! -d "$DIR" ]]; then
  echo "ERROR: NPU payload directory not found: $DIR" >&2
  exit 1
fi

for name in "${required[@]}"; do
  file="$DIR/$name"
  if [[ ! -s "$file" ]]; then
    echo "ERROR: missing or empty NPU library: $file" >&2
    exit 1
  fi
  magic="$(od -An -tx1 -N4 "$file" | tr -d ' \n')"
  if [[ "$magic" != "7f454c46" ]]; then
    echo "ERROR: $name is not an ELF shared-library payload (magic=$magic)" >&2
    exit 1
  fi
done

if ! command -v readelf >/dev/null 2>&1; then
  echo "ERROR: readelf is required to verify the Android engine ABI" >&2
  exit 1
fi
machine="$(readelf -h "$DIR/libonedge-engine.so" | awk -F: '/^[[:space:]]*Machine:/ {sub(/^[[:space:]]*/, "", $2); print $2; exit}')"
if [[ "$machine" != *AArch64* ]]; then
  echo "ERROR: libonedge-engine.so must be Android arm64-v8a; ELF machine reported: ${machine:-unknown}" >&2
  exit 1
fi
cpp_machine="$(readelf -h "$DIR/libc++_shared.so" | awk -F: '/^[[:space:]]*Machine:/ {sub(/^[[:space:]]*/, "", $2); print $2; exit}')"
if [[ "$cpp_machine" != *AArch64* ]]; then
  echo "ERROR: libc++_shared.so must match arm64-v8a; ELF machine reported: ${cpp_machine:-unknown}" >&2
  exit 1
fi

printf 'PASS: required NPU payloads are non-empty ELF files; engine ABI=%s; C++ runtime ABI=%s\n' "$machine" "$cpp_machine"
sha256sum "${required[@]/#/$DIR/}"
