// Engine configuration.
//
// All tunables flow through these structs: the CLI parses flags into a RunConfig, the
// engine consumes it. The library never reads environment variables — env overrides,
// if any, are resolved in the CLI before this struct is built (see cli/main.cpp), so
// the engine's behaviour is fully determined by its inputs and is trivially testable.
//
// This header is pure policy (no llama.cpp dependency); validate() is unit-tested
// without the native backend.
#pragma once

#include <cstdint>
#include <string>

namespace bmoe {

// Token sampling. temp <= 0 (the default) selects greedy argmax — the deterministic path the
// byte-identity gates depend on, and today's behaviour for any caller that sets nothing. temp > 0
// builds the standard chain top_k -> top_p -> temp -> dist. Opt-in by construction: sampling never
// perturbs a run that did not ask for it, so the gates stay meaningful.
struct SamplingConfig {
    float temp = 0.0f;           // <= 0: greedy (argmax). > 0: stochastic sampling.
    int top_k = 40;              // 0 disables the top-k stage (llama.cpp convention)
    float top_p = 0.95f;         // nucleus cutoff, in (0, 1]
    uint32_t seed = 0xFFFFFFFFu; // == LLAMA_DEFAULT_SEED (random per run); static_assert'd in session.cpp
};

// How the dense (non-expert) model weights are kept resident. See MoeStreamConfig::dense_weights and
// core/src/moe/dense_weights.h. Ordered cheapest-effort first.
enum class DenseWeightsMode {
    Mmap,      // leave mmap'd, no help (the A/B baseline)
    Warmed,    // mmap'd, but page-cached once at load
    Anonymous, // read via O_DIRECT into our own anon buffers and rebind (swaps to zram, not flash)
    Pinned,    // as Anonymous, but into reclaim-exempt dma-buf memory the kernel may not take back.
               // Android-only (pio::pinned_alloc); init fails where unsupported rather than falling
               // back, so an A/B against Anonymous can never silently compare a mode to itself.
};

// MoE expert-selective streaming knobs.
struct MoeStreamConfig {
    bool enabled = false; // turn streaming on; init fails fast if the model is not MoE

    // LRU expert cache budget, in MiB. 0 disables the cache (experts are re-read from
    // flash every token via three shared slots). Measured pathology: a budget below one
    // token's working set thrashes (evict + re-read, zero hits) and is SLOWER than off,
    // so validate() rejects the 1..cache_min_mb-1 band unless force_cache is set.
    int cache_mb = 0;

    // Size the cache from the device instead of a fixed cache_mb: once at init the budget is set to
    // (available RAM − cache_floor_mb), clamped to [cache_min_mb, total expert bytes], and then held
    // for the whole run. One shot, not a control loop — it spares the caller a hand-tuned number on a
    // device whose free RAM it cannot know in advance; it does not chase memory pressure afterwards.
    // Mutually exclusive with an explicit cache_mb > 0. See docs/cache-sizing.md.
    bool cache_auto = false;
    int cache_floor_mb = 1536; // RAM to leave free for the rest of the system when auto-sizing
    int cache_ceil_mb = 0;     // upper bound on the auto budget in MiB (0 = cap only at the full
                               // expert-set size); useful to keep the cache from taking all the
                               // headroom when the marginal hit-rate gain no longer justifies the RAM

    // Adaptive memory-pressure brake: when compute slows sharply and sampled cache pages have
    // been reclaimed, shrink the cache by half, never below one token's worst-case expert cycle.
    // It is inert when the cache is off or residency cannot be sampled.
    bool cache_brake = true;

    // Parallel expert-slice read lanes (incl. the calling thread). 1 = serial baseline.
    // Clamped to [1, io_threads_max]. 4 is the measured sweet spot on UFS4 phones.
    int io_threads = 4;

    bool o_direct = true;     // bypass the page cache (O_DIRECT / FILE_FLAG_NO_BUFFERING)
    bool load_all = false;    // debug/A-B: load ALL experts each token (full-sweep baseline)
    bool force_cache = false; // allow a cache_mb in the pathological band (tests/experiments)

    // Overlap async expert reads with FFN compute instead of blocking on them: load_layer()
    // publishes the reads and returns immediately, and the CPU mul_mat_id kernel blocks per
    // expert (via the fork's expert-ready hook) only if that expert's slice is not yet in.
    // Requires the Helldez/llama.cpp fork submodule (the hook); run() fails fast otherwise.
    bool overlap = false;

    // Two-wave batch publish (#118). A layer's read batch normally becomes visible to the I/O
    // lanes only after ALL of its staging finished — up to three page-commit syscalls per cold
    // expert sitting in front of the first byte of I/O, on the latency-to-first-slice path the
    // sidecar refutation identified as the binding constraint. With this on, the jobs of the
    // first projection (the one mul_mat_id blocks on first) are committed and published
    // immediately, and the remaining projections are committed and appended while the lanes
    // already read. Overlap + LRU cache only. Default off pending the on-device A/B.
    bool io_two_wave = false;

    // Temporal prefetch: while a token computes layer l, speculatively read on the idle I/O
    // lanes the experts the PREVIOUS token routed at layers l+1..l+prefetch_layers, betting on
    // the strong temporal locality of routing. A correct guess turns the next layer's read into
    // a cache hit; a wrong guess only wastes a read. 0 disables it. Needs the LRU cache on —
    // a fixed cache_mb or cache_auto (speculative slices land in the per-layer cache buffers),
    // so validate() rejects it when both are off. See docs/prefetch.md.
    int prefetch_layers = 0;

    // How the dense (non-expert) weights are treated. The streamer only rebinds experts; the rest —
    // gguf header/metadata, embeddings, attention, norms, lm_head — is handled by one of three
    // policies (see core/src/moe/dense_weights.h):
    //   Mmap      leave them mmap'd; the kernel serves and reclaims them (a >RAM model then demand-
    //             faults them 4 KiB at a time inside the first decodes — the slow-start this exists
    //             to address). The A/B baseline.
    //   Warmed    leave them mmap'd, but page-cache them once at load with a sequential sweep, so the
    //             first decodes do not fault them in. Moves the cost into load_seconds. Best when the
    //             model fits in RAM.
    //   Anonymous (default) read them once via O_DIRECT into our own anon buffers and rebind the
    //             tensors, so a reclaim swaps them to zram (fast) instead of dropping them to a 4 KiB
    //             flash refault. The measured win on a model actively losing its dense set to reclaim,
    //             and the policy the Android app ships by default — the CLI matches it here.
    DenseWeightsMode dense_weights = DenseWeightsMode::Anonymous;

    // ── row-gathered dense tables served from flash (see bmoe/row_source.h) ──────────
    // A dense weight the graph only ever GATHERS ROWS from — a token embedding table is the pure
    // case — is resident for nothing: one row of it is read per decoded token and the rest of the
    // hundreds of MiB sits in RAM the expert cache is competing for. With this on, such a table is
    // bound to reserved address space and only the rows the graph asks for are pulled from flash,
    // inside a bounded window.
    //
    // WHICH tables qualify is decided by the graph at capture time and by nothing else: every
    // reference to the tensor must be a row gather with a readable index. No architecture, tensor
    // name or size threshold appears in the rule, so a model whose embeddings are also used as the
    // output head simply never qualifies, on any architecture, without a special case for it.
    //
    // Off by default: it trades residency for a read per gather miss, and which way that trade goes
    // is a measurement per device class, not a foregone conclusion.
    bool row_stream = false;
    int row_stream_mb = 64; // resident window across all row-streamed tables, in MiB

    // ── release the model file's mapping after load (Windows) ─────────────────────────
    // llama.cpp keeps the gguf mapped for the model's lifetime, and on Windows a live section of
    // the file serialises the streamer's concurrent unbuffered reads: four lanes deliver one
    // lane's throughput (measured; see core/src/io/mapping_release.h). With this on, once nothing
    // reads through the mapping any more (dense weights copied out under anon/ahwb, every file
    // tensor either streamed, copied or row-served) the engine unmaps the file and closes its
    // section. On POSIX the mapping is munmap'd the same way; Android was measured not to serialise
    // reads, so there the gain is smaller and of a different kind (see docs/moe-streaming.md).
    //
    // Opt-in, and it must stay opt-in until the safety question has a positive answer rather than a
    // blacklist. The release is correct only while nothing still dereferences the mapping, and
    // llama.cpp exposes no way to enumerate a loaded model's tensors and prove that. The session
    // declines on every shape where a surviving pointer is KNOWN — a dense policy that keeps the
    // weights mmap'd, a tied output head, an unowned tensor under the MTP draft — but a future
    // architecture can invent another one. See Session::open.
    bool release_mmap = false;

    // ── cache-aware expert dropping (lossy; opt-in) ──────────────────────────────────
    // Skip a routed expert when it is a cache MISS *and* the router weighted it below
    // drop_cold_frac × (1 / n_expert_used) — i.e. below that fraction of the uniform share a
    // top-k routing would give each expert. 0 (the default) disables it and the engine is
    // bit-exact as before.
    //
    // The asymmetry is the whole idea: an expert already resident costs no flash read, so it
    // always runs however small its weight. Quality is spent only where it buys I/O. Because
    // the largest weight in a routing is always >= the uniform share, a frac of 1.0 can never
    // empty a routing; validate() rejects anything above it, and the implementation additionally pins the
    // top-weighted expert so no cell is ever left with nothing to compute.
    //
    // This changes the output — it is a quality/throughput trade like n_expert_used, not an
    // optimisation. Unlike n_expert_used it is *state-dependent*: the same prompt can decode
    // differently depending on what the cache happened to hold, so a run is no longer
    // reproducible token-for-token. See docs/expert-dropping.md.
    float drop_cold_frac = 0.0f;

    // Rescale the surviving weights so the routing still sums to what it did before the drop.
    // Without it the layer's expert output is systematically scaled down by the discarded mass
    // (~10% at frac 1.0), which perturbs the residual stream more than the missing expert does.
    bool drop_renorm = true;

    // Apply dropping during prefill too. Off by default and deliberately so: the cache is cold
    // there, so nearly every expert is a miss and the same threshold discards ~4x the weight
    // mass it does in decode (measured; see docs/expert-dropping.md). Prefill is also
    // compute-bound, so there is little to win.
    bool drop_prefill = false;

    // ── cache-aware substitution (lossy; opt-in) ─────────────────────────────────────
    // Dropping decides whether to PAY for a missing expert. This decides whether to NEED one:
    // before a routing is committed, every expert's router score is raised by
    // substitute_lambda × (this token's score range) if that expert is already resident, and the
    // top-k is taken again. A resident expert therefore wins a slot only when it was within that
    // margin of the one it displaces — a confident routing is untouched, a near-tie resolves
    // toward RAM.
    //
    // The margin is a fraction of the RANGE, so one value means the same thing whatever scale a
    // model's router scores live on: no per-model constant, and no calibration state. The weights
    // are not touched: the graph applies whatever the router itself gives the selected experts.
    //
    // It runs the same NUMBER of experts, just cheaper ones. It is still lossy — they are not the
    // experts the router asked for — and, like dropping, state-dependent. 0 (the default) disables
    // it and the engine is bit-exact as before. Decode only; needs a live cache to report
    // residency. See docs/cache-aware-substitution.md.
    float substitute_lambda = 0.0f;

    // Diagnostics: measure how predictable the routing is, without acting on it. For every decoded
    // token the engine ranks each layer's experts a layer early — running the NEXT layer's gate
    // matrix on the CURRENT layer's gate input, which the residual stream keeps nearly unchanged —
    // and reports what fraction of the routing that would have had in flight. Scored alongside it:
    // the previous-token bet --prefetch already makes, and a zero-staleness control that says how
    // much of any gap is the ranking's own approximation rather than the staleness.
    //
    // Nothing it computes reaches the loading path: a probed run reads exactly the bytes an
    // unprobed one does. It is not free, though — one isolated node and one gate GEMV per MoE layer
    // per token, on the eval thread — so a probed run is not a benchmark run. Requires streaming.
    // See docs/expert-prediction.md.
    bool predict_log = false;

    // Predictive prefetch: act on the stale-gate prediction instead of just logging it. While
    // layer l computes, the NEXT layer's router matrix is run on l's gate input (the same one
    // GEMV predict_log measures) and the predicted experts are handed to the same speculative
    // read path --prefetch uses — same cache buffers, same accounting, same settle. Two things
    // separate it from the temporal prefetch it replaces:
    //   - the prediction is about THIS token (measured ~89% of routed slots on a 128-expert
    //     model, vs ~43% for the previous-token bet), so far fewer speculated bytes are wasted;
    //   - it is drop-aware: with drop_cold_frac armed, predicted experts whose predicted routing
    //     weight falls below the drop threshold are not prefetched — if they miss they would be
    //     dropped unread anyway, so reading them ahead would spend the exact I/O the drop policy
    //     exists to save.
    // Decode only. Needs the LRU cache (speculative slices land in the per-layer cache buffers)
    // and is mutually exclusive with prefetch_layers — one speculative predictor at a time, or
    // the lanes fill with two guesses about the same future. Costs one gate GEMV per MoE layer
    // per token on the eval thread. Byte-identity: like --prefetch, it only warms the cache, so
    // output is unchanged — except under drop_cold_frac, where residency is an input to the
    // routing policy and a correct guess un-drops an expert (same caveat as --prefetch, see
    // docs/expert-dropping.md).
    bool predict_prefetch = false;

    // How many predicted MISSES per layer the predictive prefetch may speculate. The rest of the
    // prediction still works at any value: predicted experts already resident are retained
    // (LRU-protected) whatever this says, because that costs zero bytes. 0 is the retention-only
    // mode — the prediction spends no flash at all and only protects; the measured sweet spot for
    // speculation, if any, is small (the stall a prefetch can remove is head-of-line only).
    int predict_spec_max = 2;

    // ── route-ahead: commit to the prediction (lossy; opt-in; experimental) ───────────
    // With N > 0, decode routing at MoE layer L is REPLACED by the ranking layer L's own gate
    // matrix produced on the hidden state N layers earlier in the same forward pass — the
    // stale-gate prediction predict_log measures, acted on as the routing itself instead of as a
    // prefetch hint. The router still computes: its logits give the substituted experts their
    // true renormalized weights, and each layer's gate input feeds the prediction for layer L+N.
    // Layers 0..N-1, prefill, the first decode token and any unreadable layer route normally.
    //
    // Why anyone would do this: a prediction that IS the routing cannot miss, and it is known a
    // full N layers of compute early — the perfect-prefetch regime no honest predictor reaches
    // (measured here: one layer of staleness costs ~3.5-4pp of slot agreement, and the union of
    // four stale horizons still covers only 81-89% of misses). With the LRU cache on, the engine
    // acts on that: the committed selection of layer L+N is handed to the speculative read path
    // the moment it is fixed (at layer L's load), uncapped — those reads can never be wasted —
    // so by the time layer L+N runs its experts are resident or already in flight. Without the
    // cache the selection still commits but nothing is read early. The price is a quality
    // perturbation: ~15-20% of slots route to a different expert than the router chose at N=1,
    // and the error compounds through the residual stream. LOSSY by construction; changes the
    // output. See docs/route-ahead.md.
    //
    // Mutually exclusive with the probe and both prefetchers: the probe would score a predictor
    // against a routing this policy rewrote from that same predictor (a tautology), and a
    // speculative prefetch would bet lanes on a future this policy has already fixed. Also
    // mutually exclusive with self-speculation, for a measured reason rather than a conceptual
    // one: a verify decode is several positions wide and this policy declines to commit on every
    // one of them, so the pair pays the prediction and the early reads and commits nothing.
    int route_ahead = 0;

    // Test/debug only: complete each prefetch's speculative reads synchronously, on the eval
    // thread, before returning. This defeats the latency-hiding purpose (the reads no longer
    // overlap compute) but makes speculative integration deterministic, so the byte-identity
    // gates can exercise the integrate-then-hit path that a timing race otherwise seldom reaches
    // on a fast host. Serial mode only. Never set in production.
    bool prefetch_sync = false;

    // Top-k at or below which drop_cold_frac gets a warning. This is an EVIDENCE boundary, not a
    // physical one: the policy is measured at top-k 8, where the uniform share is 12.5% and the
    // threshold trims a long tail. At top-k 4 that share is 25% and at top-k 2 it is 50%, so the
    // same fraction removes a far larger part of the routing — a different regime, unmeasured.
    // Nothing in the streaming path reads this; it only decides whether the caller is told.
    static constexpr int drop_low_topk_warn = 4;

    static constexpr int cache_min_mb = 1500; // smallest non-pathological cache (see above)
    static constexpr int io_threads_max = 8;
    static constexpr int prefetch_layers_max = 8;
    static constexpr int route_ahead_max = 8; // beyond this the staleness has no measured meaning
};

// Where the draft tokens of a self-speculative step come from. The verify half of the loop is
// identical for both sources; only the producer differs, and with it what a draft costs.
enum class DraftSource {
    none,  // no speculation: one token per decode
    mtp,   // the model's own trained multi-token-prediction head (needs the nextn block)
    ngram, // prompt-lookup over prompt + generated tokens (needs nothing from the model)
};

// Self-speculative decoding: draft draft_max continuation tokens, then verify all of them in ONE
// decode and accept the longest prefix whose argmax agrees with the draft. Nothing is approximated
// and no weight is skipped, so this is a latency optimisation, not a quality trade.
//
// It is NOT byte-identical the way overlap and prefetch are, and must not be used in a byte-identity
// gate. Verification evaluates 1 + draft_max positions in one batch, and a batched matmul is not
// bit-identical to that many single-token ones; on a near-tie the argmax can flip. Measured on
// Qwen3.6-35B-A3B-MXFP4 over 128 greedy tokens: one token differs from an unspeculated run, and
// every draft width agrees with every other. The caveat is a property of the batched verify, so it
// applies to every draft source. See docs/mtp.md.
//
// Why it can win, and why it can lose. Verifying N positions in one decode reads the dense weights
// and each routed expert ONCE for N tokens instead of N times, which is the whole prize: on a
// DRAM-bandwidth-bound host it amortises the measured bottleneck directly, and on a flash-streamed
// device it amortises latency-to-ready. The counterweight is that the N verify positions route
// INDEPENDENTLY, so a layer's read set widens toward N*k experts instead of k. Measured at draft 3
// on the host, that widening is 97.1% of the extra bytes a speculated run streams — it is what the
// choice of source cannot change. Default off until the A/B says otherwise on the target device.
struct SpecConfig {
    DraftSource source = DraftSource::none;
    // Optional standalone MTP-only GGUF. Empty means use the model's own embedded MTP block.
    std::string draft_model_path;

    // Tokens drafted per verify batch. The verify decode is 1 + draft_max positions wide, so this
    // sets both the ceiling on tokens-per-decode and the width of the read-set widening above.
    // Past the source's acceptance horizon the extra drafts are rejected and paid for anyway, which
    // is why the useful range is small; 3 is upstream's default for a single trained head.
    int draft_max = 3;

    // MTP only. Confidence floor for continuing to draft, as the head's own probability for the
    // token it is proposing. At 0 the head is asked for draft_max tokens unconditionally, however
    // unsure it is; above 0 it stops as soon as its best candidate falls below this, making the
    // draft width adaptive per step at no cost.
    //
    // This is the cheap half of expert-cost-aware drafting, and on a streamed device it pays twice:
    // a draft not made is a pass through the MTP block (with its own MoE FFN) that does not happen,
    // AND one fewer position in the verify batch, so one fewer independent routing widening the
    // layer's read set. A rejected draft costs both of those and buys nothing.
    //
    // 0 by default — it is the width the host measurement was taken at, and the useful value is a
    // property of the device's balance between drafting cost and acceptance, so it is a knob to
    // measure rather than a constant to guess.
    float draft_p_min = 0.0f;

    // N-gram only. Shortest suffix match that is allowed to draft. This is the whole economics of
    // the n-gram source: below it the step drafts NOTHING and costs exactly a plain decode, so the
    // floor of the feature is the baseline rather than a loss. Raising it buys precision (fewer,
    // better drafts) at the cost of coverage. 3 because free prose rarely repeats a trigram, which
    // is what keeps prose runs on the floor while copy-heavy segments still match.
    int ngram_min_match = 3;

    // N-gram only. Longest suffix considered when looking for a match. A cap, not a target: it
    // bounds the per-step scan (O(corpus * ngram_max_match)) and stops a long verbatim quote from
    // making every step scan its full length for no additional selectivity.
    int ngram_max_match = 12;

    static constexpr int draft_max_limit = 8;
    static constexpr int ngram_match_limit = 64;

    bool enabled() const { return source != DraftSource::none; }
    bool is_mtp() const { return source == DraftSource::mtp; }
    bool is_ngram() const { return source == DraftSource::ngram; }
};

// Prefill on an accelerator, decode on the CPU. Off unless `device` names a ggml device.
//
// Prefill and decode want opposite hardware. A prefill graph is hundreds of tokens wide, so a
// matrix engine (the Hexagon HMX, a GPU) runs it at many times the CPU's rate; a decode graph is
// one token wide, and on unified memory the per-graph boundary cost of an accelerator eats what it
// saves there. So the weights are moved per GRAPH: before a wide prefill graph the layer weights
// are rebound onto the device's own buffer, and afterwards back onto the CPU mapping. The llama.cpp
// scheduler assigns every op to the backend holding its weight, and it re-decides that on every
// graph it builds, so the rebind is all it takes — no llama.cpp change.
//
// The one hazard is graph REUSE: llama.cpp skips rebuilding (and re-scheduling) a graph of the same
// shape as the previous one. The invariant that makes the rebind safe is therefore about widths:
// every graph run on the device is at least `min_tokens` wide and every graph run on the CPU is
// narrower, so two consecutive graphs on different placements never share a shape.
struct PrefillDeviceConfig {
    // ggml device name as the backend registry reports it (e.g. "HTP0" for the Hexagon NPU).
    // Empty = off. A local device only: no front-end registers a remote (RPC) one.
    std::string device;

    // Narrowest prefill graph sent to the device. A prompt is fed in ubatch-wide pieces; pieces at
    // least this wide run on the device and a shorter tail runs on the CPU. It must exceed every
    // graph width the CPU path uses: one token for plain decode, and 1 + spec.draft_max positions
    // for a speculative verify batch (config.cpp validates both).
    int min_tokens = 32;

    // Loader threads of the streamed-expert arena (with moe.enabled). Separate from moe.io_threads,
    // which sets the decode's read lanes: a prefill graph has the whole CPU idle while the device
    // computes, and each loader both reads and repacks (a K-quant repack is CPU-heavy), while decode
    // wants few lanes. Measured on a Q4_K_M: 4 loaders left the device waiting 10.3 s of a 15.1 s
    // prefill, 8 left it 5.0 of 10.0.
    int load_threads = 8;
    static constexpr int load_threads_max = 16;

    // TEST ONLY: sleep this long before the first upload of each layer in the arena. On a tiny
    // model the loaders always beat the graph to the next layer, so a missing barrier would go
    // unnoticed; slowed down, the barrier is the only thing keeping compute behind the loads, and the
    // gate proves it. Never set by a front-end.
    int test_load_delay_us = 0;

    // Read only the experts each device graph routes to, predicted from the previous graph's routing
    // and completed at each routing node (DeviceExpertArena::set_routed); the result is bit for bit
    // the same as reading whole layers, which `false` restores. Only the expert arena of a streamed
    // model reads experts, so elsewhere it has no effect. `routed_full_frac`: a layer routing more
    // than this fraction of its experts gets the next layer read whole.
    bool routed = true;
    float routed_full_frac = 0.85f;
    static constexpr float routed_full_frac_min = 0.0f; // exclusive: 0 would read every layer whole
    static constexpr float routed_full_frac_max = 1.0f; // inclusive: 1 never falls back
    // TEST ONLY: in routed mode, skip the reads at the routing node, so the graph computes on whatever
    // the slot held for the experts the prediction missed. The gate uses it to prove it would see that.
    bool test_routed_skip_demand = false;

    static constexpr int min_tokens_floor = 2; // decode is one token wide; this keeps the shapes apart

    // Logit rows a graph may produce, with the device on. llama.cpp reserves compute memory for as many
    // as the ubatch is wide, and a row is the whole vocabulary: 2048 rows of a 248k-token vocabulary
    // were 2 GB of reservation (measured on a 35B-A3B), which starved decode into thrashing. A prompt
    // needs one row; a perplexity pass is fed in pieces this wide instead.
    static constexpr int max_outputs = 128;

    bool enabled() const { return !device.empty(); }
};

// Whether Session::decide() keeps the model state after a request's prefix and restores it when the
// next request's prefix extends it (bmoe/decide.h).
enum class PrefixCacheMode {
    // On where splitting a prompt at the prefix costs only the tokens on each side — the CPU, where
    // prefill time scales with the tokens fed. Off where every prefill graph costs about the same at
    // any width, because there a second graph for the few tokens after the prefix costs as much as
    // prefilling the whole prompt again.
    Auto,
    On,
    Off,
};

// Stable lowercase spelling ("auto", "on", "off"), shared by the CLI flag and the telemetry.
const char * prefix_cache_mode_name(PrefixCacheMode m);
// The inverse of prefix_cache_mode_name. False, and `out` untouched, on any other spelling.
bool parse_prefix_cache_mode(const std::string & s, PrefixCacheMode & out);

// Session::decide() policy. Fixed for the session.
struct DecideConfig {
    // Off by default: decide() then refuses every request and nothing is allocated for it, so a
    // session that does not use decisions is exactly what it was before the feature existed.
    bool enabled = false;
    PrefixCacheMode prefix_cache = PrefixCacheMode::Auto;
    // Experimental diagnostic: append one JSONL line per decision to this file, with the experts each
    // layer routed and the answer read at every layer's exit (see core/src/moe/decide_probe.h).
    // Empty = off. Needs the eval callback, i.e. --moe-stream or a prefill device.
    std::string probe_path;
};

// A full run: model, prompt, decoding, streaming, telemetry.
struct RunConfig {
    std::string model_path;
    std::string prompt = "The capital of Japan is";
    int n_predict = 128;
    int n_threads = 4;
    int n_ctx = 2048;

    // Largest batch computed in one graph, i.e. the prefill chunk size. 0 (the default) means
    // "follow n_ctx", which prefills any fitting prompt in a single pass.
    //
    // It is worth exposing because it does not only cost time, it costs RESIDENT MEMORY: the
    // scheduler reserves compute buffers for the worst-case graph, which is a full-width prefill,
    // and on this engine every MiB reserved is a MiB the expert cache and the dense weights do not
    // get. Measured at n_ctx 2048: 320 MiB of compute buffer, falling to 80 MiB at 512 — the
    // reservation scales with the context, which is exactly the coupling this knob breaks. It was
    // found while chasing a fault storm that turned out to be the reservation itself, not the
    // workload.
    //
    // Decode is unaffected: a decode graph is one token wide whatever this says. The cost is
    // prefill throughput, which processes a long prompt in more, smaller passes.
    int n_ubatch = 0;
    bool chatml = false;   // wrap the prompt in the model family's chat turn (arch-aware)
    bool progress = false; // emit machine telemetry (one JSON line per token)

    // Render the chat template with reasoning enabled. Passed to the template as the
    // `enable_thinking` kwarg, so a reasoning model (Qwen3, thinking Gemma, …) only emits
    // its thinking channel when true. Off suppresses reasoning at the source rather than
    // relying on the display-time parser, which cannot strip a format it does not know.
    // Only meaningful with chatml; the raw-prompt path ignores it.
    bool think = true;

    // Override the number of active MoE experts per token (top-k routing). 0 = use the
    // model's own <arch>.expert_used_count from the gguf. A lower value cuts per-token
    // compute (and, with moe.enabled, flash I/O) proportionally, at a quality cost — it
    // changes the output. Applied at load via a llama.cpp kv_override on the arch-prefixed
    // expert_used_count metadata key; must stay in [1, n_expert]. Independent of streaming.
    int n_expert_used = 0;

    // Compute-trace granularity. false (default): a barrier per graph node — exact per-op
    // attribution, but it serializes the graph against the expert stream and distorts the run.
    // true: a barrier only at layer boundaries, cheap enough that the traced numbers stay close
    // to an untraced run. Only meaningful when a compute-trace sink is attached; see
    // bmoe/decode_trace.h for what the layer-mode rows contain.
    bool compute_trace_layers = false;

    SamplingConfig sampling; // greedy by default (temp <= 0); opt-in stochastic decoding
    MoeStreamConfig moe;
    SpecConfig spec;             // self-speculative decoding (MTP head or n-gram lookup); off by default
    PrefillDeviceConfig prefill; // prefill graphs on an accelerator; off by default
    DecideConfig decide;         // decide()'s prefix-state policy; off by default
};

// Validation result: ok plus a human-readable reason when not.
struct ValidationResult {
    bool ok = true;
    std::string error;
    explicit operator bool() const { return ok; }
};

// Check a RunConfig for internal consistency. Enforces, among others: MoE streaming
// requires a model path; cache_mb is 0 or >= cache_min_mb (unless force_cache);
// io_threads in range; n_predict/n_threads positive. Pure function — no I/O.
ValidationResult validate(const RunConfig & cfg);

} // namespace bmoe
