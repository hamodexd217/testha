# Smart context management

Opt-in (Settings -> Context -> "Automatic context management", default OFF). With it off nothing about loading changes:
the number typed in the Context field is what the engine opens with.

## What it does
* `GgufInspector` now also reads the attention layout from the GGUF header (layers, KV heads, key/value length,
  per-layer KV-head arrays, `full_attention_interval`, `nextn_predict_layers`, `ssm.*`, `context_length`) into a `KvShape`.
* `MemoryBudget` (pure Kotlin) turns that, the load settings and a memory snapshot into an ESTIMATE:
  model weights (MoE: dense part + expert cache by cache mode; dense: whole file) + KV cache (F16, which is what the engine
  opens with; cells padded to 256) + MTP draft-layer KV + recurrent state (x(1+draftMax) with MTP) + working buffers
  + vision projector / sidecar draft file sizes.
* The budget is `AutoTuner.usableMb` (the same cautious number Auto settings uses), cut 15% / 30% when Android reports
  pressure. A recommendation is the largest value of 1024..131072 whose estimate, with the estimated parts padded 15%,
  fits the budget and which is not above the model's trained context (16384 when the model states none).
* `ContextManager.resolve()` is called by the three places that load a model for the user (Models page / chat picker
  load and reload, Settings "Reload model now", load-on-start). It only chooses `nCtx`; the model still opens through
  `EngineController.loadModel` (one engine session). The manual value is never written.
* After a load that fails with an out-of-memory-looking error the Models page / chat picker ASK before retrying with the
  next smaller supported context. One retry per tap, stops at 1024, saved setting untouched.

## Estimated vs measured
| Shown as | Source |
|---|---|
| Estimated, not measured | `MemoryBudget` (header + settings) |
| Measured by Android | `ActivityManager.getMemoryInfo`, `Debug.MemoryInfo` PSS, `onTrimMemory` |
| Measured by the engine | `ctx_alloc_mib`: anonymous-memory growth around `llama_init_from_model` (approximate) |

No polling: a snapshot is taken when a decision is made or the Settings screen opens; pressure arrives through
`Application.onTrimMemory`.

## Limits
* It cannot predict Android's low-memory killer. The budget is a cautious heuristic, not a guarantee.
* KV cache types other than F16 are modelled but the engine does not expose them.
* Hybrid / recurrent state and MLA layouts are approximated from header fields.
* Auto-tune measurement loads use their own saved values and do not go through this.
