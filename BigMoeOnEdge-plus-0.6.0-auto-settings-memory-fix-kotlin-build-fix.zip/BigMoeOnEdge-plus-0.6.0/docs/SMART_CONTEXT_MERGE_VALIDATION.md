# Smart context management merge — validation report

## Integrated

- Merged the supplied Smart Context Management ZIP into the latest migration-progress-03 source tree.
- Kept the progress-03 work (Appearance collapsed by default, Cache Brake, structured-output plumbing, upstream logging/expert-layout/tensor-name additions) while merging the context-management changes.
- Added the opt-in Automatic context management flow, GGUF KV-shape inspection, memory budget estimates, event-driven Android memory-pressure tracking, Settings diagnostics, model-load routing, and confirm-before-retry behavior for OOM-like load errors.
- Kept the manual context setting intact; automatic context management defaults off.
- Kept the existing llama.cpp subtree from the progress-03 target rather than replacing it with the uploaded archive's copy.

## Checks actually run

- Merge-marker scan outside `third_party/llama.cpp`: passed (no conflict markers remain).
- Required-file integrity check: passed.
- Host CMake build of `bmoe_core` with `BMOE_HAVE_LLAMA=OFF`: passed.
- Host `cache_brake_test`: passed (1/1).

## Not verified

- Android Gradle tests/build/APK were not run: the Gradle wrapper attempted to download Gradle 8.9 from `services.gradle.org`, but network DNS was unavailable (`UnknownHostException`).
- Kotlin unit tests, NDK build, Hexagon/NPU behavior, real GGUF memory estimates, model-load recovery, and device behavior were not executed.
- Context sizes are estimates and cannot guarantee protection against Android's low-memory killer. The feature is opt-in and does not change the saved manual context value.
