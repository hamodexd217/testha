# BigMoeOnEdge+ Changelog

## 0.5.8 — 2026-10-22

- Fixed the Android NPU workflow to run Gradle from the project root and use the correct root-relative APK path.
- Hardened the Hexagon CMake path with explicit SDK/toolchain validation, the existing `PREBUILT_LIB_DIR=android_aarch64` selector, a fresh build directory, and stale-output invalidation. The reported SDK `string(FIND...)` failure is not reproduced here and remains pending a real toolchain CI run.
- Updated the native-build container reference to the documented Snapdragon toolchain `v0.8` image and added ELF/backend-marker/payload validation before packaging and after extracting files back out of the APK.
- Made the Hexagon build script remove only its own staged libraries instead of deleting the entire `jniLibs/arm64-v8a` directory.
- Added a source-level NPU validator and made settings/upstream wiring validators follow the current app version instead of hard-coding 0.5.7.
- Clarified that a successful CI package is not proof of on-device HTP execution; runtime verification on a supported Snapdragon device is still required.

This is an NPU build-pipeline hardening change. It does not claim an APK has been built or benchmarked in this environment.

## 0.5.7 — 2026-10-22

- Reorganized Engine Performance into four grouped cards: Hexagon prefill, MoE streaming/I/O, speed/quality, and CPU compute/memory.
- Added native-wired controls for batch/prefill threads, ubatch width, sampling seed, two-wave I/O, row-stream window, NPU routing thresholds, N-gram matching, drop normalization/prefill, and expert-stream diagnostics.
- Added the upstream decision-prefix-cache policy to the scored-choice API settings.
- Added an explicit force switch for expert-cache sizes below 1500 MiB while keeping the previous BigMoeOnEdge+ default behavior.
- Enabled I/O/compute overlap in fresh-install defaults. The native build still reports overlap inactive when the expert-ready hook is absent or streaming/cache is unavailable.
- Made Hexagon/NPU controls visible in CPU-only builds, disabled with an explanation instead of hiding the settings.
- Added a source-level parity inventory separating supported options from unsupported desktop/GPU/planner/debug-only options.
- Preserved BigMoeOnEdge+ identity, API, database, MTP sidecar flow, and custom UI.

This is a settings/UI/native-wiring update on the existing local engine baseline, not a wholesale merge of upstream 0.33.x.

## 0.5.6 — 2026-10-21

- Fixed host-side handling of routing index tensors whose buffers are owned by a non-host backend.
- Avoided streaming/rebinding device-owned expert weight tensors and restricted route-mutating diagnostics to host-readable tensors.
- Preserved BigMoeOnEdge+ UI, API, multimodal, persistence, split-GGUF, and custom MTP paths.
- Documented the current upstream boundary and verification limits in `docs/UPSTREAM_UPGRADE_0.5.6.md`.

This is a compatibility fix on the existing 0.28.0 engine baseline, revisioned locally as 0.28.1. It is not a wholesale merge of upstream 0.33.x.
