# BigMoeOnEdge+ Changelog

## 0.5.6 — 2026-10-21

- Fixed host-side handling of routing index tensors whose buffers are owned by a non-host backend.
- Avoided streaming/rebinding device-owned expert weight tensors and restricted route-mutating diagnostics to host-readable tensors.
- Preserved BigMoeOnEdge+ UI, API, multimodal, persistence, split-GGUF, and custom MTP paths.
- Documented the current upstream boundary and verification limits in `docs/UPSTREAM_UPGRADE_0.5.6.md`.

This is a compatibility fix on the existing 0.28.0 engine baseline, revisioned locally as 0.28.1. It is not a wholesale merge of upstream 0.33.x.
