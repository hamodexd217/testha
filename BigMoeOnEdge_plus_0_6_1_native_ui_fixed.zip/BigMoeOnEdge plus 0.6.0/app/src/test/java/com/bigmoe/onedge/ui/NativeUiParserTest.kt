package com.bigmoe.onedge.ui

import com.bigmoe.onedge.ui.chat.NativeUiParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class NativeUiParserTest {
    @Test
    fun parsesRichNativeComponentsTogether() {
        val spec = NativeUiParser.parse(
            """{
              "type":"rich","title":"Device overview","description":"Compact summary",
              "badges":[{"label":"Verified","tone":"success"}],
              "metrics":[{"label":"RAM","value":"12 GB","detail":"Installed"}],
              "comparison":{"title":"Compare","leftTitle":"A","rightTitle":"B","rows":[{"label":"Memory","left":"12 GB","right":"16 GB","highlight":true}]},
              "slides":[{"title":"Slide one","subtitle":"Intro","body":"Details","metricLabel":"Score","metricValue":"92"}],
              "lists":[{"title":"Steps","style":"ordered","items":[{"title":"First","detail":"Start"},"Second"]}],
              "cards":[{"title":"Option A","subtitle":"Fast","body":"Details"}],
              "bars":[{"label":"Progress","value":70,"valueLabel":"70%"}],
              "timeline":[{"time":"Today","title":"Done","detail":"Completed","status":"done"}],
              "sections":[{"title":"More","body":"Expanded details"}],
              "actions":[{"label":"Explain","prompt":"Explain this"}]
            }""".trimIndent()
        )

        assertNotNull(spec)
        assertEquals("Device overview", spec!!.title)
        assertEquals(1, spec.badges.size)
        assertEquals("12 GB", spec.metrics.single().value)
        assertTrue(spec.comparison!!.rows.single().highlight)
        assertEquals("Slide one", spec.slides.single().title)
        assertEquals(2, spec.lists.single().items.size)
        assertEquals("Second", spec.lists.single().items.last().title)
        assertEquals(1, spec.cards.size)
        assertEquals(70.0, spec.bars.single().value, 0.0)
        assertEquals("done", spec.timeline.single().status)
        assertEquals("Expanded details", spec.sections.single().body)
        assertEquals("Explain this", spec.actions.single().prompt)
    }

    @Test
    fun clampsProgressAndBoundsComponentCollections() {
        val metrics = (0..10).joinToString(",") { "{\"label\":\"M$it\",\"value\":\"$it\"}" }
        val spec = NativeUiParser.parse(
            """{"type":"dashboard","title":"Limits","metrics":[$metrics],"bars":[{"label":"Over","value":150}]}"""
        )
        assertNotNull(spec)
        assertEquals(8, spec!!.metrics.size)
        assertEquals(100.0, spec.bars.single().value, 0.0)
        assertEquals("100%", spec.bars.single().valueLabel)
    }

    @Test
    fun rejectsUnknownTypesMalformedJsonAndEmptyLayouts() {
        assertNull(NativeUiParser.parse("not json"))
        assertNull(NativeUiParser.parse("{\"type\":\"unknown\",\"title\":\"X\"}"))
        assertNull(NativeUiParser.parse("{\"type\":\"dashboard\",\"title\":\"Empty\"}"))
    }
}
