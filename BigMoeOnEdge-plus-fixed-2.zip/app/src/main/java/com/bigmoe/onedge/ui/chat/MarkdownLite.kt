package com.bigmoe.onedge.ui.chat

sealed interface MarkdownBlock {
    data class Paragraph(val text: String) : MarkdownBlock
    data class Code(val language: String, val code: String, val closed: Boolean, val fileName: String? = null) : MarkdownBlock
    data class Prompt(val text: String, val closed: Boolean = true) : MarkdownBlock
}

/** Small, dependency-free markdown parser designed for streaming chat text. */
object MarkdownLite {
    fun parse(text: String): List<MarkdownBlock> {
        if (text.isEmpty()) return emptyList()
        val lines = text.replace("\r\n", "\n").replace('\r', '\n').split('\n')
        val blocks = ArrayList<MarkdownBlock>()
        val prose = StringBuilder()
        var code: StringBuilder? = null
        var codeLanguage = ""
        var codeFileName: String? = null
        var prompt: StringBuilder? = null

        fun flushProse() {
            val value = prose.toString().trimEnd()
            if (value.isNotBlank()) blocks.add(MarkdownBlock.Paragraph(value))
            prose.setLength(0)
        }

        fun flushPrompt() {
            val value = prompt?.toString()?.trim() ?: return
            if (value.isNotBlank()) blocks.add(MarkdownBlock.Prompt(value))
            prompt = null
        }

        var i = 0
        while (i < lines.size) {
            val line = lines[i]

            if (code != null) {
                if (FENCE_CLOSE.matches(line.trim())) {
                    blocks.add(MarkdownBlock.Code(codeLanguage, code.toString().trimEnd('\n'), true, codeFileName))
                    code = null
                    codeLanguage = ""
                    codeFileName = null
                } else {
                    code!!.append(line).append('\n')
                }
                i++
                continue
            }

            if (prompt != null) {
                if (PROMPT_DELIMITER.matches(line.trim())) {
                    flushPrompt()
                } else {
                    prompt!!.append(line).append('\n')
                }
                i++
                continue
            }

            val fence = FENCE_OPEN.matchEntire(line)
            if (fence != null) {
                flushProse()
                code = StringBuilder()
                codeLanguage = fence.groupValues[1].trim()
                val info = fence.groupValues[2].trim()
                codeFileName = Regex("(?:filename\\s*=\\s*)?([^\\s]+\\.[A-Za-z0-9]{1,8})", RegexOption.IGNORE_CASE)
                    .find(info)?.groupValues?.get(1)
                i++
                continue
            }

            if (PROMPT_DELIMITER.matches(line.trim())) {
                // Treat --- as a prompt delimiter only when a matching closing delimiter exists.
                val close = (i + 1 until lines.size).firstOrNull { PROMPT_DELIMITER.matches(lines[it].trim()) }
                if (close != null) {
                    flushProse()
                    prompt = StringBuilder()
                    i++
                    continue
                }
            }

            prose.append(line).append('\n')
            i++
        }

        if (code != null) {
            // While streaming, an open fence is still a code block; it remains visible but has no destructive/open action.
            blocks.add(MarkdownBlock.Code(codeLanguage, code.toString().trimEnd('\n'), false, codeFileName))
        } else if (prompt != null) {
            // Malformed/incomplete prompt block: preserve it as ordinary text.
            prose.append("---\n").append(prompt.toString())
        }
        flushProse()
        return blocks
    }

    private val FENCE_OPEN = Regex("^\\s*```([A-Za-z0-9_+.-]*)([^`]*)$")
    private val FENCE_CLOSE = Regex("^```\\s*$")
    private val PROMPT_DELIMITER = Regex("^\\s*---\\s*$")
}
