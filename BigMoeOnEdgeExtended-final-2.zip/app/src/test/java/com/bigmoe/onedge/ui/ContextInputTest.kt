package com.bigmoe.onedge.ui

import com.bigmoe.onedge.ui.settings.ContextInput
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ContextInputTest {
    @Test fun acceptsAnyNumberInRange() {
        assertEquals(4096, ContextInput.parse("4096"))
        assertEquals(6000, ContextInput.parse("6000"))
        assertEquals(ContextInput.MIN, ContextInput.parse("256"))
        assertEquals(ContextInput.MAX, ContextInput.parse("131072"))
    }

    @Test fun rejectsEmptyOutOfRangeAndText() {
        assertNull(ContextInput.parse(""))
        assertNull(ContextInput.parse("255"))
        assertNull(ContextInput.parse("131073"))
        assertNull(ContextInput.parse("12a"))
    }

    @Test fun sanitizeKeepsDigitsOnly() {
        assertEquals("4096", ContextInput.sanitize("4 096"))
        assertEquals("123456", ContextInput.sanitize("1234567890"))
        assertEquals("", ContextInput.sanitize("abc"))
    }
}
