package com.bigmoe.onedge.ui.settings

/** The typed "Context (tokens)" setting. Pure Kotlin (unit-tested); the range is the one the DataStore enforces. */
object ContextInput {
    const val MIN = 256
    const val MAX = 131_072

    /** Keeps digits only (the keyboard is numeric, but pasted text may not be) and at most six of them. */
    fun sanitize(raw: String): String = raw.filter { it in '0'..'9' }.take(6)

    /** The number to store, or null while the text is empty, not a number, or outside [MIN]..[MAX]. */
    fun parse(text: String): Int? = text.toIntOrNull()?.takeIf { it in MIN..MAX }
}
