<script lang="ts">
	import { ArrowUp, Edit, Trash2 } from '@lucide/svelte';
	import { ActionIcon, ChatMessageEditForm, ChatMessageUserBubble } from '$lib/components/app';
	import { useChatMessageEditContext } from '$lib/hooks/use-chat-message-edit-context.svelte';

	interface Props {
		class?: string;
		content: string;
		extras?: DatabaseMessageExtra[];
		onSendImmediately: () => void;
		onEdit: (newContent: string, extras?: DatabaseMessageExtra[]) => void;
		onDelete: () => void;
	}

	let {
		class: className = '',
		content,
		extras = [],
		onDelete,
		onEdit,
		onSendImmediately
	}: Props = $props();

	const editCtx = useChatMessageEditContext({
		getContent: () => content,
		getExtras: () => extras,
		onSave: (content, extras) => onEdit(content, extras)
	});
</script>

<div
	aria-label="Pending user message"
	class="group flex flex-col items-end gap-3 transition-opacity hover:opacity-80 md:gap-2 {className} sticky bottom-32"
	role="group"
>
	{#if editCtx.isEditing}
		<ChatMessageEditForm />
	{:else}
		<ChatMessageUserBubble
			attachments={extras}
			cardBgClass="dark:bg-primary/8"
			{content}
			maxHeightStyle="overflow-wrap: anywhere; word-break: break-word;"
			textColorClass="text-muted-foreground"
		/>

		<div class="max-w-[80%]">
			<div class="relative flex h-6 items-center justify-between">
				<div class="right-0 flex items-center gap-2 opacity-100 transition-opacity">
					<div
						class="pointer-events-auto inset-0 flex items-center gap-1 opacity-0 transition-all duration-150 group-hover:opacity-100"
					>
						<ActionIcon icon={Edit} onclick={editCtx.handleEdit} tooltip="Edit" />

						<ActionIcon icon={Trash2} onclick={onDelete} tooltip="Delete" />

						<ActionIcon icon={ArrowUp} onclick={onSendImmediately} tooltip="Send immediately" />
					</div>
				</div>
			</div>
		</div>
	{/if}
</div>
