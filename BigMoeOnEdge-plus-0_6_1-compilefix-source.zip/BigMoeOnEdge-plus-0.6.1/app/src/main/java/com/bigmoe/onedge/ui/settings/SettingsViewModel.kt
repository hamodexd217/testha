package com.bigmoe.onedge.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.bigmoe.onedge.core.DenseWeights
import com.bigmoe.onedge.core.DecisionPrefixCache
import com.bigmoe.onedge.core.SpecSource
import com.bigmoe.onedge.core.EngineController
import com.bigmoe.onedge.core.EngineState
import com.bigmoe.onedge.core.ModelManager
import com.bigmoe.onedge.data.local.datastore.EngineSettings
import com.bigmoe.onedge.data.local.datastore.EngineSettingsDataStore
import com.bigmoe.onedge.data.local.datastore.AppVisualStyle
import com.bigmoe.onedge.data.local.datastore.WebSearchMode
import com.bigmoe.onedge.ui.theme.PalettePresets
import com.bigmoe.onedge.ui.theme.PaletteSpec
import com.bigmoe.onedge.ui.theme.PaletteStore
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val dataStore: EngineSettingsDataStore,
    private val engineController: EngineController,
    private val modelManager: ModelManager,
    private val apiServer: com.bigmoe.onedge.server.ApiServerController
) : ViewModel() {

    /** null until the first DataStore read finished, so the screen never seeds text fields with defaults. */
    val settingsState: StateFlow<EngineSettings?> = dataStore.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val engineState: StateFlow<EngineState> = engineController.state
    val npuPrefillAvailable: Boolean get() = engineController.capabilities.npuPrefill
    val npuPrefillStatus: String get() = engineController.npuPrefillStatus

    private fun launch(block: suspend () -> Unit) {
        viewModelScope.launch { block() }
    }

    // ---- per-request (apply to the next message) ----
    fun updateSystemPrompt(v: String) = launch { dataStore.updateSystemPrompt(v) }
    fun updateMaxTokens(v: Int) = launch { dataStore.updateMaxTokens(v) }
    fun updateThinkingEnabled(v: Boolean) = launch { dataStore.updateThinkingEnabled(v) }
    fun updateWebSearchEnabled(v: Boolean) = launch { dataStore.updateWebSearchEnabled(v) }
    fun updateWebSearchMode(v: WebSearchMode) = launch { dataStore.updateWebSearchMode(v) }
    fun updateInteractiveUiEnabled(v: Boolean) = launch { dataStore.updateInteractiveUiEnabled(v) }
    fun updateImageSearchEnabled(v: Boolean) = launch { dataStore.updateImageSearchEnabled(v) }
    fun updateAutoImageSearchAfterWebSearch(v: Boolean) = launch { dataStore.updateAutoImageSearchAfterWebSearch(v) }
    fun updateBraveApiKey(v: String) = launch { dataStore.updateBraveApiKey(v.trim()) }
    fun updateSearxngUrl(v: String) = launch { dataStore.updateSearxngUrl(v.trim()) }
    fun updateToolsFilesEnabled(v: Boolean) = launch { dataStore.updateToolsFilesEnabled(v) }
    fun updateToolsCodeEnabled(v: Boolean) = launch { dataStore.updateToolsCodeEnabled(v) }
    fun updateToolsUtilitiesEnabled(v: Boolean) = launch { dataStore.updateToolsUtilitiesEnabled(v) }
    fun updateToolResultChars(v: Int) = launch { dataStore.updateToolResultChars(v) }
    fun updateThinkAfterTools(v: Boolean) = launch { dataStore.updateThinkAfterTools(v) }
    fun updateImageMaxDim(v: Int) = launch { dataStore.updateImageMaxDim(v) }
    fun updateVideoFrames(v: Int) = launch { dataStore.updateVideoFrames(v) }

    // ---- engine (apply after the model is reloaded) ----
    fun updateContextLength(v: Int) = launch { dataStore.updateContextLength(v) }
    fun updateThreadCount(v: Int) = launch { dataStore.updateThreadCount(v) }
    fun updateBatchThreadCount(v: Int) = launch { dataStore.updateBatchThreadCount(v) }
    fun updateBatchWidth(v: Int) = launch { dataStore.updateBatchWidth(v) }
    fun updateTemperature(v: Float) = launch { dataStore.updateTemperature(v) }
    fun updateTopP(v: Float) = launch { dataStore.updateTopP(v) }
    fun updateTopK(v: Int) = launch { dataStore.updateTopK(v) }
    fun updateSeed(v: Int) = launch { dataStore.updateSeed(v) }
    fun updateCacheMb(v: Int) = launch { dataStore.updateCacheMb(v) }
    fun updateCacheCeilMb(v: Int) = launch { dataStore.updateCacheCeilMb(v) }
    fun updateCacheFloorMb(v: Int) = launch { dataStore.updateCacheFloorMb(v) }
    fun updateIoThreads(v: Int) = launch { dataStore.updateIoThreads(v) }
    fun updateODirect(v: Boolean) = launch { dataStore.updateODirect(v) }
    fun updateOverlap(v: Boolean) = launch { dataStore.updateOverlap(v) }
    fun updateIoTwoWave(v: Boolean) = launch { dataStore.updateIoTwoWave(v) }
    fun updateDenseWeights(v: DenseWeights) = launch { dataStore.updateDenseWeights(v) }
    fun updateRowStreamMb(v: Int) = launch { dataStore.updateRowStreamMb(v) }
    fun updateNExpertUsed(v: Int) = launch { dataStore.updateNExpertUsed(v) }
    fun updateDropColdPct(v: Int) = launch { dataStore.updateDropColdPct(v) }
    fun updateDropRenorm(v: Boolean) = launch { dataStore.updateDropRenorm(v) }
    fun updateDropInPrefill(v: Boolean) = launch { dataStore.updateDropInPrefill(v) }
    fun updateSubstitutePct(v: Int) = launch { dataStore.updateSubstitutePct(v) }
    fun updatePrefetchLayers(v: Int) = launch { dataStore.updatePrefetchLayers(v) }
    fun updatePredictPrefetch(v: Boolean) = launch { dataStore.updatePredictPrefetch(v) }
    fun updatePredictSpecMax(v: Int) = launch { dataStore.updatePredictSpecMax(v) }
    fun updatePredictionProbe(v: Boolean) = launch { dataStore.updatePredictionProbe(v) }
    fun updateRouteAhead(v: Int) = launch { dataStore.updateRouteAhead(v) }
    fun updateRowStream(v: Boolean) = launch { dataStore.updateRowStream(v) }
    fun updateLoadAllExpertsForBenchmark(v: Boolean) = launch { dataStore.updateLoadAllExpertsForBenchmark(v) }
    fun updateReleaseMmap(v: Boolean) = launch { dataStore.updateReleaseMmap(v) }
    fun updateSpec(v: SpecSource) = launch { dataStore.updateSpec(v) }
    fun updateDraftMax(v: Int) = launch { dataStore.updateDraftMax(v) }
    fun updateMtpPMinPct(v: Int) = launch { dataStore.updateMtpPMinPct(v) }
    fun updateSeparateMtpDraftEnabled(v: Boolean) = launch { dataStore.updateSeparateMtpDraftEnabled(v) }
    fun updateMetricsCsv(v: Boolean) = launch { dataStore.updateMetricsCsv(v) }
    fun updateNpuPrefill(v: Boolean) = launch { dataStore.updateNpuPrefill(v) }
    fun updateNpuLoaders(v: Int) = launch { dataStore.updateNpuLoaders(v) }
    fun updateNpuMinTokens(v: Int) = launch { dataStore.updateNpuMinTokens(v) }
    fun updateNpuRoutedPrefill(v: Boolean) = launch { dataStore.updateNpuRoutedPrefill(v) }
    fun updateNpuRoutedFullPct(v: Int) = launch { dataStore.updateNpuRoutedFullPct(v) }
    fun updateNgramMinMatch(v: Int) = launch { dataStore.updateNgramMinMatch(v) }
    fun updateNgramMaxMatch(v: Int) = launch { dataStore.updateNgramMaxMatch(v) }
    fun updateDecisionPrefixCache(v: DecisionPrefixCache) = launch { dataStore.updateDecisionPrefixCache(v) }
    fun updateForceCache(v: Boolean) = launch { dataStore.updateForceCache(v) }

    // ---- local API server ----
    fun setServerEnabled(v: Boolean) = launch { apiServer.setEnabled(v) }
    fun updateServerPort(v: Int) = launch { dataStore.updateServerPort(v) }
    fun regenerateServerKey() = launch { apiServer.regenerateKey() }
    fun updateServerRequireKey(v: Boolean) = launch { dataStore.updateServerRequireKey(v) }
    fun updateServerBindAll(v: Boolean) = launch { dataStore.updateServerBindAll(v) }
    fun updateServerForceSettings(v: Boolean) = launch { dataStore.updateServerForceSettings(v) }
    fun updateServerQueueTimeoutSec(v: Int) = launch { dataStore.updateServerQueueTimeoutSec(v) }

    // ---- appearance ----
    fun selectTheme(id: String) = launch { dataStore.updateThemeId(id) }
    fun updateVisualStyle(style: AppVisualStyle) = launch { dataStore.updateVisualStyle(style) }

    /** Saves (insert or replace) a custom palette and selects it. */
    fun saveCustomPalette(palette: PaletteSpec) = launch {
        val current = PaletteStore.parse(dataStore.settingsFlow.first().customPalettesJson)
        dataStore.updateCustomPalettesJson(PaletteStore.serialize(PaletteStore.upsert(current, palette)))
        dataStore.updateThemeId(palette.id)
    }

    fun deleteCustomPalette(id: String) = launch {
        val s = dataStore.settingsFlow.first()
        val remaining = PaletteStore.parse(s.customPalettesJson).filter { it.id != id }
        dataStore.updateCustomPalettesJson(PaletteStore.serialize(remaining))
        if (s.themeId == id) dataStore.updateThemeId(PalettePresets.DEFAULT_LIGHT_ID)
    }

    /** Reloads the current model so the engine settings above take effect. */
    fun reloadModel() = launch {
        val ready = engineController.state.value as? EngineState.Ready ?: return@launch
        val s = dataStore.settingsFlow.first()
        val draftPath = if (s.spec == SpecSource.MTP && s.separateMtpDraftEnabled)
            modelManager.draftForModel(ready.info.path) else null
        engineController.loadModel(ready.info.path, s.toLoadConfig(), ready.info.mmprojPath, draftPath)
    }
}
