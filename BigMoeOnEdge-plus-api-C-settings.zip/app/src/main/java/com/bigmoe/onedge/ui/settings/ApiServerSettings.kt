package com.bigmoe.onedge.ui.settings

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.bigmoe.onedge.core.ModelInfo
import com.bigmoe.onedge.data.local.datastore.EngineSettings
import com.bigmoe.onedge.server.ApiServerController
import kotlinx.coroutines.delay

private const val API_DEBOUNCE_MS = 500L

private val MAX_TOKEN_CHOICES = listOf(0, 1024, 2048, 4096, 8192, 16384, 32768)
private val QUEUE_CHOICES = listOf(5, 15, 30, 60, 120, 300)

private fun copyToClipboard(context: Context, label: String, text: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText(label, text))
    Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
}

/** Rough KV-cache size for the hint under the context field: depends on the model, so it is only an order of magnitude. */
private fun contextRamHint(tokens: Int): String {
    // 2 (K and V) x 48 layers x 4 KV heads x 128 head dim x 2 bytes (f16) per token, the shape of a Qwen3-30B-A3B-class model.
    val perToken = 2L * 48L * 4L * 128L * 2L
    val gib = perToken * tokens.toLong() / (1024.0 * 1024.0 * 1024.0)
    return "About %.1f GiB of KV cache for a model shaped like Qwen3-30B-A3B (48 layers, 4 KV heads); other models differ.".format(gib)
}

/**
 * Settings > "Local API server": on/off, port, endpoint URL (+ copy), API key (+ copy / regenerate), authentication,
 * "Force server settings", context size, thinking, max output tokens, queue wait.
 */
@Composable
internal fun ApiServerSection(
    settings: EngineSettings,
    readyInfo: ModelInfo?,
    viewModel: SettingsViewModel
) {
    val context = LocalContext.current
    var portText by remember { mutableStateOf(settings.serverPort.toString()) }
    var contextText by remember { mutableStateOf(settings.serverContextLength.toString()) }
    var showKey by remember { mutableStateOf(false) }
    val portValid = portText.toIntOrNull()?.let { it in 1024..65535 } == true
    val ctxValid = ContextInput.parse(contextText) != null

    LaunchedEffect(portText) {
        val v = portText.toIntOrNull()
        if (v != null && v in 1024..65535 && v != settings.serverPort) {
            delay(API_DEBOUNCE_MS)
            viewModel.updateServerPort(v)
        }
    }
    LaunchedEffect(contextText) {
        val v = ContextInput.parse(contextText)
        if (v != null && v >= 1024 && v != settings.serverContextLength) {
            delay(API_DEBOUNCE_MS)
            viewModel.updateServerContextLength(v)
        }
    }

    val url = ApiServerController.endpointUrl(settings)
    val authEffective = settings.serverRequireKey || settings.serverBindAll
    val loadedCtx = readyInfo?.nCtx
    val ctxReloadNeeded = settings.serverEnabled && loadedCtx != null && loadedCtx != settings.effectiveContextLength

    Section("Local API server")
    Hint(
        "Lets other apps on this phone (for example Mobile Harness running Claude Code) use the model that is loaded here. " +
            "It speaks the Anthropic Messages API (with streaming and tool use) and the OpenAI chat API."
    )
    Spacer(Modifier.height(8.dp))
    SwitchRow(
        "Server",
        if (settings.serverEnabled) "Running while this switch is on; a notification with a Stop button shows while it runs."
        else "Off. Turning it on generates an API key the first time.",
        settings.serverEnabled
    ) { viewModel.setServerEnabled(it) }
    if (settings.serverEnabled && readyInfo == null) {
        Hint("No model is loaded yet. Requests get HTTP 503 until you load one (Manage models).")
    }

    Spacer(Modifier.height(8.dp))
    OutlinedTextField(
        value = portText,
        onValueChange = { portText = it.filter { c -> c in '0'..'9' }.take(5) },
        label = { Text("Port") },
        singleLine = true,
        isError = !portValid,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.fillMaxWidth()
    )
    Hint(if (portValid) "1024 to 65535. Changing the port restarts the server." else "Enter a port between 1024 and 65535.")

    Spacer(Modifier.height(12.dp))
    Text("Endpoint", style = MaterialTheme.typography.labelMedium)
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(url, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        OutlinedButton(onClick = { copyToClipboard(context, "API endpoint", url) }) { Text("Copy") }
    }
    Hint("Anthropic: $url/v1/messages   OpenAI: $url/v1/chat/completions   Models: $url/v1/models")
    if (settings.serverBindAll) Hint("Replace <device-ip> with this phone's address on the network.")

    Spacer(Modifier.height(12.dp))
    Text("API key", style = MaterialTheme.typography.labelMedium)
    val key = settings.serverApiKey
    Text(
        text = when {
            key.isBlank() -> "(generated when the server is first turned on)"
            showKey -> key
            else -> "••••••••••••" + key.takeLast(4)
        },
        style = MaterialTheme.typography.bodyMedium,
        modifier = Modifier.padding(vertical = 4.dp)
    )
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { showKey = !showKey }, enabled = key.isNotBlank()) { Text(if (showKey) "Hide" else "Show") }
        OutlinedButton(onClick = { copyToClipboard(context, "API key", key) }, enabled = key.isNotBlank()) { Text("Copy key") }
        OutlinedButton(onClick = { viewModel.regenerateServerKey() }) { Text("New key") }
    }
    Hint("Send it as  x-api-key: <key>  or  Authorization: Bearer <key>. A new key stops working clients until you update them.")

    Spacer(Modifier.height(8.dp))
    SwitchRow(
        "Require API key",
        if (settings.serverBindAll) "Always on while the server listens on the network."
        else "Turning this off lets any app on this phone use the model without a key.",
        authEffective,
        enabled = !settings.serverBindAll
    ) { viewModel.updateServerRequireKey(it) }
    if (!authEffective) {
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
            Text(
                "Warning: with the key off, every app on this phone that can reach 127.0.0.1:${settings.serverPort} can run prompts on " +
                    "your model and read what it answers. Only do this if you trust every app installed here.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onErrorContainer,
                modifier = Modifier.padding(12.dp)
            )
        }
        Spacer(Modifier.height(8.dp))
    }
    SwitchRow(
        "Listen on the network (all interfaces)",
        "Off = 127.0.0.1 only, reachable just from this phone (recommended). On = other devices on the same network can connect; the key is then mandatory. Restarts the server.",
        settings.serverBindAll
    ) { viewModel.updateServerBindAll(it) }

    Spacer(Modifier.height(8.dp))
    SwitchRow(
        "Force server settings",
        "Ignore the temperature / top_p / top_k, thinking and max_tokens that clients send. The app's own sampler settings, the thinking switch and the max-output value below are used instead. " +
            "Off: client values are used where the engine supports them (stop sequences and stream are always honoured). " +
            "Every response lists what was ignored in an X-BigMoe-Ignored header.",
        settings.serverForceSettings
    ) { viewModel.updateServerForceSettings(it) }

    Spacer(Modifier.height(12.dp))
    OutlinedTextField(
        value = contextText,
        onValueChange = { contextText = ContextInput.sanitize(it) },
        label = { Text("Context size (tokens)") },
        singleLine = true,
        isError = !ctxValid,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.fillMaxWidth()
    )
    Hint(
        "Used when the model is loaded while the server is on (the larger of this and the Chat context). Claude Code needs 32768 or more. " +
            (ContextInput.parse(contextText)?.let { contextRamHint(it) + " " } ?: "") +
            "Changing it needs a model reload."
    )
    if (readyInfo != null) Hint("The loaded model has a context of ${readyInfo.nCtx} tokens.")
    if (ctxReloadNeeded) {
        Spacer(Modifier.height(6.dp))
        Button(onClick = { viewModel.reloadModel() }) { Text("Reload model now") }
    }

    Spacer(Modifier.height(8.dp))
    SwitchRow(
        "Thinking",
        "Default for API requests; a client can switch it per request unless 'Force server settings' is on. Reasoning is returned as separate thinking blocks, never mixed into the answer. " +
            "A model whose template cannot turn reasoning off may still think when tools are used.",
        settings.serverThinking
    ) { viewModel.updateServerThinking(it) }

    ChoiceSetting(
        "Max output tokens",
        MAX_TOKEN_CHOICES.map { it to if (it == 0) "No cap (until the context is full)" else it.toString() },
        selected = settings.serverMaxTokens
    ) { viewModel.updateServerMaxTokens(it) }
    Hint("A cap on every request's max_tokens (with 'Force server settings' it replaces the client's value). Clients like Claude Code ask for 32000 or more.")

    ChoiceSetting(
        "Wait in queue before answering 529",
        QUEUE_CHOICES.map { it to "$it s" },
        selected = settings.serverQueueTimeoutSec
    ) { viewModel.updateServerQueueTimeoutSec(it) }
    Hint("One request runs at a time. The in-app chat has priority: if you send a message while an API request is running, that request is cancelled (HTTP 529 / overloaded).")
}
