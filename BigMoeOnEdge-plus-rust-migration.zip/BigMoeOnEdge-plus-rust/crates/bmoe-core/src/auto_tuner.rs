//! Port of the original AutoTuner policy. Estimates are intentionally estimates, not promises.
use crate::types::{AutoTier, DeviceProfile, EngineSettings, ModelFacts, ModelKind, SpecSource, TunedValues};

const CACHE_CHOICES: &[u32] = &[500, 1000, 1250, 1500, 1750, 2000, 3000, 4000, 5000, 6000];
const CTX_CHOICES: &[u32] = &[1024, 2048, 4096, 8192, 16384];
const TOPK_CHOICES: &[u32] = &[2, 3, 4, 6];
const SYSTEM_OVERHEAD_MB: i64 = 1200;
const DENSE_PART_OF_MOE: f64 = 0.08;
const RAM_EFFICIENCY: f64 = 0.55;
const FLASH_GBS: f64 = 1.5;

pub struct AutoTuner;

impl AutoTuner {
    pub fn usable_mb(d: &DeviceProfile) -> u64 {
        let cap = (d.total_ram_mb as f64 * RAM_EFFICIENCY) as i64 - SYSTEM_OVERHEAD_MB;
        let free = d.avail_ram_mb as i64 + (d.total_ram_mb as f64 * 0.10) as i64;
        cap.min(free).max(768) as u64
    }
    pub fn compute_reserve_mb(m: &ModelFacts) -> u64 { ((700.0 + (m.size_mb() as f64 * 0.04)) as u64).clamp(700, 1800) }
    pub fn footprint_mb(m: &ModelFacts, v: &TunedValues) -> u64 {
        let kv = (v.context_length as f64 * Self::kv_mb_per_token(m)) as u64;
        let weights = if m.is_moe() {
            (m.size_mb() as f64 * DENSE_PART_OF_MOE) as u64 + (v.cache_mb as u64).min(m.size_mb())
        } else { m.size_mb() };
        weights.saturating_add(kv).saturating_add(Self::compute_reserve_mb(m))
    }
    pub fn sanitize(v: &TunedValues) -> TunedValues {
        let mut out = v.clone(); out.substitute_pct = 0; out.io_two_wave = false; out.predict_spec_max = out.predict_spec_max.min(2); out
    }
    pub fn fits_in_ram(d: &DeviceProfile, m: &ModelFacts, v: &TunedValues) -> bool { Self::footprint_mb(m, v) <= Self::usable_mb(d) }
    pub fn safer(v: &TunedValues) -> Option<TunedValues> {
        let mut out = v.clone();
        if let Some(x) = CACHE_CHOICES.iter().copied().filter(|x| *x < v.cache_mb).max() { out.cache_mb=x; return Some(out); }
        if let Some(x) = CTX_CHOICES.iter().copied().filter(|x| *x < v.context_length).max() { out.context_length=x; return Some(out); }
        if v.batch_width > 128 { out.batch_width=(v.batch_width/2).max(128); return Some(out); }
        if v.batch_thread_count > 1 { out.batch_thread_count=(v.batch_thread_count-1).max(1); return Some(out); }
        if v.thread_count > 1 { out.thread_count=(v.thread_count-1).max(1); return Some(out); }
        if v.npu_prefill { out.npu_prefill=false; return Some(out); }
        if v.predict_prefetch { out.predict_prefetch=false; return Some(out); }
        if v.predict_spec_max > 0 { out.predict_spec_max=0; return Some(out); }
        if v.prefetch_layers > 0 { out.prefetch_layers=0; return Some(out); }
        if v.route_ahead > 0 { out.route_ahead=0; return Some(out); }
        if v.spec != SpecSource::Off { out.spec=SpecSource::Off; return Some(out); }
        if v.n_expert_used > 0 { out.n_expert_used=0; return Some(out); }
        if v.drop_cold_pct > 0 { out.drop_cold_pct=0; return Some(out); }
        if v.io_two_wave { out.io_two_wave=false; return Some(out); }
        if v.overlap { out.overlap=false; return Some(out); }
        None
    }
    fn kv_mb_per_token(m: &ModelFacts) -> f64 { (if m.is_moe() { 0.04 } else { 0.12 }) * m.size_gb().max(0.5) }
    fn context_for(tier: AutoTier, d: &DeviceProfile, m: &ModelFacts, reserve_mb: u64) -> u32 {
        let wanted = match tier { AutoTier::Fastest => 2048, AutoTier::Balanced => 4096, AutoTier::Accurate => 16384 };
        let room = Self::usable_mb(d) as i64 - reserve_mb as i64 - Self::compute_reserve_mb(m) as i64;
        CTX_CHOICES.iter().copied().filter(|ctx| *ctx <= wanted && (*ctx as f64 * Self::kv_mb_per_token(m)) <= room as f64).max().unwrap_or(CTX_CHOICES[0])
    }
    fn pick_cache(budget_mb: i64, expert_mb: u64) -> u32 {
        let capped = budget_mb.min(expert_mb.max(CACHE_CHOICES[0] as u64) as i64);
        CACHE_CHOICES.iter().copied().filter(|x| *x as i64 <= capped).max().unwrap_or(CACHE_CHOICES[0])
    }
    fn reduced_top_k(used: u32) -> u32 {
        let cut = match used { 7.. => 6, 5..=6 => 4, 4 => 3, 3 => 2, _ => 0 };
        if TOPK_CHOICES.contains(&cut) { cut } else { 0 }
    }
    pub fn plan(device: &DeviceProfile, model: &ModelFacts, tier: AutoTier, allow_npu: bool) -> TunedValues {
        let fast = device.fast_cores.clamp(1, 8);
        let npu = allow_npu && device.npu_runtime && model.is_moe() && tier != AutoTier::Accurate;
        if model.is_moe() { Self::plan_moe(device, model, tier, fast, npu) } else { Self::plan_dense(device, model, tier, fast) }
    }
    fn plan_moe(d: &DeviceProfile, m: &ModelFacts, tier: AutoTier, fast: u32, npu: bool) -> TunedValues {
        let dense_mb = (m.size_mb() as f64 * DENSE_PART_OF_MOE) as u64;
        let expert_mb = m.size_mb().saturating_sub(dense_mb);
        let ctx = Self::context_for(tier, d, m, dense_mb);
        let kv_mb = (ctx as f64 * Self::kv_mb_per_token(m)) as u64;
        let cache_budget = Self::usable_mb(d) as i64 - dense_mb as i64 - Self::compute_reserve_mb(m) as i64 - kv_mb as i64;
        let mut base = TunedValues {
            context_length: ctx, thread_count: fast, batch_thread_count: fast,
            batch_width: if m.size_gb() > 12.0 { 256 } else { 512 },
            cache_mb: Self::pick_cache(cache_budget, expert_mb), io_threads: 4,
            o_direct: true, overlap: true, io_two_wave: false, n_expert_used: 0,
            drop_cold_pct: 0, drop_renorm: true, substitute_pct: 0, prefetch_layers: 0,
            predict_prefetch: false, predict_spec_max: 0, route_ahead: 0,
            spec: SpecSource::Off, draft_max: 3, npu_prefill: npu,
        };
        match tier {
            AutoTier::Fastest => { base.n_expert_used=Self::reduced_top_k(m.expert_used); base.drop_cold_pct=75; base.predict_prefetch=true; base.predict_spec_max=2; }
            AutoTier::Balanced => { base.drop_cold_pct=50; base.predict_prefetch=true; base.predict_spec_max=2; }
            AutoTier::Accurate => { base.prefetch_layers=1; }
        }
        base
    }
    fn plan_dense(_d: &DeviceProfile, m: &ModelFacts, tier: AutoTier, fast: u32) -> TunedValues {
        let ctx=Self::context_for(tier, _d, m, m.size_mb());
        TunedValues {
            context_length: ctx, thread_count: fast, batch_thread_count: fast, batch_width: 512,
            cache_mb: 2000, io_threads: 4, o_direct: true, overlap: true, io_two_wave: false,
            n_expert_used: 0, drop_cold_pct: 0, drop_renorm: true, substitute_pct: 0,
            prefetch_layers: 0, predict_prefetch: false, predict_spec_max: 0, route_ahead: 0,
            spec: if tier == AutoTier::Fastest { SpecSource::Ngram } else { SpecSource::Off }, draft_max: 4, npu_prefill: false,
        }
    }
    pub fn estimate_tps(d: &DeviceProfile, m: &ModelFacts, tier: AutoTier, v: &TunedValues) -> f64 {
        let bw = d.mem_bandwidth_gbs.max(1.0) * RAM_EFFICIENCY;
        let size_gb = m.size_gb().max(0.05);
        let raw = if m.is_moe() {
            let dense_gb=size_gb*DENSE_PART_OF_MOE; let expert_gb=size_gb-dense_gb;
            let n=m.expert_count.max(1) as f64;
            let k=if m.expert_used>0 {m.expert_used as f64} else {(8u32.min(2u32.max(m.expert_count/8))) as f64};
            let active=(k/n).min(1.0); let cache_gb=((v.cache_mb as f64)/1024.0).min(expert_gb);
            let hit=(cache_gb/expert_gb.max(0.01)).sqrt().min(0.97);
            let seconds=dense_gb/bw + expert_gb*active*(hit/bw+(1.0-hit)/FLASH_GBS);
            1.0/seconds
        } else {
            let usable_gb=Self::usable_mb(d) as f64/1024.0;
            let speed=bw/size_gb;
            if size_gb>usable_gb*0.9 {speed*0.15} else {speed}
        };
        let factor=match (m.is_moe(),tier) {
            (true,AutoTier::Fastest)=>1.7,(true,AutoTier::Balanced)=>1.25,(true,AutoTier::Accurate)=>1.0,
            (false,AutoTier::Fastest)=>1.15,(false,AutoTier::Balanced)=>1.0,(false,AutoTier::Accurate)=>0.92,
        };
        ((raw*factor).clamp(0.1,200.0)*10.0).round()/10.0
    }
    pub fn estimate_measure_seconds(m: &ModelFacts, saves: u32, tps: f64) -> u32 {
        let load=m.size_gb()*2.5+5.0; let gen=64.0/tps.max(0.2)+5.0; ((load+gen)*saves as f64).round() as u32
    }
    pub fn apply_to(settings: &mut EngineSettings, values: TunedValues) { settings.tuned=values; }
    pub fn describe(v: &TunedValues, m: &ModelFacts) -> Vec<String> {
        let mut out=vec![format!("Context {} tokens, {} CPU threads",v.context_length,v.thread_count)];
        if m.is_moe() {
            out.push(format!("Expert cache {} MB of RAM",v.cache_mb));
            if v.n_expert_used>0 {out.push(format!("Uses {} experts per token instead of the model's own {}",v.n_expert_used,if m.expert_used>0 {m.expert_used.to_string()} else {"default".into()}));}
            else {out.push("Uses the model's own number of experts per token".into());}
            if v.drop_cold_pct>0 {out.push(format!("Skips the {}% least-used experts",v.drop_cold_pct));}
            if v.substitute_pct>0 {out.push(format!("Prefers already-cached experts ({}%)",v.substitute_pct));}
            if v.predict_prefetch || v.prefetch_layers>0 {out.push("Reads the next experts ahead of time".into());}
            if v.npu_prefill {out.push("Prompt prefill on the NPU".into());}
        } else if v.spec==SpecSource::Ngram {out.push("Guesses repeated text ahead (uses greedy decoding)".into());}
        out
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn device() -> DeviceProfile { DeviceProfile { total_ram_mb: 12288, avail_ram_mb: 4500, cores: 8, fast_cores: 4, soc: "Snapdragon 8 Gen 2".into(), mem_bandwidth_gbs: 35.0, npu_runtime: true } }
    fn model(kind: ModelKind, gb: f64) -> ModelFacts { ModelFacts { path:"model.gguf".into(), name:"test".into(), size_bytes:(gb*1024.0*1024.0*1024.0) as u64, kind, expert_count:32, expert_used:8 } }
    #[test] fn fastest_moe_never_uses_unstable_two_wave_or_substitution() { let v=AutoTuner::plan(&device(),&model(ModelKind::Moe,20.0),AutoTier::Fastest,false); assert!(!v.io_two_wave); assert_eq!(v.substitute_pct,0); assert!(v.predict_prefetch); }
    #[test] fn npu_is_opt_in_and_not_used_for_accurate_tier() { let d=device(); let m=model(ModelKind::Moe,8.0); assert!(!AutoTuner::plan(&d,&m,AutoTier::Fastest,false).npu_prefill); assert!(AutoTuner::plan(&d,&m,AutoTier::Fastest,true).npu_prefill); assert!(!AutoTuner::plan(&d,&m,AutoTier::Accurate,true).npu_prefill); }
    #[test] fn dense_fastest_uses_ngram_only() { let v=AutoTuner::plan(&device(),&model(ModelKind::Dense,3.0),AutoTier::Fastest,false); assert_eq!(v.spec,SpecSource::Ngram); assert_eq!(v.cache_mb,2000); }
    #[test] fn sanitizer_removes_known_crashing_knobs() { let mut v=AutoTuner::plan(&device(),&model(ModelKind::Moe,10.0),AutoTier::Fastest,false); v.io_two_wave=true; v.substitute_pct=30; v.predict_spec_max=8; let safe=AutoTuner::sanitize(&v); assert!(!safe.io_two_wave); assert_eq!(safe.substitute_pct,0); assert_eq!(safe.predict_spec_max,2); }
}
