//! Incremental output parser: tool calls never leak into visible text; supported fences become artifacts.
use serde_json::Value;
use uuid::Uuid;

pub const CALL_OPEN: &str = "<tool_call>";
pub const CALL_CLOSE: &str = "</tool_call>";
pub const RESPONSE_OPEN: &str = "<tool_response>";
pub const RESPONSE_CLOSE: &str = "</tool_response>";

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ArtifactType { Html, Svg, Mermaid, Code }
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ArtifactModel { pub id: String, pub title: String, pub kind: ArtifactType, pub content: String, pub language: String, pub file_name: Option<String> }
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ParsedChunk {
    Text(String),
    ToolInvocation { tool_name: String, raw_arguments: String },
    MalformedToolCall { raw: String, reason: String },
    ArtifactDetected(ArtifactModel),
    Reasoning(String),
}

pub struct StreamOutputParser {
    pending: String, tool_buffer: String, in_tool: bool, visible: String, scanned_up_to: usize,
}
impl Default for StreamOutputParser { fn default() -> Self { Self::new() } }
impl StreamOutputParser {
    pub fn new() -> Self { Self { pending:String::new(), tool_buffer:String::new(), in_tool:false, visible:String::new(), scanned_up_to:0 } }
    pub fn process_token(&mut self, token: &str) -> Vec<ParsedChunk> {
        let mut out=Vec::new(); if token.is_empty() {return out;}
        if self.in_tool {self.tool_buffer.push_str(token)} else {self.pending.push_str(token)}
        self.drain(&mut out); out
    }
    fn drain(&mut self, out: &mut Vec<ParsedChunk>) {
        loop {
            if self.in_tool {
                let Some(end)=self.tool_buffer.find(CALL_CLOSE) else {return;};
                let payload=self.tool_buffer[..end].to_owned(); let rest=self.tool_buffer[end+CALL_CLOSE.len()..].to_owned();
                self.emit_tool(&payload,out); self.tool_buffer.clear(); self.in_tool=false; self.pending.push_str(&rest); continue;
            }
            if let Some(open)=self.pending.find(CALL_OPEN) {
                let before=self.pending[..open].to_owned(); self.emit_text(&before,out);
                let payload=self.pending[open+CALL_OPEN.len()..].to_owned(); self.pending.clear(); self.tool_buffer=payload; self.in_tool=true; continue;
            }
            let hold=partial_tag_suffix(&self.pending,CALL_OPEN);
            let emit_len=self.pending.len().saturating_sub(hold);
            let visible=self.pending[..emit_len].to_owned(); self.emit_text(&visible,out);
            let remainder=self.pending[emit_len..].to_owned(); self.pending=remainder; return;
        }
    }
    fn emit_tool(&self, payload: &str, out: &mut Vec<ParsedChunk>) {
        match parse_tool_call(payload) {
            Ok((name,args))=>out.push(ParsedChunk::ToolInvocation{tool_name:name,raw_arguments:args}),
            Err(reason)=>out.push(ParsedChunk::MalformedToolCall{raw:payload.trim().into(),reason}),
        }
    }
    fn emit_text(&mut self,text:&str,out:&mut Vec<ParsedChunk>) {
        if text.is_empty(){return;} out.push(ParsedChunk::Text(text.into())); self.visible.push_str(text); self.scan_artifacts(out,false);
    }
    fn scan_artifacts(&mut self,out:&mut Vec<ParsedChunk>,final_scan:bool) {
        if self.scanned_up_to>=self.visible.len(){return;}
        let tail=self.visible[self.scanned_up_to..].to_owned();
        if !tail.contains("```") && !tail.contains("~~~") {
            if let Some(n)=tail.rfind('\n'){self.scanned_up_to+=n+1;} return;
        }
        let mut offset=0usize; let mut active:Option<(String,String,usize)>=None; let mut last_end:Option<usize>=None;
        for (line_start,line_with_nl) in tail.split_inclusive('\n').enumerate().map(|(i,l)|(i,l)) {
            let _=line_start;
            let line=line_with_nl.trim_end_matches(['\r','\n']); let trimmed=line.trim_start();
            let marker=if trimmed.starts_with("```") {Some("```")} else if trimmed.starts_with("~~~"){Some("~~~")} else {None};
            if let Some(mark)=marker {
                if let Some((open_mark,info,code_start))=active.take() {
                    if mark==open_mark {
                        let close_start=offset; let code=tail[code_start..close_start].trim_end_matches(['\r','\n']).to_owned();
                        if let Some(artifact)=make_artifact(&info,&code){out.push(ParsedChunk::ArtifactDetected(artifact));}
                        last_end=Some(offset+line_with_nl.len());
                    } else { active=Some((open_mark,info,code_start)); }
                } else {
                    let info=trimmed[mark.len()..].trim().to_owned();
                    active=Some((mark.to_owned(),info,offset+line_with_nl.len()));
                }
            }
            offset+=line_with_nl.len();
        }
        if let Some(end)=last_end {self.scanned_up_to+=end;}
        else if active.is_none() || final_scan { if let Some(n)=tail.rfind('\n'){self.scanned_up_to+=n+1;} }
    }
    pub fn flush(&mut self) -> Vec<ParsedChunk> {
        let mut out=Vec::new();
        if self.in_tool {let payload=self.tool_buffer.clone(); if !payload.trim().is_empty(){self.emit_tool(&payload,&mut out);} self.tool_buffer.clear(); self.in_tool=false;}
        if !self.pending.is_empty(){let pending=self.pending.clone();self.pending.clear();self.emit_text(&pending,&mut out);}
        self.scan_artifacts(&mut out,true); out
    }
    pub fn reset(&mut self){self.pending.clear();self.tool_buffer.clear();self.in_tool=false;self.visible.clear();self.scanned_up_to=0;}
    pub fn visible_text(&self)->&str {&self.visible}
}

fn partial_tag_suffix(s:&str,tag:&str)->usize {
    let max=s.len().min(tag.len().saturating_sub(1));
    (1..=max).rev().find(|len|s.is_char_boundary(s.len()-*len) && &s[s.len()-*len..]==&tag[..*len]).unwrap_or(0)
}
fn extract_json_object(s:&str)->Option<String>{
    let start=s.find('{')?; let mut depth=0usize; let mut in_string=false; let mut escaped=false;
    for (off,ch) in s[start..].char_indices(){
        if in_string {if escaped {escaped=false;} else if ch=='\\' {escaped=true;} else if ch=='"' {in_string=false;}}
        else {match ch {'"'=>in_string=true,'{'=>depth+=1,'}'=>{depth=depth.saturating_sub(1);if depth==0{return Some(s[start..start+off+ch.len_utf8()].into());}},_=>{}}}
    }
    if depth>0 {Some(format!("{}{}",&s[start..],"}".repeat(depth)))} else {None}
}
fn parse_tool_call(payload:&str)->Result<(String,String),String>{
    let candidate=extract_json_object(payload).ok_or("no JSON object found")?;
    let parsed:Value=serde_json::from_str(&candidate).or_else(|_|{
        let no_trailing=remove_trailing_commas(&candidate); serde_json::from_str(&no_trailing)
    }).map_err(|_|"invalid JSON")?;
    let name=parsed.get("name").or_else(||parsed.get("tool")).and_then(Value::as_str).unwrap_or("").trim();
    if name.is_empty(){return Err("missing \"name\"");}
    let raw=parsed.get("arguments").or_else(||parsed.get("parameters")).or_else(||parsed.get("args"));
    let args=match raw {None|Some(Value::Null)=>serde_json::json!({}),Some(Value::Object(_))=>raw.unwrap().clone(),Some(Value::String(s))=>{
        if s.trim().is_empty(){serde_json::json!({})}else{
            let candidate=extract_json_object(s).unwrap_or_else(||s.to_owned());
            let value:Value=serde_json::from_str(&candidate).map_err(|_|"\"arguments\" is not a JSON object")?;
            if !value.is_object(){return Err("\"arguments\" is not a JSON object");} value
        }
    },_=>return Err("\"arguments\" is not a JSON object")};
    Ok((name.into(),serde_json::to_string(&args).unwrap_or_else(|_|"{}".into())))
}
fn remove_trailing_commas(s:&str)->String { let mut out=String::with_capacity(s.len());let mut chars=s.chars().peekable();let mut quoted=false;let mut escaped=false;while let Some(c)=chars.next(){if quoted{out.push(c);if escaped{escaped=false}else if c=='\\'{escaped=true}else if c=='"'{quoted=false;}}else if c=='"'{quoted=true;out.push(c);}else if c==','{let mut look=chars.clone();while look.peek().is_some_and(|x|x.is_whitespace()){look.next();}if !matches!(look.peek(),Some('}')|Some(']')){out.push(c);}}else{out.push(c);}}out }
fn canonical_language(tag:&str)->Option<&'static str>{
    let t=tag.trim().trim_start_matches('.').to_ascii_lowercase();
    Some(match t.as_str(){"html"|"htm"|"xhtml"=>"html","css"|"scss"|"sass"|"less"=>"css","js"|"jsx"|"mjs"|"cjs"|"javascript"|"node"|"nodejs"=>"javascript","ts"|"tsx"|"typescript"=>"typescript","json"|"jsonc"|"json5"|"jsonl"|"ndjson"=>"json","xml"|"xsd"|"xsl"|"xslt"=>"xml","md"|"markdown"|"mdx"=>"markdown","py"|"python"|"python3"=>"python","kt"|"kts"|"kotlin"=>"kotlin","java"=>"java","c"=>"c","cpp"|"c++"|"cc"|"cxx"|"hpp"|"h"=>"cpp","cs"|"csharp"|"c#"=>"csharp","rs"|"rust"=>"rust","go"|"golang"=>"go","swift"=>"swift","sh"|"bash"|"shell"|"zsh"=>"bash","sql"|"mysql"|"postgres"|"sqlite"=>"sql","yml"|"yaml"=>"yaml","svg"=>"svg","mermaid"|"mmd"=>"mermaid","toml"=>"toml","txt"|"text"|"plain"|"plaintext"=>"text","dockerfile"|"docker"=>"dockerfile","makefile"|"make"=>"makefile","cmake"=>"cmake",_=>return None})
}
fn language_title(language:&str)->&'static str {match language{"html"=>"HTML","css"=>"CSS","javascript"=>"JavaScript","typescript"=>"TypeScript","json"=>"JSON","xml"=>"XML","markdown"=>"Markdown","python"=>"Python","kotlin"=>"Kotlin","java"=>"Java","c"=>"C","cpp"=>"C++","csharp"=>"C#","rust"=>"Rust","go"=>"Go","swift"=>"Swift","bash"=>"Shell","sql"=>"SQL","yaml"=>"YAML","svg"=>"SVG","mermaid"=>"Mermaid","toml"=>"TOML","dockerfile"=>"Dockerfile","makefile"=>"Makefile","cmake"=>"CMake",_=>"Text"}}
fn make_artifact(info:&str,code:&str)->Option<ArtifactModel>{
    if code.trim().is_empty(){return None;}
    let mut parts=info.split_whitespace();let tag=parts.next().unwrap_or("");let file=parts.find(|x|x.contains('.')||x.starts_with("filename=")).map(|s|s.trim_start_matches("filename="));
    let filename_lang=file.and_then(|f|f.rsplit('.').next()).and_then(canonical_language);
    let lang=canonical_language(tag).filter(|l|*l!="text").or(filename_lang).or_else(||canonical_language(tag))?;
    if lang=="python" {return None;}
    let kind=match lang{"html"=>ArtifactType::Html,"svg"=>ArtifactType::Svg,"mermaid"=>ArtifactType::Mermaid,_=>ArtifactType::Code};
    let title=file.map(|f|f.rsplit('/').next().unwrap_or(f).to_owned()).unwrap_or_else(||format!("{} artifact",language_title(lang)));
    Some(ArtifactModel{id:Uuid::new_v4().to_string(),title,kind,content:code.into(),language:lang.into(),file_name:file.map(str::to_owned)})
}

#[cfg(test)] mod tests {
    use super::*;
    #[test] fn a_split_tool_tag_never_leaks(){let mut p=StreamOutputParser::new();assert!(p.process_token("hello <tool").iter().all(|x|!matches!(x,ParsedChunk::Text(s) if s.contains("<tool"))));let out=p.process_token("_call>{\"name\":\"x\",\"arguments\":{\"n\":1}}</tool_call>ok");assert!(out.iter().any(|c|matches!(c,ParsedChunk::ToolInvocation{tool_name,..} if tool_name=="x")));assert!(out.iter().any(|c|matches!(c,ParsedChunk::Text(s) if s=="ok")));}
    #[test] fn malformed_calls_are_reported_not_rendered(){let mut p=StreamOutputParser::new();let out=p.process_token("<tool_call>{bad}</tool_call>");assert!(out.iter().any(|c|matches!(c,ParsedChunk::MalformedToolCall{..})));assert!(out.iter().all(|c|!matches!(c,ParsedChunk::Text(_))));}
    #[test] fn html_fence_becomes_artifact_after_closure(){let mut p=StreamOutputParser::new();let out=p.process_token("Here\n```html\n<h1>Hello</h1>\n```\n");assert!(out.iter().any(|c|matches!(c,ParsedChunk::ArtifactDetected(a) if a.kind==ArtifactType::Html)));}
}
