//! Conversation cache identity and conservative history trimming, ported from ContextPlanner.kt.
use crate::types::ChatTurn;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PreparedHistory { pub history: Vec<ChatTurn>, pub prompt: String, pub trimmed: bool }

pub struct ContextPlanner;
impl ContextPlanner {
    /// Matches Kotlin/JVM String.hashCode() so existing context-key semantics remain predictable.
    pub fn state_key(session_id: &str, last_message_id: Option<&str>, system: &str) -> String {
        format!("{}|{}|{}", session_id, last_message_id.unwrap_or(""), java_string_hash(system))
    }
    pub fn estimate_tokens(text: &str) -> usize {
        if text.is_empty() { 0 } else { text.len() / 3 + 4 }
    }
    /// Enforce an alternating user/assistant sequence, merge adjacent roles, drop leading assistant turns.
    pub fn normalize(turns: &[ChatTurn]) -> Vec<ChatTurn> {
        let mut out: Vec<ChatTurn> = Vec::new();
        for turn in turns {
            let role = if turn.role == ChatTurn::ASSISTANT { ChatTurn::ASSISTANT } else { ChatTurn::USER };
            let content = turn.content.trim();
            if content.is_empty() { continue; }
            if out.last().is_some_and(|last| last.role == role) {
                let previous = out.pop().expect("last exists");
                out.push(ChatTurn { role: role.into(), content: format!("{}\n\n{}", previous.content, content) });
            } else { out.push(ChatTurn { role: role.into(), content: content.into() }); }
        }
        while out.first().is_some_and(|t| t.role != ChatTurn::USER) { out.remove(0); }
        out
    }
    pub fn prepare(history: &[ChatTurn], prompt: &str, history_budget_tokens: usize) -> PreparedHistory {
        let mut turns = Self::normalize(history);
        let mut effective_prompt = prompt.to_owned();
        if turns.last().is_some_and(|t| t.role == ChatTurn::USER) {
            let last = turns.pop().expect("last exists");
            effective_prompt = format!("{}\n\n{}", last.content, prompt);
        }
        let mut total: usize = turns.iter().map(|t| Self::estimate_tokens(&t.content) + 8).sum();
        let mut trimmed = false;
        let mut start = 0;
        while total > history_budget_tokens && start < turns.len() {
            total = total.saturating_sub(Self::estimate_tokens(&turns[start].content) + 8);
            start += 1;
            trimmed = true;
        }
        while start < turns.len() && turns[start].role != ChatTurn::USER { start += 1; trimmed = true; }
        PreparedHistory { history: turns.into_iter().skip(start).collect(), prompt: effective_prompt, trimmed }
    }
    pub fn history_budget(n_ctx: usize, system_tokens: usize, prompt_tokens: usize, max_tokens: usize) -> usize {
        let reserve = if max_tokens > 0 { max_tokens.min(n_ctx / 2) } else { n_ctx / 4 };
        let by_reserve = n_ctx.saturating_sub(reserve).saturating_sub(system_tokens).saturating_sub(prompt_tokens).saturating_sub(32);
        let by_cap = (n_ctx * 7 / 10).saturating_sub(system_tokens).saturating_sub(prompt_tokens);
        by_reserve.min(by_cap)
    }
    pub fn effective_max_tokens(max_tokens: usize, n_ctx: usize) -> usize {
        if max_tokens == 0 { 0 } else { max_tokens.min((n_ctx / 2).max(1)) }
    }
    pub fn is_context_overflow(error: &str) -> bool { error.contains("n_ctx") }
}

fn java_string_hash(text: &str) -> i32 {
    text.encode_utf16().fold(0_i32, |h, c| h.wrapping_mul(31).wrapping_add(c as i32))
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn jvm_hash_matches_ascii_and_unicode() { assert_eq!(java_string_hash("abc"), 96354); assert_eq!(java_string_hash("😀"), 1772899); }
    #[test] fn normalize_merges_roles_and_drops_leading_assistant() {
        let input=vec![ChatTurn::assistant("orphan"),ChatTurn::user(" hi "),ChatTurn::user("there"),ChatTurn::assistant("ok")];
        let got=ContextPlanner::normalize(&input); assert_eq!(got.len(),2); assert_eq!(got[0].content,"hi\n\nthere");
    }
    #[test] fn trailing_user_is_folded_into_prompt() {
        let got=ContextPlanner::prepare(&[ChatTurn::user("last user")],"new prompt",100);
        assert!(got.history.is_empty()); assert_eq!(got.prompt,"last user\n\nnew prompt");
    }
    #[test] fn trimming_preserves_user_first() {
        let got=ContextPlanner::prepare(&[ChatTurn::user("one"),ChatTurn::assistant("two"),ChatTurn::user("three"),ChatTurn::assistant("four")],"now",1);
        assert!(got.trimmed); assert!(got.history.is_empty() || got.history[0].role==ChatTurn::USER);
    }
}
