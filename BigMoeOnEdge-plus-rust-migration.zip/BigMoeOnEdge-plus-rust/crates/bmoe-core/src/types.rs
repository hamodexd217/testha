use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "snake_case")]
pub enum ModelKind { #[default] Dense, Moe }

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "snake_case")]
pub enum SpecSource { #[default] Off, Mtp, Ngram }

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "snake_case")]
pub enum AutoTier { Fastest, #[default] Balanced, Accurate }

impl AutoTier {
    pub fn id(self) -> &'static str { match self { Self::Fastest => "fastest", Self::Balanced => "balanced", Self::Accurate => "accurate" } }
    pub fn title(self) -> &'static str { match self { Self::Fastest => "Fastest", Self::Balanced => "Balanced", Self::Accurate => "Most accurate (slowest)" } }
    pub fn tagline(self) -> &'static str { match self { Self::Fastest => "Highest speed. Answers may differ slightly from the original model.", Self::Balanced => "Good speed with answers very close to the original model.", Self::Accurate => "Slowest. Uses the model exactly as trained, with the largest safe context." } }
    pub fn from_id(id: &str) -> Self { match id { "fastest" => Self::Fastest, "accurate" => Self::Accurate, _ => Self::Balanced } }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DeviceProfile {
    pub total_ram_mb: u64,
    pub avail_ram_mb: u64,
    pub cores: u32,
    pub fast_cores: u32,
    pub soc: String,
    pub mem_bandwidth_gbs: f64,
    pub npu_runtime: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModelFacts {
    pub path: String,
    pub name: String,
    pub size_bytes: u64,
    pub kind: ModelKind,
    pub expert_count: u32,
    pub expert_used: u32,
}

impl ModelFacts {
    pub fn size_mb(&self) -> u64 { self.size_bytes / (1024 * 1024) }
    pub fn size_gb(&self) -> f64 { self.size_bytes as f64 / (1024.0 * 1024.0 * 1024.0) }
    pub fn is_moe(&self) -> bool { self.kind == ModelKind::Moe }
}

/// All inference knobs controlled by Auto Settings. Settings outside this struct remain user-owned.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TunedValues {
    pub context_length: u32,
    pub thread_count: u32,
    pub batch_thread_count: u32,
    pub batch_width: u32,
    pub cache_mb: u32,
    pub io_threads: u32,
    pub o_direct: bool,
    pub overlap: bool,
    pub io_two_wave: bool,
    pub n_expert_used: u32,
    pub drop_cold_pct: u32,
    pub drop_renorm: bool,
    pub substitute_pct: u32,
    pub prefetch_layers: u32,
    pub predict_prefetch: bool,
    pub predict_spec_max: u32,
    pub route_ahead: u32,
    pub spec: SpecSource,
    pub draft_max: u32,
    pub npu_prefill: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct EngineSettings {
    pub tuned: TunedValues,
    /// Cera compute backend preference: auto, cpu, gpu, metal, hexagon, or npu.
    pub backend: String,
    pub temperature: f32,
    pub top_p: f32,
    pub top_k: u32,
    pub seed: i64,
    pub max_tokens: i32,
    pub system_prompt: String,
    pub enable_tools: bool,
    pub theme: String,
}

impl Default for EngineSettings {
    fn default() -> Self {
        Self {
            backend: "auto".into(),
            tuned: TunedValues {
                context_length: 4096, thread_count: 4, batch_thread_count: 4,
                batch_width: 512, cache_mb: 2000, io_threads: 4, o_direct: true,
                overlap: true, io_two_wave: false, n_expert_used: 0,
                drop_cold_pct: 0, drop_renorm: true, substitute_pct: 0,
                prefetch_layers: 0, predict_prefetch: false, predict_spec_max: 0,
                route_ahead: 0, spec: SpecSource::Off, draft_max: 4, npu_prefill: false,
            },
            temperature: 0.7, top_p: 0.9, top_k: 40, seed: -1, max_tokens: 0,
            system_prompt: String::new(), enable_tools: true, theme: "system".into(),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ChatTurn { pub role: String, pub content: String }
impl ChatTurn {
    pub const USER: &'static str = "user";
    pub const ASSISTANT: &'static str = "assistant";
    pub fn user(content: impl Into<String>) -> Self { Self { role: Self::USER.into(), content: content.into() } }
    pub fn assistant(content: impl Into<String>) -> Self { Self { role: Self::ASSISTANT.into(), content: content.into() } }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GenerationStats {
    pub generated_tokens: u64,
    pub prompt_tokens: u64,
    pub past_tokens: u64,
    pub tokens_per_second: f64,
    pub prefill_seconds: f64,
    pub cache_hit_pct: Option<f64>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MessageRecord {
    pub id: String,
    pub session_id: String,
    pub role: String,
    pub content: String,
    pub reasoning: String,
    pub created_at_ms: i64,
    pub stats: Option<GenerationStats>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChatSessionRecord {
    pub id: String,
    pub title: String,
    pub created_at_ms: i64,
    pub updated_at_ms: i64,
    pub system_prompt: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModelRecord {
    pub id: String,
    pub path: String,
    pub display_name: String,
    pub size_bytes: u64,
    pub kind: ModelKind,
    pub is_ready: bool,
    pub metadata_json: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ArtifactRecord {
    pub id: String,
    pub session_id: Option<String>,
    pub title: String,
    pub kind: String,
    pub language: String,
    pub file_name: Option<String>,
    pub content: String,
    pub created_at_ms: i64,
}
