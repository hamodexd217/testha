//! Platform-independent domain and policy code for BigMoeOnEdge+.
//! The module is deliberately free of Android/JNI/UI dependencies.

pub mod auto_tuner;
pub mod context;
pub mod gguf;
pub mod output_parser;
pub mod types;

pub use auto_tuner::AutoTuner;
pub use context::ContextPlanner;
pub use output_parser::{ArtifactModel, ArtifactType, ParsedChunk, StreamOutputParser};
pub use types::*;
