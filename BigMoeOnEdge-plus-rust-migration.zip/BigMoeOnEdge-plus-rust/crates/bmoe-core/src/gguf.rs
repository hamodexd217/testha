//! Small, bounded GGUF header reader. It reads metadata only, never tensor payloads.
use serde::{Deserialize, Serialize};
use std::{collections::BTreeMap, fs::File, io::{self, Read, BufReader}, path::{Path, PathBuf}};
use thiserror::Error;

const MAX_STRING_BYTES: u64 = 16 * 1024 * 1024;
const MAX_METADATA_ITEMS: u64 = 2_000_000;

#[derive(Debug, Error)]
pub enum GgufError {
    #[error("could not read file: {0}")]
    Io(#[from] io::Error),
    #[error("not a GGUF file (bad magic)")]
    BadMagic,
    #[error("unsupported GGUF version {0}")]
    UnsupportedVersion(u32),
    #[error("invalid or unreasonable GGUF header: {0}")]
    InvalidHeader(String),
    #[error("metadata value type {0} is unsupported")]
    UnsupportedType(u32),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(untagged)]
pub enum MetadataValue { String(String), Integer(i64), Float(f64), Bool(bool), Array(Vec<MetadataValue>) }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GgufInfo {
    pub path: PathBuf,
    pub display_name: String,
    pub size_bytes: u64,
    pub version: u32,
    pub tensor_count: u64,
    pub metadata: BTreeMap<String, MetadataValue>,
    pub architecture: Option<String>,
    pub context_length: Option<u64>,
    pub expert_count: Option<u64>,
    pub expert_used: Option<u64>,
    pub split_count: Option<u64>,
    pub split_number: Option<u64>,
    pub quantization: Option<String>,
}

impl GgufInfo {
    pub fn inspect(path: impl AsRef<Path>) -> Result<Self, GgufError> {
        let path=path.as_ref(); let file=File::open(path)?; let size_bytes=file.metadata()?.len();
        let mut r=BufReader::new(file); let mut magic=[0u8;4]; r.read_exact(&mut magic)?;
        if &magic!=b"GGUF" {return Err(GgufError::BadMagic);}
        let version=read_u32(&mut r)?;
        if !(2..=3).contains(&version) {return Err(GgufError::UnsupportedVersion(version));}
        let tensor_count=read_u64(&mut r)?; let metadata_count=read_u64(&mut r)?;
        if metadata_count>MAX_METADATA_ITEMS {return Err(GgufError::InvalidHeader(format!("metadata count {metadata_count} exceeds safety bound")));}
        if tensor_count>20_000_000 {return Err(GgufError::InvalidHeader(format!("tensor count {tensor_count} exceeds safety bound")));}
        let mut metadata=BTreeMap::new();
        for _ in 0..metadata_count {
            let key=read_string(&mut r)?; let kind=read_u32(&mut r)?; let value=read_value(&mut r,kind,0)?;
            metadata.insert(key,value);
        }
        let get_string=|key:&str| metadata.get(key).and_then(|v| if let MetadataValue::String(s)=v {Some(s.clone())} else {None});
        let get_int=|key:&str| metadata.get(key).and_then(value_u64);
        let architecture=get_string("general.architecture");
        let context_length=architecture.as_ref().and_then(|a|get_int(&format!("{a}.context_length")));
        let expert_count=architecture.as_ref().and_then(|a|get_int(&format!("{a}.expert_count")));
        let expert_used=architecture.as_ref().and_then(|a|get_int(&format!("{a}.expert_used_count")));
        let display_name=path.file_name().and_then(|x|x.to_str()).unwrap_or("model.gguf").to_owned();
        let quantization=get_string("general.file_type").map(|x|format!("file_type={x}"));
        Ok(Self { path:path.to_path_buf(),display_name,size_bytes,version,tensor_count,architecture,context_length,expert_count,expert_used,
            split_count:get_int("split.count"),split_number:get_int("split.no"),quantization,metadata })
    }
    pub fn is_moe(&self)->bool { self.expert_count.unwrap_or(0)>0 || self.architecture.as_deref().is_some_and(|a|a.to_ascii_lowercase().contains("moe")) }
    pub fn size_mb(&self)->u64 {self.size_bytes/(1024*1024)}
}

fn read_u32<R:Read>(r:&mut R)->io::Result<u32>{let mut b=[0;4];r.read_exact(&mut b)?;Ok(u32::from_le_bytes(b))}
fn read_u64<R:Read>(r:&mut R)->io::Result<u64>{let mut b=[0;8];r.read_exact(&mut b)?;Ok(u64::from_le_bytes(b))}
fn read_string<R:Read>(r:&mut R)->Result<String,GgufError>{let len=read_u64(r)?;if len>MAX_STRING_BYTES{return Err(GgufError::InvalidHeader(format!("metadata string size {len} exceeds safety bound")));}let mut b=vec![0;len as usize];r.read_exact(&mut b)?;String::from_utf8(b).map_err(|e|GgufError::InvalidHeader(format!("metadata string is not UTF-8: {e}")))}
fn value_u64(v:&MetadataValue)->Option<u64>{match v {MetadataValue::Integer(n) if *n>=0=>Some(*n as u64),MetadataValue::Float(n) if *n>=0.0=>Some(*n as u64),_=>None}}
fn read_value<R:Read>(r:&mut R,kind:u32,depth:u8)->Result<MetadataValue,GgufError>{
    if depth>8{return Err(GgufError::InvalidHeader("metadata array nesting exceeded".into()));}
    Ok(match kind {
        0=>MetadataValue::Integer(read_num::<R,u8>(r)? as i64),1=>MetadataValue::Integer(read_num::<R,i8>(r)? as i64),
        2=>MetadataValue::Integer(read_num::<R,u16>(r)? as i64),3=>MetadataValue::Integer(read_num::<R,i16>(r)? as i64),
        4=>MetadataValue::Integer(read_num::<R,u32>(r)? as i64),5=>MetadataValue::Integer(read_num::<R,i32>(r)? as i64),
        6=>MetadataValue::Float(read_num::<R,f32>(r)? as f64),7=>MetadataValue::Bool(read_num::<R,u8>(r)?!=0),
        8=>MetadataValue::String(read_string(r)?),
        9=>{let elem=read_u32(r)?;let len=read_u64(r)?;if len>MAX_METADATA_ITEMS{return Err(GgufError::InvalidHeader(format!("array length {len} exceeds safety bound")));}let mut values=Vec::with_capacity(len.min(4096) as usize);for _ in 0..len {values.push(read_value(r,elem,depth+1)?);}MetadataValue::Array(values)},
        10=>MetadataValue::Integer(read_num::<R,u64>(r)? as i64),11=>MetadataValue::Integer(read_num::<R,i64>(r)?),
        12=>MetadataValue::Float(read_num::<R,f64>(r)?),_=>return Err(GgufError::UnsupportedType(kind)),
    })
}
trait ReadLe: Sized {const SIZE:usize;fn from_le(bytes:&[u8])->Self;}
macro_rules! read_le {($t:ty,$n:expr)=>{impl ReadLe for $t{const SIZE:usize=$n;fn from_le(b:&[u8])->Self{<$t>::from_le_bytes(b.try_into().expect("fixed buffer size"))}}};}
read_le!(u8,1);read_le!(i8,1);read_le!(u16,2);read_le!(i16,2);read_le!(u32,4);read_le!(i32,4);read_le!(u64,8);read_le!(i64,8);read_le!(f32,4);read_le!(f64,8);
fn read_num<R:Read,T:ReadLe>(r:&mut R)->io::Result<T>{let mut b=vec![0u8;T::SIZE];r.read_exact(&mut b)?;Ok(T::from_le(&b))}

#[cfg(test)] mod tests { use super::*; #[test] fn rejects_non_gguf_files(){let p=std::env::temp_dir().join(format!("bad-{}.gguf",std::process::id()));std::fs::write(&p,b"NOPE\0\0\0\0").unwrap();assert!(matches!(GgufInfo::inspect(&p),Err(GgufError::BadMagic)));let _=std::fs::remove_file(p);} }
