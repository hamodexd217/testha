use crate::{api::LocalApiServer,runtime::{InferenceClient,RuntimeEvent},store::AppStore};
use bmoe_core::{AutoTier,AutoTuner,ChatSessionRecord,ChatTurn,ContextPlanner,DeviceProfile,EngineSettings,GenerationStats,GgufInfo,MessageRecord,ModelFacts,ModelKind,ModelRecord,TunedValues,StreamOutputParser,ParsedChunk};
use eframe::egui::{self,Align,Color32,Layout,RichText,ScrollArea,TextEdit};
use std::{collections::HashMap, path::PathBuf, sync::mpsc::{self,Receiver,Sender}, time::Duration};
#[cfg(target_os="android")]
use std::{fs, path::Path};
use robius_file_picker::FileDialog;

#[derive(Debug,Clone,Copy,PartialEq,Eq)] enum Page { Chat, Models, AutoSettings, Workspace, Settings, Api }
struct PendingMessage { session_id:String, assistant_id:String }
enum PickerEvent {
    Model(Result<Option<PathBuf>,String>),
    Export(Result<Option<String>,String>),
}
pub struct BigMoeApp {
    store:AppStore, runtime:InferenceClient, page:Page,
    sessions:Vec<ChatSessionRecord>, selected_session:String, messages:Vec<MessageRecord>, models:Vec<ModelRecord>,
    selected_model:String, settings:EngineSettings, default_tuned:TunedValues, device:DeviceProfile, tier:AutoTier, allow_npu:bool,
    input:String, new_model_path:String, status:String, error:String, pending:HashMap<String,PendingMessage>, generating:bool,
    workspace_path:String, workspace_text:String, api_port:u16, api_key:String, api_server:Option<LocalApiServer>,
    show_reasoning:bool, sidebar_width:f32,
    file_picker_tx:Sender<PickerEvent>, file_picker_rx:Receiver<PickerEvent>,
}
impl BigMoeApp {
    pub fn new(_cc:&eframe::CreationContext<'_>)->Self {
        let db_path=app_data_dir().join("app.sqlite3");
        let mut store=AppStore::open(&db_path).unwrap_or_else(|e|panic!("Could not open local database at {}: {e}",db_path.display()));
        let mut settings=store.setting::<EngineSettings>("engine_settings").ok().flatten().unwrap_or_default();
        let default_tuned=match store.setting::<TunedValues>("default_tuned").ok().flatten() {
            Some(values)=>values,
            None=>{let values=settings.tuned.clone();let _=store.save_setting("default_tuned",&values);values},
        };
        settings.tuned=default_tuned.clone();
        let selected_model=store.setting::<String>("selected_model").ok().flatten().unwrap_or_default();
        if !selected_model.is_empty() {
            if let Ok(Some(profile))=store.model_profile::<TunedValues>(&selected_model) {
                settings.tuned=profile;
            }
        }
        let mut sessions=store.sessions().unwrap_or_default();
        if sessions.is_empty(){if let Ok(s)=store.create_session("New chat",&settings.system_prompt){sessions.push(s);}}
        let selected_session=sessions.first().map(|s|s.id.clone()).unwrap_or_default();
        let messages=store.messages(&selected_session).unwrap_or_default();
        let models=store.models().unwrap_or_default();
        let device=detect_device_profile();
        let runtime=InferenceClient::spawn();
        if !selected_model.is_empty(){runtime.load_with_settings(selected_model.clone(),settings.backend.clone(),settings.tuned.context_length);}
        let (file_picker_tx,file_picker_rx)=mpsc::channel();
        Self {store,runtime,page:Page::Chat,sessions,selected_session,messages,models,selected_model,settings,default_tuned,device,tier:AutoTier::Balanced,allow_npu:false,input:String::new(),new_model_path:String::new(),status:"Ready".into(),error:String::new(),pending:HashMap::new(),generating:false,workspace_path:String::new(),workspace_text:String::new(),api_port:8080,api_key:String::new(),api_server:None,show_reasoning:false,sidebar_width:255.0,file_picker_tx,file_picker_rx}
    }
    fn refresh_sessions(&mut self){self.sessions=self.store.sessions().unwrap_or_default();}
    fn refresh_models(&mut self){self.models=self.store.models().unwrap_or_default();}
    fn select_session(&mut self,id:String){
        self.selected_session=id;
        self.messages=self.store.messages(&self.selected_session).unwrap_or_default();
        self.generating=self.pending.values().any(|p|p.session_id==self.selected_session);
        self.status=if self.generating {"Generation is still running for this chat".into()} else {"Chat selected".into()};
    }
    fn persist_settings(&mut self){if let Err(e)=self.store.save_setting("engine_settings",&self.settings){self.error=e.to_string();}else{self.status="Settings saved".into();}}
    fn select_model(&mut self,path:String){
        if path == self.selected_model { return; }
        if self.api_server.is_some() {
            self.error="Stop the local API before changing models; its model is pinned while the server runs.".into();
            return;
        }
        self.settings.tuned=self.default_tuned.clone();
        if !path.is_empty() {
            match self.store.model_profile::<TunedValues>(&path) {
                Ok(Some(profile)) => { self.settings.tuned=profile; }
                Ok(None) => {}
                Err(error) => self.error=format!("Could not load this model's saved settings: {error}"),
            }
        }
        self.selected_model=path.clone();
        if let Err(error)=self.store.save_setting("selected_model",&self.selected_model){self.error=error.to_string();}
        if path.is_empty(){self.runtime.unload();self.status="No model selected".into();}
        else{self.runtime.load_with_settings(path,self.settings.backend.clone(),self.settings.tuned.context_length);self.status="Loading model…".into();}
    }
    fn handle_runtime_events(&mut self) {
        let events = self.runtime.try_events();
        let mut streamed_deltas: HashMap<String, String> = HashMap::new();
        for event in events {
            if matches!(&event, RuntimeEvent::Answer { .. } | RuntimeEvent::Error { .. }) {
                self.flush_streamed_deltas(&mut streamed_deltas);
            }
            match event {
                RuntimeEvent::Loading { path } => {
                    self.status = format!("Loading {}…", PathBuf::from(path).file_name().and_then(|x| x.to_str()).unwrap_or("model"));
                    self.error.clear();
                }
                RuntimeEvent::Loaded { path, architecture } => {
                    self.status = format!("Model ready: {} ({architecture})", PathBuf::from(path).file_name().and_then(|x| x.to_str()).unwrap_or("model"));
                    self.error.clear();
                }
                RuntimeEvent::Unloaded => {
                    self.status = "Model unloaded".into();
                    self.generating = false;
                }
                RuntimeEvent::Token { request_id, delta } => {
                    if let Some(pending) = self.pending.get(&request_id) {
                        streamed_deltas.entry(pending.assistant_id.clone()).or_default().push_str(&delta);
                        if pending.session_id == self.selected_session {
                            if let Some(message) = self.messages.iter_mut().find(|m| m.id == pending.assistant_id) {
                                message.content.push_str(&delta);
                            }
                        }
                    }
                }
                RuntimeEvent::Answer { request_id, text, stats } => {
                    if let Some(pending) = self.pending.remove(&request_id) {
                        if let Err(error) = self.store.complete_message(&pending.assistant_id, &text, "", &stats) {
                            self.error = error.to_string();
                        }
                        if pending.session_id == self.selected_session {
                            self.messages = self.store.messages(&self.selected_session).unwrap_or_default();
                        }
                        self.generating = self.pending.values().any(|p| p.session_id == self.selected_session);
                        self.status = format!("Done · {:.1} tok/s · {} tokens", stats.tokens_per_second, stats.generated_tokens);
                        self.save_detected_artifacts(&pending.session_id, &text);
                    }
                }
                RuntimeEvent::Error { request_id, message } => {
                    if let Some(id) = request_id {
                        if let Some(pending) = self.pending.remove(&id) {
                            if pending.session_id == self.selected_session {
                                self.messages = self.store.messages(&self.selected_session).unwrap_or_default();
                            }
                        }
                    }
                    self.generating = self.pending.values().any(|p| p.session_id == self.selected_session);
                    self.error = message;
                    self.status = "Action failed".into();
                }
            }
        }
        self.flush_streamed_deltas(&mut streamed_deltas);
    }
    fn flush_streamed_deltas(&mut self, deltas: &mut HashMap<String, String>) {
        for (message_id, delta) in deltas.drain() {
            if let Err(error) = self.store.append_message_content(&message_id, &delta) {
                self.error = error.to_string();
            }
        }
    }
    fn send(&mut self){
        let prompt=self.input.trim().to_owned();if prompt.is_empty()||self.generating{return;}
        if self.selected_model.is_empty(){self.error="Add and select a GGUF model first.".into();return;}
        let should_title=self.sessions.iter().any(|s|s.id==self.selected_session && s.title.trim().eq_ignore_ascii_case("new chat"));
        if should_title {
            let mut title:String=prompt.chars().take(42).collect();
            if prompt.chars().count()>42 {title.push('…');}
            if let Err(error)=self.store.rename_session(&self.selected_session,&title){self.error=error.to_string();}
            self.refresh_sessions();
        }
        let old_messages=self.messages.clone();let last_id=old_messages.last().map(|m|m.id.as_str());
        let history:Vec<ChatTurn>=old_messages.iter().filter(|m|m.role=="user"||m.role=="assistant").map(|m|ChatTurn{role:m.role.clone(),content:m.content.clone()}).collect();
        let nctx=self.settings.tuned.context_length as usize;
        let sys_tokens=ContextPlanner::estimate_tokens(&self.settings.system_prompt);
        let prompt_tokens=ContextPlanner::estimate_tokens(&prompt);
        let budget=ContextPlanner::history_budget(nctx,sys_tokens,prompt_tokens,self.settings.max_tokens.max(0) as usize);
        let prepared=ContextPlanner::prepare(&history,&prompt,budget);
        let request_id=uuid::Uuid::new_v4().to_string();let user_id=uuid::Uuid::new_v4().to_string();let assistant_id=uuid::Uuid::new_v4().to_string();
        let state_key=ContextPlanner::state_key(&self.selected_session,last_id,&self.settings.system_prompt);
        let next_state_key=ContextPlanner::state_key(&self.selected_session,Some(&assistant_id),&self.settings.system_prompt);
        if let Err(e)=self.store.add_message_with_id(user_id,&self.selected_session,"user",&prompt,"",None){self.error=e.to_string();return;}
        if let Err(e)=self.store.add_message_with_id(assistant_id.clone(),&self.selected_session,"assistant","","",None){self.error=e.to_string();return;}
        self.messages=self.store.messages(&self.selected_session).unwrap_or_default();
        self.pending.insert(request_id.clone(),PendingMessage{session_id:self.selected_session.clone(),assistant_id});
        self.runtime.generate(request_id,self.selected_session.clone(),state_key,next_state_key,self.selected_model.clone(),self.settings.backend.clone(),self.settings.system_prompt.clone(),prepared.history,prepared.prompt,self.settings.max_tokens.max(0) as usize,self.settings.tuned.context_length,self.settings.tuned.batch_width,self.settings.seed,self.settings.temperature,self.settings.top_p,self.settings.top_k);
        self.input.clear();self.generating=true;self.status=if prepared.trimmed{"Generating · older context trimmed".into()}else{"Generating…".into()};self.error.clear();
    }
    fn open_model_picker(&mut self, ctx:&egui::Context) {
        let tx=self.file_picker_tx.clone();
        let repaint=ctx.clone();
        let picker=FileDialog::new().add_filter("GGUF model", &["gguf"]).set_title("Choose a local GGUF model");
        match picker.pick_file(move |result| {
            let result=match result {
                Ok(Some(file)) => resolve_picked_model(file).map(Some),
                Ok(None) => Ok(None),
                Err(error) => Err(error.to_string()),
            };
            let _=tx.send(PickerEvent::Model(result));
            repaint.request_repaint();
        }) {
            Ok(()) => { self.status="Choose a GGUF model in the system file picker…".into(); self.error.clear(); }
            Err(error) => self.error=format!("Could not open file picker: {error}"),
        }
    }
    fn handle_file_picker_events(&mut self) {
        loop {
            match self.file_picker_rx.try_recv() {
                Ok(PickerEvent::Model(Ok(Some(path)))) => {
                    self.new_model_path=path.to_string_lossy().to_string();
                    self.status="Model file selected. Inspect it before loading.".into();
                    self.error.clear();
                }
                Ok(PickerEvent::Model(Ok(None))) => { self.status="Model selection cancelled".into(); }
                Ok(PickerEvent::Model(Err(error))) => { self.error=format!("Model file selection failed: {error}"); }
                Ok(PickerEvent::Export(Ok(Some(destination)))) => { self.status=format!("Chat export saved to {destination}"); self.error.clear(); }
                Ok(PickerEvent::Export(Ok(None))) => { self.status="Chat export cancelled".into(); }
                Ok(PickerEvent::Export(Err(error))) => { self.error=format!("Chat export failed: {error}"); }
                Err(mpsc::TryRecvError::Empty | mpsc::TryRecvError::Disconnected) => break,
            }
        }
    }
    fn export_chat(&mut self,format:&str,ctx:&egui::Context){
        if self.messages.is_empty(){self.error="There are no messages to export yet.".into();return;}
        let (extension,mime,bytes)=match format {
            "json" => match serde_json::to_vec_pretty(&self.messages){Ok(data)=>("json","application/json",data),Err(error)=>{self.error=format!("Could not serialize chat: {error}");return;}},
            "txt" => {let text=self.messages.iter().map(|m|format!("{}\n{}\n\n",if m.role=="user"{"You"}else if m.role=="assistant"{"Assistant"}else{&m.role},m.content)).collect::<String>();("txt","text/plain; charset=utf-8",text.into_bytes())},
            _ => {let text=self.messages.iter().map(|m|format!("### {}\n\n{}\n\n",if m.role=="user"{"You"}else if m.role=="assistant"{"Assistant"}else{&m.role},m.content)).collect::<String>();("md","text/markdown; charset=utf-8",text.into_bytes())},
        };
        let filename=format!("bigmoe-chat-{}.{}",chrono::Local::now().format("%Y%m%d-%H%M%S"),extension);
        let tx=self.file_picker_tx.clone();
        let repaint=ctx.clone();
        match FileDialog::new().set_title("Export chat").set_file_name(filename).set_mime_type(mime).save_data(bytes,move|result|{
            let event=match result {
                Ok(Some(file))=>{
                    let location=file.path().map(|p|p.to_string_lossy().to_string()).or_else(||file.uri().map(str::to_owned)).unwrap_or_else(||"selected location".into());
                    PickerEvent::Export(Ok(Some(location)))
                }
                Ok(None)=>PickerEvent::Export(Ok(None)),
                Err(error)=>PickerEvent::Export(Err(error.to_string())),
            };
            let _=tx.send(event);
            repaint.request_repaint();
        }) {
            Ok(())=>{self.status=format!("Choose where to save the {extension} export…");self.error.clear();}
            Err(error)=>self.error=format!("Could not open export dialog: {error}"),
        }
    }
    fn add_model(&mut self){
        let path=PathBuf::from(self.new_model_path.trim());if path.as_os_str().is_empty(){self.error="Enter a model's full .gguf path.".into();return;}
        match GgufInfo::inspect(&path){Ok(info)=>{let model=ModelRecord{id:uuid::Uuid::new_v4().to_string(),path:info.path.to_string_lossy().to_string(),display_name:info.display_name.clone(),size_bytes:info.size_bytes,kind:if info.is_moe(){ModelKind::Moe}else{ModelKind::Dense},is_ready:true,metadata_json:serde_json::to_string(&info).unwrap_or_else(|_|"{}".into())};
            match self.store.upsert_model(&model){Ok(())=>{self.refresh_models();self.new_model_path.clear();self.status=format!("Added {} · {} MiB · {}",info.display_name,info.size_mb(),info.architecture.as_deref().unwrap_or("unknown architecture"));self.error.clear();},Err(e)=>self.error=e.to_string()}}
            Err(e)=>self.error=format!("GGUF inspection failed: {e}")}
    }
    fn delete_current_chat(&mut self){
        if self.selected_session.is_empty() || self.pending.values().any(|p|p.session_id==self.selected_session) {return;}
        let id=self.selected_session.clone();
        if let Err(error)=self.store.delete_session(&id){self.error=error.to_string();return;}
        self.refresh_sessions();
        if self.sessions.is_empty(){if let Ok(s)=self.store.create_session("New chat",&self.settings.system_prompt){self.sessions.push(s);}}
        self.selected_session=self.sessions.first().map(|s|s.id.clone()).unwrap_or_default();
        self.messages=self.store.messages(&self.selected_session).unwrap_or_default();
        self.generating=self.pending.values().any(|p|p.session_id==self.selected_session);
        self.status="Chat deleted".into();
    }
    fn save_detected_artifacts(&mut self,session_id:&str,text:&str){
        let mut parser=StreamOutputParser::new();let mut found=Vec::new();for chunk in parser.process_token(text).into_iter().chain(parser.flush()){if let ParsedChunk::ArtifactDetected(a)=chunk{found.push(a);}}
        for a in found {let _=self.store.save_artifact(session_id,&a.title,match a.kind{bmoe_core::ArtifactType::Html=>"html",bmoe_core::ArtifactType::Svg=>"svg",bmoe_core::ArtifactType::Mermaid=>"mermaid",bmoe_core::ArtifactType::Code=>"code"},&a.language,a.file_name.as_deref(),&a.content);}
    }
    fn device_model_facts(&self)->Option<ModelFacts>{
        let m=self.models.iter().find(|m|m.path==self.selected_model)?;
        let info=GgufInfo::inspect(&m.path).ok()?;
        Some(ModelFacts{path:m.path.clone(),name:m.display_name.clone(),size_bytes:m.size_bytes,kind:m.kind,expert_count:info.expert_count.unwrap_or(0) as u32,expert_used:info.expert_used.unwrap_or(0) as u32})
    }
    fn draw_nav(&mut self,ctx:&egui::Context){
        egui::SidePanel::left("navigation").exact_width(self.sidebar_width).resizable(true).show(ctx,|ui|{
            ui.add_space(8.0);ui.horizontal(|ui|{ui.heading(RichText::new("BigMoeOnEdge+").strong());ui.label(RichText::new("RUST").small().color(Color32::from_rgb(90,190,160)));});
            ui.label(RichText::new("Local AI workspace").small().weak());ui.add_space(16.0);
            for (page,label,icon) in [(Page::Chat,"Chat","◉"),(Page::Models,"Models","▤"),(Page::AutoSettings,"Auto Settings","✦"),(Page::Workspace,"Workspace","⌘"),(Page::Settings,"Settings","⚙"),(Page::Api,"Local API","⇄")] {
                let selected=self.page==page;let button=egui::Button::new(format!("{icon}   {label}")).selected(selected).min_size(egui::vec2(ui.available_width(),34.0));if ui.add(button).clicked(){self.page=page;}
            }
            ui.add_space(18.0);ui.separator();ui.horizontal(|ui|{ui.strong("Chats");if ui.small_button("＋").clicked(){if let Ok(s)=self.store.create_session("New chat",&self.settings.system_prompt){self.selected_session=s.id.clone();self.sessions.insert(0,s);self.messages.clear();self.generating=false;self.page=Page::Chat;}}});
            ScrollArea::vertical().max_height(ui.available_height()-50.0).show(ui,|ui|{
                for s in self.sessions.clone(){let is_selected=s.id==self.selected_session;let label=if s.title.trim().is_empty(){"New chat"}else{&s.title};if ui.add_sized([ui.available_width(),32.0],egui::Button::new(label).selected(is_selected)).clicked(){self.select_session(s.id);self.page=Page::Chat;}}
            });
            ui.with_layout(Layout::bottom_up(Align::Min),|ui|{ui.separator();ui.label(RichText::new(self.status.clone()).small().weak());if !self.selected_model.is_empty(){ui.label(RichText::new(PathBuf::from(&self.selected_model).file_name().and_then(|x|x.to_str()).unwrap_or("model")).small());}else{ui.label(RichText::new("No model selected").small().color(Color32::from_rgb(225,170,80)));}});
        });
    }
    fn draw_chat(&mut self,ui:&mut egui::Ui){
        let session_busy=self.pending.values().any(|p|p.session_id==self.selected_session);
        ui.horizontal(|ui|{ui.heading(self.sessions.iter().find(|s|s.id==self.selected_session).map(|s|s.title.as_str()).unwrap_or("Chat"));
            if ui.add_enabled(!session_busy,egui::Button::new("Delete chat")).clicked(){self.delete_current_chat();}
            ui.with_layout(Layout::right_to_left(Align::Center),|ui|{
            if ui.button("Unload").clicked(){self.select_model(String::new());}
            let mut selected_path=self.selected_model.clone();
            ui.add_enabled_ui(self.api_server.is_none(),|ui|{
                egui::ComboBox::from_id_salt("active_model_select").selected_text(self.models.iter().find(|m|m.path==self.selected_model).map(|m|m.display_name.as_str()).unwrap_or("Select model")).show_ui(ui,|ui|{for m in self.models.clone(){ui.selectable_value(&mut selected_path,m.path.clone(),m.display_name);}});
            });
            if selected_path!=self.selected_model {self.select_model(selected_path);}
        });});
        ui.horizontal(|ui|{
            ui.label(RichText::new("Export chat:").small().weak());
            if ui.button("Markdown").clicked(){self.export_chat("md",ui.ctx());}
            if ui.button("TXT").clicked(){self.export_chat("txt",ui.ctx());}
            if ui.button("JSON").clicked(){self.export_chat("json",ui.ctx());}
        });
        ui.separator();
        ScrollArea::vertical().stick_to_bottom(true).auto_shrink([false,false]).show(ui,|ui|{
            if self.messages.is_empty(){ui.add_space(48.0);ui.vertical_centered(|ui|{ui.heading("Your local AI, your rules.");ui.label("Choose a GGUF model in Models, then start chatting.");});}
            for m in &self.messages{let is_user=m.role=="user";ui.horizontal(|ui|{if is_user{ui.add_space((ui.available_width()*0.15).max(8.0));}ui.allocate_ui_with_layout(egui::vec2(ui.available_width()*if is_user{0.85}else{1.0},0.0),Layout::top_down(Align::Min),|ui|{
                    egui::Frame::group(ui.style()).fill(if is_user{ui.visuals().faint_bg_color}else{ui.visuals().panel_fill}).corner_radius(egui::CornerRadius::same(10)).inner_margin(egui::Margin::symmetric(12,9)).show(ui,|ui|{ui.label(RichText::new(if is_user{"You"}else{"Assistant"}).small().strong().weak());ui.add(egui::Label::new(&m.content).wrap());
                        if self.show_reasoning && !m.reasoning.trim().is_empty(){ui.collapsing("Thinking",|ui|{ui.add(egui::Label::new(&m.reasoning).wrap());});}
                        if let Some(st)=&m.stats{ui.label(RichText::new(format!("{:.1} tok/s · {} generated · {:.2}s prefill",st.tokens_per_second,st.generated_tokens,st.prefill_seconds)).small().weak());}
                    });
                });});ui.add_space(7.0);}
            if self.generating{ui.horizontal(|ui|{ui.spinner();ui.label("Model is thinking…");});}
        });
        ui.separator();ui.horizontal(|ui|{ui.checkbox(&mut self.show_reasoning,"Show Thinking");ui.label(RichText::new("Responses now stream as they are generated; separate reasoning-channel parsing is still being ported.").small().weak());});
        let response=ui.add_sized([ui.available_width(),76.0],TextEdit::multiline(&mut self.input).hint_text("Message your local model… (Ctrl+Enter to send)").desired_rows(3));
        let send=ui.with_layout(Layout::right_to_left(Align::Center),|ui|{let clicked=ui.add_enabled(!self.generating&& !self.input.trim().is_empty(),egui::Button::new("Send  ↗").min_size(egui::vec2(92.0,34.0))).clicked();ui.label(RichText::new(format!("Context {}",self.settings.tuned.context_length)).small().weak());clicked}).inner;
        if send||(response.has_focus()&&ui.input(|i|i.key_pressed(egui::Key::Enter)&&i.modifiers.ctrl)){self.send();}
    }
    fn draw_models(&mut self, ui: &mut egui::Ui) {
        ui.heading("Models");
        ui.label("Register a local GGUF by path. Inspection reads the header only; it doesn't copy or rewrite the model.");
        ui.add_space(10.0);
        ui.horizontal(|ui| {
            ui.add(
                TextEdit::singleline(&mut self.new_model_path)
                    .hint_text("Path to a .gguf model")
                    .desired_width((ui.available_width() - 200.0).max(120.0)),
            );
            if ui.button("Browse…").clicked() {
                self.open_model_picker(ui.ctx());
            }
            if ui.button("Inspect + Add").clicked() {
                self.add_model();
            }
        });
        ui.add_space(12.0);
        ui.separator();

        if self.models.is_empty() {
            ui.label("No models registered yet.");
        }
        for model in self.models.clone() {
            egui::Frame::group(ui.style()).show(ui, |ui| {
                ui.horizontal(|ui| {
                    ui.vertical(|ui| {
                        ui.strong(&model.display_name);
                        ui.label(
                            RichText::new(format!(
                                "{:.2} GiB · {} · {}",
                                model.size_bytes as f64 / 1024f64.powi(3),
                                if model.kind == ModelKind::Moe { "MoE" } else { "Dense" },
                                model.path
                            ))
                            .small()
                            .weak(),
                        );
                    });
                    ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                        if ui.button("Remove").clicked() {
                            let _ = self.store.remove_model(&model.path);
                            if self.selected_model == model.path {
                                self.select_model(String::new());
                            }
                            self.refresh_models();
                        }
                        if ui.button(if self.selected_model == model.path { "Selected" } else { "Load" }).clicked() {
                            self.select_model(model.path.clone());
                            self.page = Page::Chat;
                        }
                    });
                });
                if let Ok(info) = GgufInfo::inspect(&model.path) {
                    ui.label(
                        RichText::new(format!(
                            "GGUF v{} · {} tensors · architecture {} · context {}",
                            info.version,
                            info.tensor_count,
                            info.architecture.as_deref().unwrap_or("unknown"),
                            info.context_length.map(|x| x.to_string()).unwrap_or_else(|| "unknown".into())
                        ))
                        .small()
                        .color(Color32::GRAY),
                    );
                }
            });
            ui.add_space(6.0);
        }
        ui.add_space(8.0);
        ui.label(
            RichText::new("Android uses the system document picker and copies selected models into private app storage. Desktop models are loaded in place. Split-GGUF grouping/resume, MTP sidecars, and full multimodal projector compatibility remain unported.")
                .small()
                .weak(),
        );
    }
    fn draw_auto_settings(&mut self,ui:&mut egui::Ui){
        ui.heading("Auto Settings");ui.label("Choose the speed/accuracy trade-off; the planner only edits inference-performance settings.");ui.add_space(8.0);
        ui.horizontal_wrapped(|ui|{for tier in [AutoTier::Fastest,AutoTier::Balanced,AutoTier::Accurate]{let selected=self.tier==tier;if ui.add_sized([ui.available_width()/3.0-6.0,72.0],egui::Button::new(format!("{}\n{}",tier.title(),tier.tagline())).selected(selected)).clicked(){self.tier=tier;}}});ui.add_space(10.0);
        ui.horizontal(|ui|{self.allow_npu=false;ui.add_enabled(false,egui::Checkbox::new(&mut self.allow_npu,"NPU prefill unavailable in this backend"));ui.label(RichText::new("The backend selector in Settings controls Cera accelerator selection. This toggle is for the original engine’s special NPU-prefill path, which is not ported.").small().weak());});
        if let Some(model)=self.device_model_facts(){let tuned=AutoTuner::plan(&self.device,&model,self.tier,self.allow_npu);let fits=AutoTuner::fits_in_ram(&self.device,&model,&tuned);let tps=AutoTuner::estimate_tps(&self.device,&model,self.tier,&tuned);
            ui.add_space(12.0);ui.separator();ui.heading("Plan preview");ui.label(format!("{} · {:.2} GiB · {}",model.name,model.size_gb(),if model.is_moe(){"Mixture of Experts"}else{"Dense model"}));ui.label(RichText::new("Important: context length and prefill micro-batch are applied. The original engine’s expert-cache, expert-skipping, prefetch, and CPU-thread tuning values are displayed as proposals only; Cera does not consume those custom knobs here.").small().color(Color32::from_rgb(220,170,80)));
            egui::Grid::new("auto_plan_values").num_columns(2).striped(true).show(ui,|ui|{ui.label("Context length");ui.strong(format!("{} tokens",tuned.context_length));ui.end_row();ui.label("CPU threads");ui.strong(format!("{} target (not applied)",tuned.thread_count));ui.end_row();ui.label("Prompt micro-batch");ui.strong(format!("{} (applied)",tuned.batch_width));ui.end_row();if model.is_moe(){ui.label("Expert cache proposal");ui.strong(format!("{} MiB (not applied)",tuned.cache_mb));ui.end_row();ui.label("Expert skip proposal");ui.strong(format!("{}% (not applied)",tuned.drop_cold_pct));ui.end_row();}ui.label("Estimated speed");ui.strong(format!("{tps:.1} tokens/s (legacy estimate, not a Cera benchmark)"));ui.end_row();ui.label("Legacy engine RAM estimate");ui.strong(format!("{} MiB / {} MiB (not Cera allocation)",AutoTuner::footprint_mb(&model,&tuned),AutoTuner::usable_mb(&self.device)));ui.end_row();});
            ui.colored_label(if fits{Color32::from_rgb(70,180,120)}else{Color32::from_rgb(230,120,75)},if fits{"Legacy planner estimates this fits; Cera memory still needs real-device validation"}else{"Legacy planner estimates over budget; Cera memory behavior may differ"});
            ui.add_space(10.0);
            if self.api_server.is_some() {ui.label(RichText::new("Stop the local API before applying a new context plan; its runtime settings are pinned while active.").small().weak());}
            if ui.add_enabled(self.api_server.is_none(),egui::Button::new("Apply compatible settings")).clicked(){AutoTuner::apply_to(&mut self.settings,tuned.clone());self.persist_settings();let _=self.store.save_model_profile(&model.path,&tuned);if !self.selected_model.is_empty(){self.runtime.load_with_settings(self.selected_model.clone(),self.settings.backend.clone(),self.settings.tuned.context_length);}self.status="Saved plan; reloading engine context. Only supported settings apply.".into();}
            ui.separator();ui.collapsing("Legacy engine-plan details (not applied by Cera)",|ui|{for line in AutoTuner::describe(&tuned,&model){ui.label(format!("• {line}"));}});
        } else {ui.label("Select a valid model in Models to generate a plan.");}
        ui.add_space(12.0);ui.label(RichText::new(format!("Memory detected: {} MiB total / {} MiB available · {} logical CPUs · {}",self.device.total_ram_mb,self.device.avail_ram_mb,self.device.cores,self.device.soc)).small().weak());
        ui.label(RichText::new("Safety note: RAM and tokens/s are heuristics. This port has no device benchmark calibration yet, and engine-specific knobs are not wired until backend parity is verified.").small().weak());
    }
    fn draw_workspace(&mut self,ui:&mut egui::Ui){
        ui.heading("Workspace & files");
        ui.label("Open local text files or inspect artifacts extracted from chat replies.");
        let artifacts=self.store.artifacts(None).unwrap_or_default();
        ui.collapsing(format!("Saved artifacts ({})",artifacts.len()),|ui|{
            if artifacts.is_empty(){ui.label("No artifacts saved yet. Code, HTML, SVG, and Mermaid fenced blocks are detected after a response completes.");}
            ScrollArea::vertical().max_height(130.0).show(ui,|ui|{
                for artifact in artifacts {
                    ui.horizontal(|ui|{
                        if ui.small_button(format!("{} · {}",artifact.title,artifact.language)).clicked(){self.workspace_text=artifact.content.clone();self.workspace_path=artifact.file_name.unwrap_or_default();self.status=format!("Loaded artifact: {}",artifact.title);}
                        if ui.small_button("Delete").clicked(){if let Err(e)=self.store.delete_artifact(&artifact.id){self.error=e.to_string();}}
                    });
                }
            });
        });
        ui.add_space(6.0);
        ui.horizontal(|ui|{
            ui.add(TextEdit::singleline(&mut self.workspace_path).hint_text("File path").desired_width(ui.available_width()-160.0));
            if ui.button("Open").clicked(){match std::fs::read_to_string(&self.workspace_path){Ok(s)=>{self.workspace_text=s;self.status="File opened".into();self.error.clear();},Err(e)=>self.error=e.to_string()}}
            if ui.button("Save").clicked(){if self.workspace_path.trim().is_empty(){self.error="Enter a path before saving.".into();}else{match std::fs::write(&self.workspace_path,&self.workspace_text){Ok(())=>self.status="File saved".into(),Err(e)=>self.error=e.to_string()}}}
        });
        ui.add_space(8.0);
        ui.add_sized(ui.available_size(),TextEdit::multiline(&mut self.workspace_text).font(egui::TextStyle::Monospace).code_editor());
        ui.label(RichText::new("Still not ported here: archive/document extraction, workspace tree/diff, image attachments, and generated-file preview sandboxing.").small().weak());
    }
    fn draw_settings(&mut self,ui:&mut egui::Ui){
        ui.heading("Settings");ui.label("Chat sampling, compute backend, and app preferences");ui.add_space(10.0);
        let old_backend=self.settings.backend.clone();
        ui.add_enabled_ui(self.api_server.is_none(),|ui|{
            ui.horizontal(|ui|{ui.label("Compute backend");egui::ComboBox::from_id_salt("compute_backend").selected_text(match self.settings.backend.as_str(){"cpu"=>"CPU only","gpu"=>"GPU (wgpu/Vulkan/DX12)","metal"=>"Metal (Apple)","hexagon"=>"Qualcomm Hexagon","npu"=>"Any NPU",_=>"Automatic (recommended)"}).show_ui(ui,|ui|{ui.selectable_value(&mut self.settings.backend,"auto".into(),"Automatic (recommended)");ui.selectable_value(&mut self.settings.backend,"cpu".into(),"CPU only");ui.selectable_value(&mut self.settings.backend,"gpu".into(),"GPU (wgpu/Vulkan/DX12)");ui.selectable_value(&mut self.settings.backend,"metal".into(),"Metal (Apple)");ui.selectable_value(&mut self.settings.backend,"hexagon".into(),"Qualcomm Hexagon");ui.selectable_value(&mut self.settings.backend,"npu".into(),"Any NPU");});});
        });
        if self.api_server.is_some(){ui.label(RichText::new("Compute backend is locked while the local API is running.").small().weak());}
        if self.settings.backend!=old_backend {self.persist_settings();if !self.selected_model.is_empty(){self.runtime.load_with_settings(self.selected_model.clone(),self.settings.backend.clone(),self.settings.tuned.context_length);self.status=format!("Reloading model with {} backend…",self.settings.backend);}}
        ui.label(RichText::new("Explicit accelerators require a compatible build and model. Automatic selection falls back when a backend cannot load the model.").small().weak());
        ui.add(egui::Slider::new(&mut self.settings.temperature,0.0..=2.0).text("Temperature"));ui.add(egui::Slider::new(&mut self.settings.top_p,0.0..=1.0).text("Top-p"));ui.add(egui::Slider::new(&mut self.settings.top_k,0..=100).text("Top-k"));ui.add(egui::Slider::new(&mut self.settings.max_tokens,0..=32768).text("Max generated tokens (0 = context default)"));ui.label("System prompt");ui.add_sized([ui.available_width(),110.0],TextEdit::multiline(&mut self.settings.system_prompt).hint_text("Optional system prompt"));ui.horizontal(|ui|{ui.label("Theme");egui::ComboBox::from_id_salt("theme").selected_text(&self.settings.theme).show_ui(ui,|ui|{ui.selectable_value(&mut self.settings.theme,"system".into(),"System");ui.selectable_value(&mut self.settings.theme,"dark".into(),"Dark");ui.selectable_value(&mut self.settings.theme,"light".into(),"Light");});});ui.add_space(12.0);if ui.button("Save settings").clicked(){self.persist_settings();}
        ui.separator();ui.heading("Engine & portability");ui.label("Rust core is separate from Android glue. NPU routing, MTP draft sidecars, image projector, and legacy model-specific MoE knobs still require backend integration and device verification.");
    }
    fn draw_api(&mut self, ui: &mut egui::Ui) {
        ui.heading("Local API server");
        ui.label("OpenAI-compatible /v1/chat/completions and Anthropic-compatible /v1/messages endpoints, loopback only.");
        ui.add_space(10.0);
        ui.add_enabled_ui(self.api_server.is_none(), |ui| {
            ui.horizontal(|ui| {
                ui.label("Port");
                ui.add(egui::DragValue::new(&mut self.api_port).range(1024..=65535));
            });
            ui.horizontal(|ui| {
                ui.label("Bearer/API key");
                ui.add(TextEdit::singleline(&mut self.api_key).password(true).desired_width(230.0));
            });
        });
        ui.label(RichText::new("Leave the key empty to disable authentication only for localhost use. Do not expose this server to a network.").small().weak());

        if let Some(server) = &self.api_server {
            ui.colored_label(Color32::from_rgb(65, 180, 120), format!("Running at {}", server.address));
            if ui.button("Stop server").clicked() {
                if let Some(mut server) = self.api_server.take() {
                    server.stop();
                }
                self.status = "Local API stopped".into();
            }
        } else if ui.button("Start local API").clicked() {
            if self.selected_model.is_empty() {
                self.error = "Select a model before starting the API.".into();
            } else {
                match LocalApiServer::start(
                    self.runtime.clone(),
                    self.selected_model.clone(),
                    self.api_key.clone(),
                    self.api_port,
                    self.settings.backend.clone(),
                    self.settings.tuned.context_length,
                ) {
                    Ok(server) => {
                        self.status = format!("API listening at {}", server.address);
                        self.api_server = Some(server);
                        self.error.clear();
                    }
                    Err(error) => self.error = error,
                }
            }
        }
        ui.add_space(10.0);
        ui.label(RichText::new("OpenAI and Anthropic SSE streaming is enabled. Request cancellation, API tool execution, richer usage parity, and concurrent-model scheduling still need work.").small().weak());
    }

}
impl eframe::App for BigMoeApp {
    fn update(&mut self,ctx:&egui::Context,_frame:&mut eframe::Frame){
        self.handle_file_picker_events();
        self.handle_runtime_events();
        if self.settings.theme=="dark"{ctx.set_visuals(egui::Visuals::dark());}else if self.settings.theme=="light"{ctx.set_visuals(egui::Visuals::light());}
        egui::TopBottomPanel::top("top_bar").show(ctx,|ui|{ui.horizontal(|ui|{ui.label(RichText::new("BMOE / RUST REWRITE").small().strong().color(Color32::from_rgb(90,190,160)));ui.separator();ui.label(RichText::new(&self.status).small());if !self.error.is_empty(){ui.with_layout(Layout::right_to_left(Align::Center),|ui|{ui.label(RichText::new(&self.error).small().color(Color32::LIGHT_RED));});}});});
        self.draw_nav(ctx);
        egui::CentralPanel::default().show(ctx,|ui|{match self.page{Page::Chat=>self.draw_chat(ui),Page::Models=>self.draw_models(ui),Page::AutoSettings=>self.draw_auto_settings(ui),Page::Workspace=>self.draw_workspace(ui),Page::Settings=>self.draw_settings(ui),Page::Api=>self.draw_api(ui)}});
        if self.generating||self.api_server.is_some(){ctx.request_repaint_after(Duration::from_millis(80));}
    }
}
impl Drop for BigMoeApp {fn drop(&mut self){if let Some(mut server)=self.api_server.take(){server.stop();}self.runtime.shutdown();}}

fn app_data_dir()->PathBuf {
    #[cfg(target_os="android")]
    { PathBuf::from("/data/user/0/com.bigmoe.onedgeplus.rust/files") }
    #[cfg(not(target_os="android"))]
    { std::env::current_dir().unwrap_or_else(|_|PathBuf::from(".")).join(".bigmoe-plus-rust") }
}

fn resolve_picked_model(file:robius_file_picker::PickedFile)->Result<PathBuf,String>{
    let local=file.into_local_file().map_err(|e|e.to_string())?;
    let source=local.path();
    if !source.extension().and_then(|e|e.to_str()).is_some_and(|e|e.eq_ignore_ascii_case("gguf")) {
        return Err("Please select a .gguf model file.".into());
    }
    #[cfg(target_os="android")]
    {
        // The picker temp file is deleted when `local` drops, so copy into private persistent storage.
        let dir=app_data_dir().join("models");
        fs::create_dir_all(&dir).map_err(|e|format!("Cannot create model directory: {e}"))?;
        let name=local.display_name().and_then(|n|Path::new(n).file_name()).or_else(||source.file_name()).and_then(|n|n.to_str()).unwrap_or("model.gguf");
        let mut destination=dir.join(name);
        if destination.exists() {
            let stem=Path::new(name).file_stem().and_then(|s|s.to_str()).unwrap_or("model");
            let ext=Path::new(name).extension().and_then(|s|s.to_str()).unwrap_or("gguf");
            let mut n=1u32;
            loop { let candidate=dir.join(format!("{stem} ({n}).{ext}")); if !candidate.exists(){destination=candidate;break;} n=n.saturating_add(1); if n==u32::MAX{return Err("Cannot find an unused destination filename".into());} }
        }
        fs::copy(source,&destination).map_err(|e|format!("Cannot copy model into private app storage: {e}"))?;
        Ok(destination)
    }
    #[cfg(not(target_os="android"))]
    { Ok(source.to_path_buf()) }
}

fn detect_device_profile()->DeviceProfile{
    let mut total=8192u64;let mut avail=4096u64;
    if let Ok(text)=std::fs::read_to_string("/proc/meminfo") {for line in text.lines(){if let Some(v)=line.strip_prefix("MemTotal:"){if let Some(k)=v.split_whitespace().next().and_then(|x|x.parse::<u64>().ok()){total=(k/1024).max(768);}}if let Some(v)=line.strip_prefix("MemAvailable:"){if let Some(k)=v.split_whitespace().next().and_then(|x|x.parse::<u64>().ok()){avail=k/1024;}}}}
    let cores=std::thread::available_parallelism().map(|n|n.get() as u32).unwrap_or(4).max(1);
    DeviceProfile{total_ram_mb:total,avail_ram_mb:avail,cores,fast_cores:cores.min(8),soc:std::env::var("BMOE_SOC_NAME").unwrap_or_else(|_|"SoC not detected".into()),mem_bandwidth_gbs:20.0,npu_runtime:false}
}
