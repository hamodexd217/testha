mod api;
mod runtime;
mod store;
mod ui;

#[cfg(not(target_os = "android"))]
fn main() -> eframe::Result<()> {
    let options = eframe::NativeOptions {
        viewport: eframe::egui::ViewportBuilder::default()
            .with_inner_size([1280.0, 820.0])
            .with_min_inner_size([720.0, 560.0]),
        ..Default::default()
    };
    eframe::run_native(
        "BigMoeOnEdge+ Rust",
        options,
        Box::new(|cc| Ok(Box::new(ui::BigMoeApp::new(cc)))),
    )
}

/// Rust-only Android NativeActivity entrypoint. This is an experimental packaging path;
/// Android file-picker permissions and device-specific inference still require validation.
#[cfg(target_os = "android")]
#[unsafe(no_mangle)]
pub fn android_main(app: winit::platform::android::activity::AndroidApp) {
    let options = eframe::NativeOptions {
        android_app: Some(app),
        ..Default::default()
    };
    let _ = eframe::run_native(
        "BigMoeOnEdge+ Rust",
        options,
        Box::new(|cc| Ok(Box::new(ui::BigMoeApp::new(cc)))),
    );
}
