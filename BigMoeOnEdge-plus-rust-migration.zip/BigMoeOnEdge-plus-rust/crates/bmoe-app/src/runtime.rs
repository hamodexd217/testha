//! Single-owner inference worker. UI/API threads send commands; only this worker mutates sessions.
//! Token text is fanned out to the UI event stream and, when requested, a per-request API stream.
use bmoe_core::{ChatTurn, GenerationStats};
use cera::{BackendPreference, CeraEngine, EngineConfig, GenerateOpts, Message, SessionConfig};
use cera::session::chat::SessionChat;
use std::{
    collections::HashMap,
    path::PathBuf,
    sync::{mpsc::{self, Receiver, Sender}, Arc, Mutex},
    thread,
};

#[derive(Debug, Clone)]
pub enum RuntimeEvent {
    Loading { path: String },
    Loaded { path: String, architecture: String },
    Unloaded,
    Token { request_id: String, delta: String },
    Answer { request_id: String, text: String, stats: GenerationStats },
    Error { request_id: Option<String>, message: String },
}

/// Per-request stream items used by SSE endpoints. `Done` is always sent after successful queueing,
/// unless the receiver disconnects or the worker process exits unexpectedly.
#[derive(Debug, Clone)]
pub enum InferenceStreamItem {
    Delta(String),
    Done(Result<GenerationStats, String>),
}

#[derive(Debug)]
enum RuntimeCommand {
    Load { path: PathBuf, backend: String, context_size: u32 },
    Unload,
    Generate {
        request_id: String,
        session_id: String,
        state_key: String,
        next_state_key: String,
        path: String,
        backend: String,
        system: String,
        history: Vec<ChatTurn>,
        prompt: String,
        max_tokens: usize,
        context_length: u32,
        batch_width: u32,
        seed: i64,
        temperature: f32,
        top_p: f32,
        top_k: u32,
        response: Option<Sender<Result<(String, GenerationStats), String>>>,
        stream: Option<Sender<InferenceStreamItem>>,
    },
    Shutdown,
}

#[derive(Clone)]
pub struct InferenceClient {
    tx: Sender<RuntimeCommand>,
    events: Arc<Mutex<Receiver<RuntimeEvent>>>,
}

impl InferenceClient {
    pub fn spawn() -> Self {
        let (tx, rx) = mpsc::channel();
        let (event_tx, event_rx) = mpsc::channel();
        thread::Builder::new()
            .name("bmoe-inference".into())
            .spawn(move || worker_loop(rx, event_tx))
            .expect("create inference worker");
        Self { tx, events: Arc::new(Mutex::new(event_rx)) }
    }

    pub fn load(&self, path: impl Into<PathBuf>) {
        self.load_with_settings(path, "auto", 4096);
    }

    pub fn load_with_settings(&self, path: impl Into<PathBuf>, backend: impl Into<String>, context_size: u32) {
        let _ = self.tx.send(RuntimeCommand::Load { path: path.into(), backend: backend.into(), context_size });
    }

    pub fn unload(&self) {
        let _ = self.tx.send(RuntimeCommand::Unload);
    }

    #[allow(clippy::too_many_arguments)]
    pub fn generate(
        &self, request_id: String, session_id: String, state_key: String,
        next_state_key: String, path: String, backend: String, system: String, history: Vec<ChatTurn>,
        prompt: String, max_tokens: usize, context_length: u32, batch_width: u32,
        seed: i64, temperature: f32, top_p: f32, top_k: u32,
    ) {
        let _ = self.tx.send(RuntimeCommand::Generate {
            request_id, session_id, state_key, next_state_key, path, backend, system, history, prompt,
            max_tokens, context_length, batch_width, seed, temperature, top_p, top_k,
            response: None, stream: None,
        });
    }

    #[allow(clippy::too_many_arguments)]
    pub fn generate_blocking(
        &self, session_id: String, state_key: String, next_state_key: String,
        path: String, backend: String, system: String, history: Vec<ChatTurn>, prompt: String,
        max_tokens: usize, context_length: u32, batch_width: u32, seed: i64,
        temperature: f32, top_p: f32, top_k: u32,
    ) -> Result<(String, GenerationStats), String> {
        let (tx, rx) = mpsc::channel();
        let request_id = uuid::Uuid::new_v4().to_string();
        self.tx.send(RuntimeCommand::Generate {
            request_id, session_id, state_key, next_state_key, path, backend, system, history, prompt,
            max_tokens, context_length, batch_width, seed, temperature, top_p, top_k,
            response: Some(tx), stream: None,
        }).map_err(|e| e.to_string())?;
        rx.recv().map_err(|e| e.to_string())?
    }

    #[allow(clippy::too_many_arguments)]
    pub fn generate_streaming(
        &self, request_id: String, session_id: String, state_key: String,
        next_state_key: String, path: String, backend: String, system: String, history: Vec<ChatTurn>,
        prompt: String, max_tokens: usize, context_length: u32, batch_width: u32,
        seed: i64, temperature: f32, top_p: f32, top_k: u32,
    ) -> Result<Receiver<InferenceStreamItem>, String> {
        let (tx, rx) = mpsc::channel();
        self.tx.send(RuntimeCommand::Generate {
            request_id, session_id, state_key, next_state_key, path, backend, system, history, prompt,
            max_tokens, context_length, batch_width, seed, temperature, top_p, top_k,
            response: None, stream: Some(tx),
        }).map_err(|e| e.to_string())?;
        Ok(rx)
    }

    pub fn try_events(&self) -> Vec<RuntimeEvent> {
        let Ok(lock) = self.events.lock() else { return vec![]; };
        let mut out = Vec::new();
        while let Ok(event) = lock.try_recv() { out.push(event); }
        out
    }

    pub fn shutdown(&self) { let _ = self.tx.send(RuntimeCommand::Shutdown); }
}

struct CachedChat {
    state_key: String,
    system: String,
    context_length: u32,
    batch_width: u32,
    chat: SessionChat,
}

fn send_failure(
    events: &Sender<RuntimeEvent>,
    request_id: &str,
    response: &Option<Sender<Result<(String, GenerationStats), String>>>,
    stream: &Option<Sender<InferenceStreamItem>>,
    message: String,
) {
    if let Some(tx) = response { let _ = tx.send(Err(message.clone())); }
    if let Some(tx) = stream { let _ = tx.send(InferenceStreamItem::Done(Err(message.clone()))); }
    let _ = events.send(RuntimeEvent::Error { request_id: Some(request_id.to_owned()), message });
}

fn load_engine(path: &std::path::Path, backend: &str, context_size: u32) -> Result<CeraEngine, String> {
    let preference = BackendPreference::parse_str(backend).unwrap_or(BackendPreference::Auto);
    let config = EngineConfig { context_size: context_size.clamp(256, 131072) as usize, backend: preference, ..EngineConfig::default() };
    CeraEngine::from_path(path, config).map_err(|error| error.to_string())
}

fn worker_loop(rx: Receiver<RuntimeCommand>, events: Sender<RuntimeEvent>) {
    let mut engine: Option<CeraEngine> = None;
    let mut current_path = String::new();
    let mut current_backend = String::new();
    let mut current_context_size = 0u32;
    let mut chats: HashMap<String, CachedChat> = HashMap::new();

    while let Ok(command) = rx.recv() {
        match command {
            RuntimeCommand::Shutdown => break,
            RuntimeCommand::Unload => {
                engine = None;
                chats.clear();
                current_path.clear();
                current_backend.clear();
                current_context_size = 0;
                let _ = events.send(RuntimeEvent::Unloaded);
            }
            RuntimeCommand::Load { path, backend, context_size } => {
                let path_string = path.to_string_lossy().to_string();
                let _ = events.send(RuntimeEvent::Loading { path: path_string.clone() });
                match load_engine(&path, &backend, context_size) {
                    Ok(loaded) => {
                        engine = Some(loaded);
                        current_path = path_string.clone();
                        current_backend = backend.clone();
                        current_context_size = context_size;
                        chats.clear();
                        let architecture = bmoe_core::GgufInfo::inspect(&path).ok().and_then(|info| info.architecture)
                            .unwrap_or_else(|| "unknown architecture".into());
                        let _ = events.send(RuntimeEvent::Loaded { path: path_string, architecture });
                    }
                    Err(error) => {
                        engine = None;
                        chats.clear();
                        current_path.clear();
                        current_backend.clear();
                        current_context_size = 0;
                        let _ = events.send(RuntimeEvent::Error { request_id: None, message: format!("Model load failed: {error}") });
                    }
                }
            }
            RuntimeCommand::Generate {
                request_id, session_id, state_key, next_state_key, path, backend, system, history,
                prompt, max_tokens, context_length, batch_width, seed, temperature, top_p,
                top_k, response, stream,
            } => {
                if engine.is_none() || current_path != path || current_backend != backend || current_context_size != context_length {
                    let _ = events.send(RuntimeEvent::Loading { path: path.clone() });
                    match load_engine(&path, &backend, context_length) {
                        Ok(loaded) => {
                            engine = Some(loaded);
                            current_path = path.clone();
                            current_backend = backend.clone();
                            current_context_size = context_length;
                            chats.clear();
                            let architecture = bmoe_core::GgufInfo::inspect(&path).ok().and_then(|info| info.architecture)
                                .unwrap_or_else(|| "unknown architecture".into());
                            let _ = events.send(RuntimeEvent::Loaded { path: path.clone(), architecture });
                        }
                        Err(error) => {
                            send_failure(&events, &request_id, &response, &stream, format!("Model load failed: {error}"));
                            continue;
                        }
                    }
                }

                let effective_context = context_length.clamp(256, 131072);
                let effective_batch = batch_width.clamp(1, 4096);
                let stale = chats.get(&session_id).is_none_or(|cached| {
                    cached.state_key != state_key || cached.system != system
                        || cached.context_length != effective_context || cached.batch_width != effective_batch
                });

                if stale {
                    let Some(active_engine) = engine.as_ref() else { continue; };
                    let config = SessionConfig {
                        max_seq_len: Some(effective_context),
                        ubatch_size: effective_batch,
                        seed: if seed >= 0 { Some(seed as u64) } else { None },
                        ..SessionConfig::default()
                    };
                    let built = match active_engine.new_session(config) {
                        Ok(session) => session.into_chat().map_err(|(_, error)| error.to_string()),
                        Err(error) => Err(error.to_string()),
                    };
                    match built {
                        Ok(mut chat) => {
                            if !system.trim().is_empty() {
                                if let Err(error) = chat.ingest(&Message::system(system.clone())) {
                                    send_failure(&events, &request_id, &response, &stream, format!("Could not add system message: {error}"));
                                    continue;
                                }
                            }
                            let mut failed = None;
                            for turn in &history {
                                let message = if turn.role == ChatTurn::ASSISTANT {
                                    Message::assistant(turn.content.clone())
                                } else {
                                    Message::user(turn.content.clone())
                                };
                                if let Err(error) = chat.ingest(&message) { failed = Some(error.to_string()); break; }
                            }
                            if let Some(error) = failed {
                                send_failure(&events, &request_id, &response, &stream, format!("Could not restore chat context: {error}"));
                                continue;
                            }
                            chats.insert(session_id.clone(), CachedChat {
                                state_key: state_key.clone(), system: system.clone(),
                                context_length: effective_context, batch_width: effective_batch, chat,
                            });
                        }
                        Err(error) => {
                            send_failure(&events, &request_id, &response, &stream, format!("Could not create inference session: {error}"));
                            continue;
                        }
                    }
                }

                let Some(cached) = chats.get_mut(&session_id) else { continue; };
                if let Err(error) = cached.chat.ingest(&Message::user(prompt)) {
                    chats.remove(&session_id);
                    send_failure(&events, &request_id, &response, &stream, format!("Could not add prompt (session reset required): {error}"));
                    continue;
                }

                let mut options = GenerateOpts::default();
                let token_limit = if max_tokens == 0 { effective_context as usize } else { max_tokens.min(effective_context as usize) };
                options.max_tokens = token_limit.max(1).min(u32::MAX as usize) as u32;
                options.seed = if seed >= 0 { Some(seed as u64) } else { None };
                options.temperature = temperature.clamp(0.0, 2.0);
                options.top_p = top_p.clamp(0.0, 1.0);
                options.top_k = top_k;

                let mut streamed_text = String::new();
                let result = cached.chat.stream_text(&options, |delta| {
                    streamed_text.push_str(delta);
                    if let Some(tx) = &stream { let _ = tx.send(InferenceStreamItem::Delta(delta.to_owned())); }
                    let _ = events.send(RuntimeEvent::Token { request_id: request_id.clone(), delta: delta.to_owned() });
                });

                match result {
                    Ok(reply) => {
                        let generated = reply.summary.tokens_generated as u64;
                        let decode_seconds = reply.summary.decode_ms as f64 / 1000.0;
                        let stats = GenerationStats {
                            generated_tokens: generated,
                            prompt_tokens: reply.summary.prompt_eval_tokens as u64,
                            past_tokens: 0,
                            tokens_per_second: if decode_seconds > 0.0 { generated as f64 / decode_seconds } else { 0.0 },
                            prefill_seconds: reply.summary.prompt_eval_ms as f64 / 1000.0,
                            cache_hit_pct: None,
                        };
                        if let Some(cached) = chats.get_mut(&session_id) { cached.state_key = next_state_key; }
                        let final_text = if reply.text.is_empty() { streamed_text } else { reply.text };
                        if let Some(tx) = &response { let _ = tx.send(Ok((final_text.clone(), stats.clone()))); }
                        if let Some(tx) = &stream { let _ = tx.send(InferenceStreamItem::Done(Ok(stats.clone()))); }
                        let _ = events.send(RuntimeEvent::Answer { request_id, text: final_text, stats });
                    }
                    Err(error) => {
                        chats.remove(&session_id);
                        send_failure(&events, &request_id, &response, &stream, format!("Generation failed; session will be rebuilt next turn: {error}"));
                    }
                }
            }
        }
    }
}
