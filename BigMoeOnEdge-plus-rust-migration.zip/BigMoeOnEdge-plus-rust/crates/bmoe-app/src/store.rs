use anyhow::{Context, Result};
use bmoe_core::{ArtifactRecord, ChatSessionRecord, MessageRecord, ModelRecord, GenerationStats, ModelKind};
use rusqlite::{params, Connection, OptionalExtension};
use std::{fs, path::{Path, PathBuf}};

pub struct AppStore { conn: Connection, path: PathBuf }
impl AppStore {
    pub fn open(path: impl AsRef<Path>) -> Result<Self> {
        let path=path.as_ref().to_path_buf();
        if let Some(parent)=path.parent(){fs::create_dir_all(parent).context("create database directory")?;}
        let conn=Connection::open(&path).context("open local database")?;
        conn.pragma_update(None,"journal_mode","WAL")?;
        conn.pragma_update(None,"foreign_keys","ON")?;
        conn.execute_batch(r#"
            CREATE TABLE IF NOT EXISTS schema_meta(version INTEGER NOT NULL);
            INSERT INTO schema_meta(version) SELECT 1 WHERE NOT EXISTS(SELECT 1 FROM schema_meta);
            CREATE TABLE IF NOT EXISTS chat_sessions(
                id TEXT PRIMARY KEY, title TEXT NOT NULL, created_at_ms INTEGER NOT NULL,
                updated_at_ms INTEGER NOT NULL, system_prompt TEXT NOT NULL DEFAULT ''
            );
            CREATE INDEX IF NOT EXISTS idx_chat_sessions_updated ON chat_sessions(updated_at_ms DESC);
            CREATE TABLE IF NOT EXISTS chat_messages(
                id TEXT PRIMARY KEY, session_id TEXT NOT NULL REFERENCES chat_sessions(id) ON DELETE CASCADE,
                role TEXT NOT NULL, content TEXT NOT NULL, reasoning TEXT NOT NULL DEFAULT '',
                created_at_ms INTEGER NOT NULL, stats_json TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_chat_messages_session ON chat_messages(session_id, created_at_ms);
            CREATE TABLE IF NOT EXISTS models(
                id TEXT PRIMARY KEY, path TEXT NOT NULL UNIQUE, display_name TEXT NOT NULL,
                size_bytes INTEGER NOT NULL, kind TEXT NOT NULL, is_ready INTEGER NOT NULL DEFAULT 0,
                metadata_json TEXT NOT NULL DEFAULT '{}'
            );
            CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value_json TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS artifacts(
                id TEXT PRIMARY KEY, session_id TEXT REFERENCES chat_sessions(id) ON DELETE SET NULL,
                title TEXT NOT NULL, kind TEXT NOT NULL, language TEXT NOT NULL,
                file_name TEXT, content TEXT NOT NULL, created_at_ms INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS attachments(
                id TEXT PRIMARY KEY, session_id TEXT NOT NULL REFERENCES chat_sessions(id) ON DELETE CASCADE,
                path TEXT NOT NULL, display_name TEXT NOT NULL, mime_type TEXT NOT NULL DEFAULT '',
                size_bytes INTEGER NOT NULL DEFAULT 0, created_at_ms INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS model_profiles(
                model_path TEXT PRIMARY KEY, settings_json TEXT NOT NULL, updated_at_ms INTEGER NOT NULL
            );
        "#)?;
        Ok(Self{conn,path})
    }
    pub fn path(&self)->&Path {&self.path}
    pub fn sessions(&self)->Result<Vec<ChatSessionRecord>> {
        let mut stmt=self.conn.prepare("SELECT id,title,created_at_ms,updated_at_ms,system_prompt FROM chat_sessions ORDER BY updated_at_ms DESC")?;
        let rows=stmt.query_map([],|r|Ok(ChatSessionRecord{id:r.get(0)?,title:r.get(1)?,created_at_ms:r.get(2)?,updated_at_ms:r.get(3)?,system_prompt:r.get(4)?}))?;
        Ok(rows.collect::<rusqlite::Result<Vec<_>>>()?)
    }
    pub fn create_session(&self, title:&str, system_prompt:&str)->Result<ChatSessionRecord>{
        let now=now_ms();let record=ChatSessionRecord{id:uuid::Uuid::new_v4().to_string(),title:title.into(),created_at_ms:now,updated_at_ms:now,system_prompt:system_prompt.into()};
        self.conn.execute("INSERT INTO chat_sessions(id,title,created_at_ms,updated_at_ms,system_prompt) VALUES(?1,?2,?3,?4,?5)",params![record.id,record.title,record.created_at_ms,record.updated_at_ms,record.system_prompt])?;Ok(record)
    }
    pub fn rename_session(&self,id:&str,title:&str)->Result<()> {self.conn.execute("UPDATE chat_sessions SET title=?2,updated_at_ms=?3 WHERE id=?1",params![id,title,now_ms()])?;Ok(())}
    pub fn delete_session(&self,id:&str)->Result<()> {self.conn.execute("DELETE FROM chat_sessions WHERE id=?1",[id])?;Ok(())}
    pub fn messages(&self,session_id:&str)->Result<Vec<MessageRecord>> {
        let mut stmt=self.conn.prepare("SELECT id,session_id,role,content,reasoning,created_at_ms,stats_json FROM chat_messages WHERE session_id=?1 ORDER BY created_at_ms,id")?;
        let rows=stmt.query_map([session_id],|r|{
            let stats_json:Option<String>=r.get(6)?;
            Ok(MessageRecord{id:r.get(0)?,session_id:r.get(1)?,role:r.get(2)?,content:r.get(3)?,reasoning:r.get(4)?,created_at_ms:r.get(5)?,stats:stats_json.and_then(|s|serde_json::from_str::<GenerationStats>(&s).ok())})
        })?;Ok(rows.collect::<rusqlite::Result<Vec<_>>>()?)
    }
    pub fn add_message(&self,session_id:&str,role:&str,content:&str,reasoning:&str,stats:Option<&GenerationStats>)->Result<MessageRecord>{
        self.add_message_with_id(uuid::Uuid::new_v4().to_string(),session_id,role,content,reasoning,stats)
    }
    pub fn add_message_with_id(&self,id:String,session_id:&str,role:&str,content:&str,reasoning:&str,stats:Option<&GenerationStats>)->Result<MessageRecord>{
        let rec=MessageRecord{id,session_id:session_id.into(),role:role.into(),content:content.into(),reasoning:reasoning.into(),created_at_ms:now_ms(),stats:stats.cloned()};
        self.conn.execute("INSERT INTO chat_messages(id,session_id,role,content,reasoning,created_at_ms,stats_json) VALUES(?1,?2,?3,?4,?5,?6,?7)",params![rec.id,rec.session_id,rec.role,rec.content,rec.reasoning,rec.created_at_ms,rec.stats.as_ref().map(serde_json::to_string).transpose()?])?;
        self.conn.execute("UPDATE chat_sessions SET updated_at_ms=?2 WHERE id=?1",params![session_id,rec.created_at_ms])?;Ok(rec)
    }
    /// Append one decoded text chunk to a pending assistant message. Chunks are persisted so a
    /// process shutdown does not discard an otherwise visible partial response.
    pub fn append_message_content(&self,id:&str,delta:&str)->Result<()> {
        let changed=self.conn.execute("UPDATE chat_messages SET content=content || ?2 WHERE id=?1",params![id,delta])?;
        if changed==0 { anyhow::bail!("message {id} does not exist"); }
        self.conn.execute("UPDATE chat_sessions SET updated_at_ms=?2 WHERE id=(SELECT session_id FROM chat_messages WHERE id=?1)",params![id,now_ms()])?;
        Ok(())
    }
    /// Finalize the already-created assistant placeholder without inserting a duplicate row.
    pub fn complete_message(&self,id:&str,content:&str,reasoning:&str,stats:&GenerationStats)->Result<()> {
        let changed=self.conn.execute("UPDATE chat_messages SET content=?2,reasoning=?3,stats_json=?4 WHERE id=?1",params![id,content,reasoning,serde_json::to_string(stats)?])?;
        if changed==0 { anyhow::bail!("pending assistant message {id} does not exist"); }
        self.conn.execute("UPDATE chat_sessions SET updated_at_ms=?2 WHERE id=(SELECT session_id FROM chat_messages WHERE id=?1)",params![id,now_ms()])?;
        Ok(())
    }
    pub fn models(&self)->Result<Vec<ModelRecord>>{
        let mut stmt=self.conn.prepare("SELECT id,path,display_name,size_bytes,kind,is_ready,metadata_json FROM models ORDER BY display_name COLLATE NOCASE")?;
        let rows=stmt.query_map([],|r|{let kind:String=r.get(4)?;Ok(ModelRecord{id:r.get(0)?,path:r.get(1)?,display_name:r.get(2)?,size_bytes:r.get::<_,i64>(3)?.max(0) as u64,kind:if kind=="moe"{ModelKind::Moe}else{ModelKind::Dense},is_ready:r.get::<_,i64>(5)?!=0,metadata_json:r.get(6)?})})?;Ok(rows.collect::<rusqlite::Result<Vec<_>>>()?)
    }
    pub fn upsert_model(&self,model:&ModelRecord)->Result<()> {
        self.conn.execute("INSERT INTO models(id,path,display_name,size_bytes,kind,is_ready,metadata_json) VALUES(?1,?2,?3,?4,?5,?6,?7) ON CONFLICT(path) DO UPDATE SET display_name=excluded.display_name,size_bytes=excluded.size_bytes,kind=excluded.kind,is_ready=excluded.is_ready,metadata_json=excluded.metadata_json",
            params![model.id,model.path,model.display_name,model.size_bytes.min(i64::MAX as u64) as i64,if model.kind==ModelKind::Moe{"moe"}else{"dense"},model.is_ready as i32,model.metadata_json])?;Ok(())
    }
    pub fn remove_model(&self,path:&str)->Result<()> {self.conn.execute("DELETE FROM models WHERE path=?1",[path])?;Ok(())}
    pub fn setting<T:serde::de::DeserializeOwned>(&self,key:&str)->Result<Option<T>>{
        let raw:Option<String>=self.conn.query_row("SELECT value_json FROM settings WHERE key=?1",[key],|r|r.get(0)).optional()?;
        raw.map(|s|serde_json::from_str(&s).context("decode persisted setting")).transpose()
    }
    pub fn save_setting<T:serde::Serialize>(&self,key:&str,value:&T)->Result<()> {
        self.conn.execute("INSERT INTO settings(key,value_json) VALUES(?1,?2) ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json",params![key,serde_json::to_string(value)?])?;Ok(())
    }

    pub fn save_artifact(&self, session_id:&str, title:&str, kind:&str, language:&str, file_name:Option<&str>, content:&str)->Result<ArtifactRecord>{
        let id=uuid::Uuid::new_v4().to_string();
        let created_at_ms=now_ms();
        let session:Option<&str>=if session_id.trim().is_empty(){None}else{Some(session_id)};
        self.conn.execute("INSERT INTO artifacts(id,session_id,title,kind,language,file_name,content,created_at_ms) VALUES(?1,?2,?3,?4,?5,?6,?7,?8)",params![id,session,title,kind,language,file_name,content,created_at_ms])?;
        Ok(ArtifactRecord{id,session_id:session.map(str::to_owned),title:title.to_owned(),kind:kind.to_owned(),language:language.to_owned(),file_name:file_name.map(str::to_owned),content:content.to_owned(),created_at_ms})
    }
    pub fn artifacts(&self, session_id:Option<&str>)->Result<Vec<ArtifactRecord>>{
        let mut out=Vec::new();
        if let Some(sid)=session_id {
            let mut stmt=self.conn.prepare("SELECT id,session_id,title,kind,language,file_name,content,created_at_ms FROM artifacts WHERE session_id=?1 ORDER BY created_at_ms DESC")?;
            let rows=stmt.query_map([sid],map_artifact)?;
            for row in rows {out.push(row?);}
        } else {
            let mut stmt=self.conn.prepare("SELECT id,session_id,title,kind,language,file_name,content,created_at_ms FROM artifacts ORDER BY created_at_ms DESC")?;
            let rows=stmt.query_map([],map_artifact)?;
            for row in rows {out.push(row?);}
        }
        Ok(out)
    }
    pub fn delete_artifact(&self,id:&str)->Result<()> {
        self.conn.execute("DELETE FROM artifacts WHERE id=?1",[id])?;
        Ok(())
    }
    pub fn save_model_profile<T:serde::Serialize>(&self,path:&str,settings:&T)->Result<()> {
        self.conn.execute("INSERT INTO model_profiles(model_path,settings_json,updated_at_ms) VALUES(?1,?2,?3) ON CONFLICT(model_path) DO UPDATE SET settings_json=excluded.settings_json,updated_at_ms=excluded.updated_at_ms",params![path,serde_json::to_string(settings)?,now_ms()])?;Ok(())
    }
    pub fn model_profile<T:serde::de::DeserializeOwned>(&self,path:&str)->Result<Option<T>> {
        let raw:Option<String>=self.conn.query_row("SELECT settings_json FROM model_profiles WHERE model_path=?1",[path],|r|r.get(0)).optional()?;
        raw.map(|s|serde_json::from_str(&s).context("decode model profile")).transpose()
    }
}
fn map_artifact(r:&rusqlite::Row<'_>)->rusqlite::Result<ArtifactRecord>{
    Ok(ArtifactRecord{id:r.get(0)?,session_id:r.get(1)?,title:r.get(2)?,kind:r.get(3)?,language:r.get(4)?,file_name:r.get(5)?,content:r.get(6)?,created_at_ms:r.get(7)?})
}
fn now_ms()->i64 {chrono::Utc::now().timestamp_millis()}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn streamed_content_is_persisted_and_finalized_without_duplicate_rows() {
        let root = std::env::temp_dir().join(format!("bmoe-store-test-{}", uuid::Uuid::new_v4()));
        let db = root.join("app.sqlite3");
        let store = AppStore::open(&db).expect("open test database");
        let session = store.create_session("Streaming test", "").expect("create session");
        let message_id = uuid::Uuid::new_v4().to_string();
        store.add_message_with_id(message_id.clone(), &session.id, "assistant", "", "", None)
            .expect("create pending assistant row");
        store.append_message_content(&message_id, "hello ").expect("append first chunk");
        store.append_message_content(&message_id, "world").expect("append second chunk");

        let stats = GenerationStats {
            generated_tokens: 2,
            prompt_tokens: 3,
            past_tokens: 0,
            tokens_per_second: 12.5,
            prefill_seconds: 0.1,
            cache_hit_pct: None,
        };
        store.complete_message(&message_id, "hello world", "", &stats).expect("finalize message");
        let messages = store.messages(&session.id).expect("read messages");
        assert_eq!(messages.len(), 1, "streaming should not create a duplicate assistant row");
        assert_eq!(messages[0].content, "hello world");
        assert_eq!(messages[0].stats.as_ref().map(|value| value.generated_tokens), Some(2));

        drop(store);
        std::fs::remove_dir_all(root).expect("remove test database directory");
    }
}
