//! Optional localhost HTTP API. The server always binds to IPv4 loopback, never a LAN interface.
use crate::runtime::{InferenceClient, InferenceStreamItem};
use axum::{
    extract::State,
    http::{HeaderMap, StatusCode},
    response::{sse::{Event, KeepAlive, Sse}, IntoResponse, Response},
    routing::{get, post}, Json, Router,
};
use bmoe_core::{ChatTurn, ContextPlanner};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::{
    convert::Infallible,
    net::SocketAddr,
    path::PathBuf,
    sync::{mpsc::{self, Receiver, Sender}, Arc, Mutex},
    thread::{self, JoinHandle},
    time::Duration,
};
use tokio_stream::wrappers::ReceiverStream;

#[derive(Clone)]
struct ApiState {
    runtime: InferenceClient,
    model_path: Arc<Mutex<String>>,
    api_key: Arc<Mutex<String>>,
    backend: String,
    context_size: u32,
}

pub struct LocalApiServer {
    shutdown: Option<Sender<()>>,
    thread: Option<JoinHandle<()>>,
    pub address: String,
}

impl LocalApiServer {
    pub fn start(runtime: InferenceClient, model_path: String, api_key: String, port: u16, backend: String, context_size: u32) -> Result<Self, String> {
        let (stop_tx, stop_rx) = mpsc::channel();
        let addr = SocketAddr::from(([127, 0, 0, 1], port));
        let state = ApiState {
            runtime,
            model_path: Arc::new(Mutex::new(model_path)),
            api_key: Arc::new(Mutex::new(api_key)),
            backend,
            context_size,
        };
        let (ready_tx, ready_rx) = mpsc::channel();
        let handle = thread::Builder::new()
            .name("bmoe-local-api".into())
            .spawn(move || server_thread(addr, state, stop_rx, ready_tx))
            .map_err(|e| e.to_string())?;
        match ready_rx.recv_timeout(Duration::from_secs(5)) {
            Ok(Ok(())) => Ok(Self { shutdown: Some(stop_tx), thread: Some(handle), address: format!("http://{addr}") }),
            Ok(Err(error)) => { let _ = handle.join(); Err(error) }
            Err(error) => { let _ = stop_tx.send(()); Err(format!("API server did not start: {error}")) }
        }
    }

    pub fn stop(&mut self) {
        if let Some(tx) = self.shutdown.take() { let _ = tx.send(()); }
        if let Some(handle) = self.thread.take() { let _ = handle.join(); }
    }
}
impl Drop for LocalApiServer { fn drop(&mut self) { self.stop(); } }

fn server_thread(addr: SocketAddr, state: ApiState, stop: Receiver<()>, ready: Sender<Result<(), String>>) {
    let runtime = match tokio::runtime::Builder::new_multi_thread().enable_all().build() {
        Ok(runtime) => runtime,
        Err(error) => { let _ = ready.send(Err(error.to_string())); return; }
    };
    runtime.block_on(async move {
        let app = Router::new()
            .route("/health", get(health))
            .route("/v1/models", get(models))
            .route("/v1/chat/completions", post(openai_chat))
            .route("/v1/messages", post(anthropic_messages))
            .with_state(state);
        let listener = match tokio::net::TcpListener::bind(addr).await {
            Ok(listener) => listener,
            Err(error) => { let _ = ready.send(Err(format!("Cannot bind localhost API on {addr}: {error}"))); return; }
        };
        let _ = ready.send(Ok(()));
        let stop_task = tokio::task::spawn_blocking(move || { let _ = stop.recv(); });
        let _ = axum::serve(listener, app).with_graceful_shutdown(async { let _ = stop_task.await; }).await;
    });
}

async fn health() -> Json<Value> { Json(json!({"status":"ok","service":"BigMoeOnEdge+ Rust"})) }

fn authorized(headers: &HeaderMap, key: &str) -> bool {
    key.is_empty() || headers.get("authorization").and_then(|h| h.to_str().ok())
        .is_some_and(|value| value.strip_prefix("Bearer ").is_some_and(|token| token == key))
}

async fn models(State(state): State<ApiState>, headers: HeaderMap) -> Response {
    let key = state.api_key.lock().map(|v| v.clone()).unwrap_or_default();
    if !authorized(&headers, &key) {
        return (StatusCode::UNAUTHORIZED, Json(json!({"error":{"message":"invalid API key","type":"authentication_error"}}))).into_response();
    }
    let path = state.model_path.lock().map(|v| v.clone()).unwrap_or_default();
    let name = PathBuf::from(&path).file_name().and_then(|x| x.to_str()).unwrap_or("local-model").to_owned();
    (StatusCode::OK, Json(json!({"object":"list","data":[{"id":name,"object":"model","owned_by":"local"}]}))).into_response()
}

#[derive(Debug, Deserialize)]
struct ApiMessage { role: String, content: Value }
impl ApiMessage {
    fn text(&self) -> String {
        match &self.content {
            Value::String(text) => text.clone(),
            Value::Array(parts) => parts.iter().filter_map(|part| part.get("text").and_then(Value::as_str)).collect::<Vec<_>>().join("\n"),
            _ => String::new(),
        }
    }
}

#[derive(Debug, Deserialize)]
struct OpenAiRequest {
    #[serde(default)] model: String,
    messages: Vec<ApiMessage>,
    max_tokens: Option<usize>,
    temperature: Option<f32>,
    top_p: Option<f32>,
    top_k: Option<u32>,
    #[serde(default)] stream: bool,
}
#[derive(Debug, Serialize)]
struct OpenAiResponse { id: String, object: String, created: u64, model: String, choices: Vec<OpenAiChoice>, usage: Value }
#[derive(Debug, Serialize)]
struct OpenAiChoice { index: u32, message: Value, finish_reason: String }

async fn openai_chat(State(state): State<ApiState>, headers: HeaderMap, Json(request): Json<OpenAiRequest>) -> Response {
    let api_key = state.api_key.lock().map(|value| value.clone()).unwrap_or_default();
    if !authorized(&headers, &api_key) {
        return (StatusCode::UNAUTHORIZED, Json(json!({"error":{"message":"invalid API key","type":"authentication_error"}}))).into_response();
    }
    let path = state.model_path.lock().map(|value| value.clone()).unwrap_or_default();
    if path.is_empty() {
        return (StatusCode::BAD_REQUEST, Json(json!({"error":{"message":"no model selected","type":"invalid_request_error"}}))).into_response();
    }
    let (system, history, prompt) = split_messages(request.messages);
    if prompt.trim().is_empty() {
        return (StatusCode::BAD_REQUEST, Json(json!({"error":{"message":"messages must end with a non-empty user message","type":"invalid_request_error"}}))).into_response();
    }
    let model_name = resolve_model_name(&request.model, &path);
    let max_tokens = request.max_tokens.unwrap_or(0);
    let temperature = request.temperature.unwrap_or(0.7);
    let top_p = request.top_p.unwrap_or(0.9);
    let top_k = request.top_k.unwrap_or(40);
    let request_id = format!("chatcmpl-{}", uuid::Uuid::new_v4().simple());
    let created = chrono::Utc::now().timestamp().max(0) as u64;
    let session_id = format!("api:{}", uuid::Uuid::new_v4());
    let state_key = ContextPlanner::state_key(&session_id, None, &system);
    let next_state_key = state_key.clone();

    if request.stream {
        let stream_rx = match state.runtime.generate_streaming(
            request_id.clone(), session_id, state_key, next_state_key, path, state.backend.clone(), system, history, prompt,
            max_tokens, state.context_size, 512, -1, temperature, top_p, top_k,
        ) {
            Ok(receiver) => receiver,
            Err(error) => return (StatusCode::SERVICE_UNAVAILABLE, Json(json!({"error":{"message":error,"type":"runtime_error"}}))).into_response(),
        };
        return openai_sse_response(stream_rx, request_id, model_name, created);
    }

    let runtime = state.runtime.clone();
    let backend = state.backend.clone();
    let context_size = state.context_size;
    let result = tokio::task::spawn_blocking(move || runtime.generate_blocking(
        session_id, state_key, next_state_key, path, backend, system, history, prompt, max_tokens,
        context_size, 512, -1, temperature, top_p, top_k,
    )).await;
    match result {
        Ok(Ok((text, stats))) => {
            let body = OpenAiResponse {
                id: request_id, object: "chat.completion".into(), created, model: model_name,
                choices: vec![OpenAiChoice { index: 0, message: json!({"role":"assistant","content":text}), finish_reason: "stop".into() }],
                usage: json!({"prompt_tokens":stats.prompt_tokens,"completion_tokens":stats.generated_tokens,"total_tokens":stats.prompt_tokens+stats.generated_tokens}),
            };
            (StatusCode::OK, Json(serde_json::to_value(body).unwrap_or_else(|_| json!({"error":"serialization failed"})))).into_response()
        }
        Ok(Err(error)) => (StatusCode::BAD_GATEWAY, Json(json!({"error":{"message":error,"type":"inference_error"}}))).into_response(),
        Err(error) => (StatusCode::INTERNAL_SERVER_ERROR, Json(json!({"error":{"message":error.to_string(),"type":"runtime_error"}}))).into_response(),
    }
}

#[derive(Debug, Deserialize)]
struct AnthropicRequest {
    #[serde(default)] model: String,
    max_tokens: usize,
    messages: Vec<ApiMessage>,
    system: Option<String>,
    temperature: Option<f32>,
    top_p: Option<f32>,
    #[serde(default)] stream: bool,
}

async fn anthropic_messages(State(state): State<ApiState>, headers: HeaderMap, Json(request): Json<AnthropicRequest>) -> Response {
    let api_key = state.api_key.lock().map(|value| value.clone()).unwrap_or_default();
    if !authorized(&headers, &api_key) {
        return (StatusCode::UNAUTHORIZED, Json(json!({"type":"error","error":{"type":"authentication_error","message":"invalid API key"}}))).into_response();
    }
    let path = state.model_path.lock().map(|value| value.clone()).unwrap_or_default();
    if path.is_empty() {
        return (StatusCode::BAD_REQUEST, Json(json!({"type":"error","error":{"type":"invalid_request_error","message":"no model selected"}}))).into_response();
    }
    let (embedded_system, history, prompt) = split_messages(request.messages);
    if prompt.trim().is_empty() {
        return (StatusCode::BAD_REQUEST, Json(json!({"type":"error","error":{"type":"invalid_request_error","message":"messages must end with a non-empty user message"}}))).into_response();
    }
    let system = request.system.unwrap_or(embedded_system);
    let model_name = resolve_model_name(&request.model, &path);
    let max_tokens = request.max_tokens;
    let temperature = request.temperature.unwrap_or(0.7);
    let top_p = request.top_p.unwrap_or(0.9);
    let request_id = format!("msg_{}", uuid::Uuid::new_v4().simple());
    let session_id = format!("anthropic:{}", uuid::Uuid::new_v4());
    let state_key = ContextPlanner::state_key(&session_id, None, &system);
    let next_state_key = state_key.clone();

    if request.stream {
        let stream_rx = match state.runtime.generate_streaming(
            request_id.clone(), session_id, state_key, next_state_key, path, state.backend.clone(), system, history, prompt,
            max_tokens, state.context_size, 512, -1, temperature, top_p, 40,
        ) {
            Ok(receiver) => receiver,
            Err(error) => return (StatusCode::SERVICE_UNAVAILABLE, Json(json!({"type":"error","error":{"type":"runtime_error","message":error}}))).into_response(),
        };
        return anthropic_sse_response(stream_rx, request_id, model_name);
    }

    let runtime = state.runtime.clone();
    let backend = state.backend.clone();
    let context_size = state.context_size;
    let result = tokio::task::spawn_blocking(move || runtime.generate_blocking(
        session_id, state_key, next_state_key, path, backend, system, history, prompt, max_tokens,
        context_size, 512, -1, temperature, top_p, 40,
    )).await;
    match result {
        Ok(Ok((text, stats))) => (StatusCode::OK, Json(json!({
            "id":request_id,"type":"message","role":"assistant","model":model_name,
            "content":[{"type":"text","text":text}],"stop_reason":"end_turn","stop_sequence":null,
            "usage":{"input_tokens":stats.prompt_tokens,"output_tokens":stats.generated_tokens}
        }))).into_response(),
        Ok(Err(error)) => (StatusCode::BAD_GATEWAY, Json(json!({"type":"error","error":{"type":"inference_error","message":error}}))).into_response(),
        Err(error) => (StatusCode::INTERNAL_SERVER_ERROR, Json(json!({"type":"error","error":{"type":"runtime_error","message":error.to_string()}}))).into_response(),
    }
}

fn openai_sse_response(receiver: Receiver<InferenceStreamItem>, id: String, model: String, created: u64) -> Response {
    let (tx, rx) = tokio::sync::mpsc::channel::<Result<Event, Infallible>>(16);
    tokio::task::spawn_blocking(move || {
        let role_chunk = json!({"id":id,"object":"chat.completion.chunk","created":created,"model":model,
            "choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}]});
        if tx.blocking_send(Ok(Event::default().data(role_chunk.to_string()))).is_err() { return; }
        while let Ok(item) = receiver.recv() {
            match item {
                InferenceStreamItem::Delta(delta) => {
                    let chunk = json!({"id":id,"object":"chat.completion.chunk","created":created,"model":model,
                        "choices":[{"index":0,"delta":{"content":delta},"finish_reason":null}]});
                    if tx.blocking_send(Ok(Event::default().data(chunk.to_string()))).is_err() { return; }
                }
                InferenceStreamItem::Done(Ok(_stats)) => {
                    let chunk = json!({"id":id,"object":"chat.completion.chunk","created":created,"model":model,
                        "choices":[{"index":0,"delta":{},"finish_reason":"stop"}]});
                    let _ = tx.blocking_send(Ok(Event::default().data(chunk.to_string())));
                    let _ = tx.blocking_send(Ok(Event::default().data("[DONE]")));
                    return;
                }
                InferenceStreamItem::Done(Err(error)) => {
                    let payload = json!({"error":{"message":error,"type":"inference_error"}});
                    let _ = tx.blocking_send(Ok(Event::default().data(payload.to_string())));
                    let _ = tx.blocking_send(Ok(Event::default().data("[DONE]")));
                    return;
                }
            }
        }
        let _ = tx.blocking_send(Ok(Event::default().data("[DONE]")));
    });
    Sse::new(ReceiverStream::new(rx)).keep_alive(KeepAlive::new().interval(Duration::from_secs(15)).text("keep-alive")).into_response()
}

fn anthropic_sse_response(receiver: Receiver<InferenceStreamItem>, id: String, model: String) -> Response {
    let (tx, rx) = tokio::sync::mpsc::channel::<Result<Event, Infallible>>(16);
    tokio::task::spawn_blocking(move || {
        let message_start = json!({"type":"message_start","message":{"id":id,"type":"message","role":"assistant","model":model,
            "content":[],"stop_reason":null,"stop_sequence":null,"usage":{"input_tokens":0,"output_tokens":0}}});
        if tx.blocking_send(Ok(Event::default().event("message_start").data(message_start.to_string()))).is_err() { return; }
        let block_start = json!({"type":"content_block_start","index":0,"content_block":{"type":"text","text":""}});
        if tx.blocking_send(Ok(Event::default().event("content_block_start").data(block_start.to_string()))).is_err() { return; }
        while let Ok(item) = receiver.recv() {
            match item {
                InferenceStreamItem::Delta(delta) => {
                    let data = json!({"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":delta}});
                    if tx.blocking_send(Ok(Event::default().event("content_block_delta").data(data.to_string()))).is_err() { return; }
                }
                InferenceStreamItem::Done(Ok(stats)) => {
                    let stop = json!({"type":"content_block_stop","index":0});
                    let delta = json!({"type":"message_delta","delta":{"stop_reason":"end_turn","stop_sequence":null},"usage":{"output_tokens":stats.generated_tokens}});
                    let end = json!({"type":"message_stop"});
                    let _ = tx.blocking_send(Ok(Event::default().event("content_block_stop").data(stop.to_string())));
                    let _ = tx.blocking_send(Ok(Event::default().event("message_delta").data(delta.to_string())));
                    let _ = tx.blocking_send(Ok(Event::default().event("message_stop").data(end.to_string())));
                    return;
                }
                InferenceStreamItem::Done(Err(error)) => {
                    let failure = json!({"type":"error","error":{"type":"api_error","message":error}});
                    let _ = tx.blocking_send(Ok(Event::default().event("error").data(failure.to_string())));
                    let _ = tx.blocking_send(Ok(Event::default().event("message_stop").data(json!({"type":"message_stop"}).to_string())));
                    return;
                }
            }
        }
        let _ = tx.blocking_send(Ok(Event::default().event("message_stop").data(json!({"type":"message_stop"}).to_string())));
    });
    Sse::new(ReceiverStream::new(rx)).keep_alive(KeepAlive::new().interval(Duration::from_secs(15)).text("keep-alive")).into_response()
}

fn resolve_model_name(requested: &str, path: &str) -> String {
    if !requested.trim().is_empty() { requested.to_owned() }
    else { PathBuf::from(path).file_name().and_then(|name| name.to_str()).unwrap_or("local-model").to_owned() }
}

fn split_messages(messages: Vec<ApiMessage>) -> (String, Vec<ChatTurn>, String) {
    let mut system = String::new();
    let mut turns = Vec::new();
    for message in messages {
        let text = message.text();
        match message.role.as_str() {
            "system" => { if !system.is_empty() { system.push('\n'); } system.push_str(&text); }
            "assistant" => turns.push(ChatTurn::assistant(text)),
            _ => turns.push(ChatTurn::user(text)),
        }
    }
    let prompt = if turns.last().is_some_and(|turn| turn.role == ChatTurn::USER) {
        turns.pop().map(|turn| turn.content).unwrap_or_default()
    } else { String::new() };
    (system, turns, prompt)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn resolves_requested_or_local_model_name() {
        assert_eq!(resolve_model_name("alias", "/models/model.gguf"), "alias");
        assert_eq!(resolve_model_name("", "/models/model.gguf"), "model.gguf");
    }

    #[test]
    fn final_user_message_becomes_generation_prompt() {
        let (system, history, prompt) = split_messages(vec![
            ApiMessage { role: "system".into(), content: Value::String("be helpful".into()) },
            ApiMessage { role: "user".into(), content: Value::String("hi".into()) },
            ApiMessage { role: "assistant".into(), content: Value::String("hello".into()) },
            ApiMessage { role: "user".into(), content: Value::String("again".into()) },
        ]);
        assert_eq!(system, "be helpful");
        assert_eq!(history.len(), 2);
        assert_eq!(history[1].content, "hello");
        assert_eq!(prompt, "again");
    }
}
