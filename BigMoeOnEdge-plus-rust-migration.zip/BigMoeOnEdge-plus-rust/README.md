# BigMoeOnEdge+ — Rust-first rewrite prototype

This repository is the **first Rust migration slice** for the uploaded BigMoeOnEdge+ application. It is not a claim of complete feature parity with the original Android app yet.

## Workspace

- `crates/bmoe-core`: Rust domain types, Auto Settings planner, context-window/history planning, incremental tool-call/artifact parser, and bounded GGUF metadata reader.
- `crates/bmoe-app`: a Rust `egui/eframe` UI, SQLite persistence, single-owner inference worker using the Rust `cera` crate, and an optional localhost HTTP API.

All first-party application code in this prototype is Rust. Configuration/manifest files remain TOML. The `eframe` UI now has a conditional Rust `NativeActivity` entrypoint and cargo-apk metadata, so Android packaging can be attempted without a Kotlin Activity. That path is experimental and **not yet built or device-verified**; lifecycle/suspend handling, verified model import on the target tablet, and signed APK delivery remain open items.

## Build and run

Install a current stable Rust toolchain (the workspace uses Rust edition 2024), then run:

```sh
cargo fmt --all
cargo test --workspace
cargo run -p bmoe-app
```

For an experimental Android APK build, install Android Studio/SDK + NDK, configure the Android environment variables, install the `aarch64-linux-android` Rust target and `cargo-apk`, then try `cargo apk build --release -p bmoe-app`. This packaging route has not been built here, so Android build/device behavior remains unverified. The Models page now uses a Rust-native file picker; on Android it copies the selected GGUF into private app storage. Large models need enough free storage for a full copy.

The first build downloads crates, including `cera`, `eframe`, and SQLite bindings. Settings include the backend preference (`auto`, `cpu`, `gpu`, `metal`, `hexagon`, `npu`) and the selected context length is passed into the engine configuration. This environment did not have `cargo` or `rustc`, and network access to install them was unavailable, so this package could not be compiled or tested here. Treat compilation and actual inference as unverified until those commands pass on a Rust-enabled machine.

## Adding a model

Open **Models** and use **Browse…** to choose a `.gguf` file, or paste a filesystem path, then choose **Inspect + Add**. The header reader inspects metadata only. On desktop the model is loaded in place; on Android, the picker import copies it into private app storage. In Chat, use the export controls to save a conversation as Markdown, text, or JSON. Select the model and send a prompt. Model support depends on Cera's actual architecture and quantization coverage; the custom llama.cpp backend from the Android original is not replicated in this pass.

## Local API

The optional API binds to `127.0.0.1` only. It exposes `/health`, `/v1/models`, `/v1/chat/completions`, and `/v1/messages`. OpenAI-compatible and Anthropic-compatible requests support Server-Sent Events (SSE) when `stream: true`. Client-disconnect cancellation, API tools, and complete provider-specific protocol parity are not implemented yet. Leave it bound to loopback; do not expose it to a network.

## Migration status

See [`MIGRATION_STATUS.md`](MIGRATION_STATUS.md) for what's already ported, what is partial, and what still blocks equivalence with the Android source app.
