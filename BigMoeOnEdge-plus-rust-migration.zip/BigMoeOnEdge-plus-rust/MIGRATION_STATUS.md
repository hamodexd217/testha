# Migration status — do not confuse the prototype with parity

The source application is much larger than a syntax conversion. Its Android implementation includes Compose UI, Android lifecycle/storage APIs, Room/DataStore persistence, a custom-patched llama.cpp runtime, MoE streaming/cache controls, NPU integration, MTP, vision projector support, attachments, tools/search, artifacts, and APIs. This Rust tree is a concrete start, not a completed wholesale rewrite.

## In this Rust slice

- Rust domain models for chats, model records, device/model facts, runtime settings, and generation statistics.
- Auto Settings planning for Fastest / Balanced / Accurate, with conservative RAM checks and visible estimation warnings; compatible settings are saved as per-model profiles and restored when that model is selected.
- Context planning/history trimming and Kotlin/JVM-compatible string hash behavior for the context key.
- Incremental `<tool_call>` parser and fenced code artifact detection.
- Bounds-checked GGUF v2/v3 metadata inspection (not tensor loading).
- SQLite persistence for chats/messages, models, preferences, per-model profiles, attachments schema, and generated artifacts.
- Rust `egui` desktop shell with Chat, Models, Auto Settings, Workspace, Settings, and Local API pages.
- Cera-backed generation on a dedicated single-owner inference worker, using Cera token callbacks for incremental output. The selected context length, prefill micro-batch, sampling values, seed, and backend preference are passed where the new backend exposes equivalents.
- Loopback OpenAI-style and Anthropic-style endpoints, including incremental SSE streaming for both protocols.
- Streaming assistant text is displayed immediately and persisted in batches per UI event cycle to avoid a SQLite write for every tiny token.

## Partial / not equivalent yet

- **Android packaging/UI:** a Rust NativeActivity entrypoint and cargo-apk metadata now exist, but no APK has been built or verified. The Models page now invokes a Rust native document picker that maps to Android’s system document picker/Storage Access Framework and copies the selected GGUF into app-private storage. However, the APK has not been built, the path has not been validated on Android hardware, large model imports need free space for a full copy, and lifecycle suspend/resume handling remains missing. The current UI is an `eframe` port, not a pixel-perfect Compose recreation.
- **Inference backend:** Cera replaces the old custom-patched llama.cpp here. It does not expose all of the original MoE streaming/cache/prefetch knobs. The Auto Settings plan preserves the planning data, but only controls the session context length and micro-batch and sampler options that this backend exposes. Do not assume expert skipping, mmap/`O_DIRECT`, two-wave reads, route-ahead, or NPU prefill are applied.
- **Model coverage/performance:** no parity matrix for all original GGUF architectures/quantizations, no benchmark, no Android Snapdragon validation, and no guarantee that an original supported model will load in Cera.
- **Streaming and cancellation:** incremental UI output and HTTP SSE are implemented in the current code, but stop-generation and disconnect-driven cancellation are not. Anthropic stream usage starts with an unknown/zero input-token count; only completion usage is known when the generation finishes.
- **Tools and web search:** parser can recognize tool-call output, but tool registry, confirmation/permission flow, browser/search providers, scheduling, and tool execution are not wired into the UI/runtime.
- **Multimodal and files:** vision/audio model input, `mmproj`, actual attachments/image payloads, archive/document extraction, import-copy vs direct-load, split-GGUF continuation and MTP draft sidecars are not ported.
- **UI/UX parity:** existing chat history, model registration, settings, workspace text editing, artifact persistence and API controls exist in simple form. Original Compose navigation/accessibility, full artifact tools, separate reasoning stream, model comparisons, performance monitor, telemetry, and all original preferences are not all present. Chat export supports Markdown, plain text, and JSON through the native save dialog.
- **Migration of the entire source tree:** the original Kotlin/native C++ source remains separately in the provided archive; it has not been removed or silently claimed to be translated. Vendored third-party code is not rewritten by this prototype.

## Required validation before treating this as a replacement

1. Run `cargo fmt --all -- --check`, `cargo test --workspace`, and `cargo clippy --workspace --all-targets -- -D warnings` with stable Rust.
2. Run the app against each target architecture/quantization currently supported by the Android original; capture load/generate errors, token speed, peak RAM, and output correctness.
3. Implement Android packaging and device APIs, then validate on the actual target tablet.
4. Port remaining feature areas from the feature matrix above and run regression tests against exported chat/model/settings fixtures from the original.
5. Do not remove the original project until feature and performance parity is demonstrated.
